using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Xunit;

namespace DatesErp.Tests;

/// <summary>
/// §التصميم المعتمد — نشر لغة شاشة التخطيط (شرائح السياق + أشرطة الإجماليات + الجداول
/// المرسّمة بصفوف متبادلة) على شاشة أمر إنتاج اليوم وشاشة تسليم الإنتاج،
/// وإضافة الفلترة بالحالة والترتيب بالنقر على نافذة بحث الخطط المنبثقة.
/// </summary>
public class ProductionScreensDesignTests
{
    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null && !File.Exists(Path.Combine(dir.FullName, "DateERP.sln"))) dir = dir.Parent;
        return dir!.FullName;
    }

    private static string Read(string rel) => File.ReadAllText(Path.Combine(RepoRoot(), rel));

    [Fact]
    public void Orders_Screen_Uses_The_Adopted_Design()
    {
        // §شاشة أمر إنتاج اليوم بنفس لغة شاشة التخطيط
        string xaml = Read("src/DatesErp.Desktop/Views/Screens/OrdersView.xaml");
        string cs = Read("src/DatesErp.Desktop/Views/Screens/OrdersView.xaml.cs");

        // شرائح السياق الأربع + شريط الإجماليات
        Assert.Contains("DayChip", xaml); Assert.Contains("ItemsChip", xaml);
        Assert.Contains("IssuedChip", xaml); Assert.Contains("PendingChip", xaml);
        Assert.Contains("TotCartonsBox", xaml); Assert.Contains("TotQtyBox", xaml);
        Assert.Contains("TotCustsBox", xaml); Assert.Contains("TotLinesBox", xaml);
        Assert.Contains("DayChip.Text", cs); Assert.Contains("TotCartonsBox.Text", cs);

        // تنسيق الجدول الموحد: صفوف متبادلة وخطوط أفقية وإطار الهوية
        Assert.Contains("AlternatingRowBackground=\"#FBFAF5\"", xaml);
        Assert.Contains("HorizontalGridLinesBrush=\"#8CA0AC\"", xaml);
        Assert.Contains("BorderBrush=\"#D9D4C4\"", xaml);
        Assert.Contains("RowHeight=\"32\"", xaml);
        Assert.Contains("ColumnHeaderHeight=\"36\"", xaml);
        // عمود الوزن المعتمد في التصميم
        Assert.Contains("الوزن (كجم)", xaml);

        // العقود الوظيفية باقية: الجذر ListArea وجدول اليوم وإجراء الإصدار من هذه الشاشة فقط
        Assert.Contains("x:Name=\"ListArea\"", xaml);
        Assert.Contains("x:Name=\"TodayGrid\"", xaml);
        Assert.Contains("IssueTodayBtn", xaml);
        Assert.Contains("IssueToday_Click", cs);
        Assert.Contains("IssueTodayOrders()", cs);
        // §v1.50.36 — شاشة واحدة: المستند أسفل الجدول (لا DocArea متبادل)
        Assert.Contains("x:Name=\"DetailsHost\"", xaml);
        Assert.Contains("ShowOrderInPlace", cs);
        Assert.DoesNotContain("x:Name=\"DocArea\"", xaml);
    }

    [Fact]
    public void ProductionDelivery_Screen_Uses_The_Operational_Delivery_Design()
    {
        // شاشة التسليم مستقلة عن تسجيل الفعلي: مصدرها أمر ذو فعلي محفوظ، وحركات المخزون من سند الاستلام فقط.
        string xaml = Read("src/DatesErp.Desktop/Views/Screens/ProductionDeliveryView.xaml");
        string cs = Read("src/DatesErp.Desktop/Views/Screens/ProductionDeliveryView.xaml.cs");

        Assert.Contains("OrderChip", xaml); Assert.Contains("CustomerChip", xaml);
        Assert.Contains("PlanChip", xaml); Assert.Contains("ShiftLineChip", xaml);
        Assert.Contains("OrderChip.Text", cs); Assert.Contains("CustomerChip.Text", cs);
        Assert.Contains("PlanChip.Text", cs); Assert.Contains("ShiftLineChip.Text", cs);
        Assert.Contains("PlannedTotal", xaml); Assert.Contains("ActualTotal", xaml);
        Assert.Contains("DeliveredTotal", xaml); Assert.Contains("RemainingTotal", xaml);

        Assert.Contains("x:Name=\"StatusLabel\"", xaml);
        Assert.Contains("AlternatingRowBackground=\"#FBFAF5\"", xaml);
        Assert.Contains("HorizontalGridLinesBrush=\"#8CA0AC\"", xaml);
        Assert.Contains("x:Name=\"OrderBox\"", xaml);
        Assert.Contains("x:Name=\"DeliveryBox\"", xaml);
        Assert.Contains("x:Name=\"SearchBox\"", xaml);
        Assert.Contains("x:Name=\"ItemsGrid\"", xaml);
        Assert.Contains("x:Name=\"SecondaryGrid\"", xaml);
        Assert.Contains("x:Name=\"DeliveryDateBox\"", xaml);
        Assert.Contains("x:Name=\"NotesBox\"", xaml);

        // عمليات دورة المستند من شريط الأدوات؛ لا يوجد إدخال فعلي أو حفظه على هذه الشاشة.
        Assert.Contains(".WithNew(", cs); Assert.Contains(".WithEdit(", cs);
        Assert.Contains(".WithSave(", cs); Assert.Contains(".WithApprove(", cs);
        Assert.Contains(".WithSearch(", cs); Assert.Contains(".WithRefresh(", cs);
        Assert.Contains(".WithPrint(", cs); Assert.Contains(".WithUndo(", cs);
        Assert.Contains("SaveDraft()", cs); Assert.Contains("IssueDelivery()", cs);
        Assert.Contains("CancelDelivery()", cs); Assert.Contains("OpenWarehouseReceipt()", cs);
        Assert.Contains("SecondaryGrid.IsReadOnly = true", cs);
        Assert.DoesNotContain("x:Name=\"RawBox\"", xaml);
        Assert.DoesNotContain("SaveActualProduction", cs);
        Assert.Contains("لا توجد أوامر إنتاج ذات تنفيذ فعلي محفوظ", cs);
    }

    [Fact]
    public void PlanClosure_Separates_Closed_Order_Count_From_Closed_Quantity()
    {
        string xaml = Read("src/DatesErp.Desktop/Views/Screens/PlanClosureView.xaml");
        string cs = Read("src/DatesErp.Desktop/Views/Screens/PlanClosureView.xaml.cs");

        // عدد الأوامر المغلقة وكمية الإنتاج المغلقة معلومتان مستقلتان في الملخص.
        Assert.Contains("x:Name=\"CClosed\"", xaml);
        Assert.Contains("x:Name=\"CClosedQty\"", xaml);
        Assert.Contains("CClosed.Text = $\"مقفلة: {i.ClosedOrders}\"", cs);
        Assert.Contains("CClosedQty.Text = $\"المقفل: {i.ClosedTotal:N0}\"", cs);
    }

    [Fact]
    public void Plans_Search_Popup_Has_Status_Filter_And_Column_Sort()
    {
        // §فلترة نافذة الخطط: شرائح حالة (الكل + حالات الخطط) تُدمج مع البحث النصي،
        // والنقر على رأس أي عمود يرتّب به مع سهم اتجاه.
        string popup = Read("src/DatesErp.Desktop/Views/PlanSearchWindow.cs");

        // الفلتر بالحالة
        Assert.Contains("_statusFilter", popup);
        Assert.Contains("BuildStatusFilter", popup);
        Assert.Contains("\"الكل\"", popup);
        Assert.Contains("GroupName = \"planStatusFilter\"", popup);

        // الترتيب بالنقر على رأس العمود مع أسهم الاتجاه
        Assert.Contains("OnColumnSort", popup);
        Assert.Contains("Sorting += OnColumnSort", popup);
        Assert.Contains("SortMemberPath", popup);
        Assert.Contains("UpdateHeaderGlyphs", popup);
        Assert.Contains("SortFiltered", popup);

        // عقد الإنزال بالنقر المزدوج باقٍ كما هو
        Assert.Contains("MouseDoubleClick", popup);
        Assert.Contains("SelectedPlanId", popup);
        Assert.Contains("DialogResult = true", popup);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // §الفحص الشامل (v1.50.19): لا نافذة بلا نقطة دخول — «كود بلا واجهة»
    // اكتُشف هذا الحارس بعد أن وُجدت نافذة «المجموعات والفئات» بلا فتّاح منذ
    // إعادة بناء بطاقة الصنف، فأصبحت SaveItemGroup/SaveItemCategory بلا واجهة.
    // ═════════════════════════════════════════════════════════════════════════
    [Fact]
    public void Every_Window_Class_Is_Reachable_From_Another_File()
    {
        string root = RepoRoot();
        string dir = Path.Combine(root, "src/DatesErp.Desktop");
        var files = Directory.GetFiles(dir, "*.cs", SearchOption.AllDirectories)
            .Where(f => !f.Replace('\\', '/').Contains("/obj/") && !f.Replace('\\', '/').Contains("/bin/"))
            .ToList();
        var texts = files.ToDictionary(f => f, File.ReadAllText);

        var windows = new List<(string Name, string File)>();
        foreach (var (file, text) in texts)
            foreach (Match m in Regex.Matches(text, @"\bclass (\w*Window)\b"))
                windows.Add((m.Groups[1].Value, file));

        Assert.True(windows.Count >= 20, "قراءة نوافذ الواجهة فشلت (" + windows.Count + ").");
        // «الملف الحي»: إن كانت النافذة تُستخدم داخل ملفها (أكثر من مجرد تصريحها) وكان ذلك
        // الملف يحوي صنفاً آخر يذكره ملفات خارجية (مثل الشاشة نفسها) فهي متاحة عبره — وإلا فهي يتيمة.
        var classNamesPerFile = texts.ToDictionary(kv => kv.Key, kv =>
            Regex.Matches(kv.Value, @"\b(?:class|record)\s+(\w+)").Select(m => m.Groups[1].Value).Distinct().ToList());
        bool fileIsLive(string file) => classNamesPerFile[file].Any(c =>
            texts.Where(kv => kv.Key != file).Any(kv => kv.Value.Contains(c)));
        foreach (var (name, file) in windows)
        {
            bool usedInOwnFile = Regex.Matches(texts[file], @"\b" + Regex.Escape(name) + @"\b").Count >= 2;
            bool reachable = texts.Where(kv => kv.Key != file).Any(kv => kv.Value.Contains(name))
                || (usedInOwnFile && fileIsLive(file));
            Assert.True(reachable,
                $"النافذة «{name}» لا يذكرها أي ملف آخر في الواجهات — نافذة بلا نقطة دخول (كود بلا واجهة). " +
                "إما ربطها بزر/مسار فتح أو حذفها.");
        }
    }

}
