using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DatesErp.Core.Common;
using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Services;
using Microsoft.Extensions.DependencyInjection;

namespace DatesErp.Desktop.Views.Screens;

/// <summary>
/// شاشة تشغيل أوامر تسليم الإنتاج من الفعلي المحفوظ.
/// تحرير أمر التسليم يظل مرحلة إنتاجية مستقلة؛ سند الاستلام المخزني وحده يرحّل الأرصدة.
/// </summary>
public partial class ProductionDeliveryView : UserControl
{
    public static int? PendingOrderId { get; set; }

    private readonly ObservableCollection<DeliveryEditRow> _finishedRows = new();
    private readonly ObservableCollection<DeliveryEditRow> _secondaryRows = new();
    private readonly Func<List<ActualDeliveryOrderDto>> _loadOrders;
    private readonly Func<List<ActualByProductDefinitionDto>> _loadDefinitions;
    private List<ActualDeliveryOrderDto> _orders = new();
    private List<ActualByProductDefinitionDto> _definitions = new();
    private List<ProductionDeliveryCard> _deliveries = new();
    private List<WarehouseOptionDto> _warehouses = new();
    private DeliverySourceContext _sourceContext = new();
    private ActualDeliveryOrderDto _currentOrder;
    private ProductionDeliveryCard _currentDelivery;
    private bool _loading;
    private bool _saving;

    private static bool CanProduction(string action) => DatesErp.Desktop.Views.PermissionGate.Can("production", action);
    private static bool CanFinishedGoods(string action) => DatesErp.Desktop.Views.PermissionGate.Can("finishedgoods", action);

    public ProductionDeliveryView() : this(null, null, null) { }

    // التوقيع القديم يبقى للتوافق مع أي استدعاء/اختبار خارجي؛ شاشة التسليم لا تحفظ الفعلي.
    public ProductionDeliveryView(Func<List<ActualDeliveryOrderDto>> loadOrders,
        Func<List<ActualByProductDefinitionDto>> loadDefinitions,
        Func<ActualProductionDto, OpResult> saveActual)
    {
        _loadOrders = loadOrders;
        _loadDefinitions = loadDefinitions;
        _ = saveActual;
        InitializeComponent();
        ItemsGrid.ItemsSource = _finishedRows;
        SecondaryGrid.ItemsSource = _secondaryRows;
        Loaded += (_, _) => LoadData(PendingOrderId, null);
    }

    public void AttachChrome(Views.ErpChrome chrome)
    {
        chrome.SetModule("production");
        chrome.SetScreenCode("MRPMPS1021");
        var toolbar = new Views.ErpToolbar()
            .WithNew((_, _) => NewDelivery(), "جديد — أمر تسليم من الفعلي")
            .WithEdit((_, _) => EditSelected())
            .WithSave((_, _) => SaveDraft(), "حفظ مسودة التسليم")
            .WithApprove((_, _) => IssueDelivery(), "اعتماد/تحرير للمخزن")
            .WithCustom("إلغاء أمر التسليم", "ErpDangerButton", (_, _) => CancelDelivery(),
                "إلغاء مستند وفق حالته وصلاحية الإلغاء — لا يحذف السجل", "Cancel")
            .WithCustom("استلام مخزني", "ErpButton", (_, _) => OpenWarehouseReceipt(),
                "فتح دورة سند الاستلام المخزني المرتبط؛ هذه الخطوة وحدها ترحّل المخزون")
            .WithSearch((_, _) => SearchBox.Focus(), "البحث برقم أمر الإنتاج أو مستند التسليم")
            .WithRefresh((_, _) => LoadData(_currentOrder?.OrderId, _currentDelivery?.Id > 0 ? _currentDelivery.Id : null))
            .WithPrint((_, _) => Print(), "طباعة مستند التسليم المحفوظ فقط")
            .WithList((_, _) => ClearSearch_Click(this, new RoutedEventArgs()), "عرض الأوامر والمستندات")
            .WithUndo((_, _) => Undo(), "تراجع عن التحرير غير المحفوظ/إعادة تحميل المستند")
            .WithExit((_, _) => (Window.GetWindow(this) as MainWindow)?.OpenPreviousScreen());
        chrome.SetToolbar(toolbar);
        chrome.SetBody(this);
        chrome.CloseRequested += (_, _) => (Window.GetWindow(this) as MainWindow)?.OpenPreviousScreen();
    }

    public static void OpenForOrder(int orderId, Window source)
    {
        ErrorLog.WriteInfo($"ProductionDeliveryView.OpenForOrder OrderId={orderId} Source={source?.GetType().Name ?? "<null>"}");
        PendingOrderId = orderId;
        var main = System.Windows.Application.Current.MainWindow as MainWindow;
        var taskOwner = source?.Owner as TaskWindow;
        if (source != null && source != main) source.Close();
        taskOwner?.Close();
        main?.OpenScreen("proddelivery");
    }

    private T WithService<T>(Func<IProductionDeliveryService, T> action)
    {
        using var scope = AppContainer.NewScope();
        return action(scope.ServiceProvider.GetRequiredService<IProductionDeliveryService>());
    }

    private void LoadData(int? selectedOrderId, int? selectedDeliveryId)
    {
        _loading = true;
        try
        {
            _orders = _loadOrders?.Invoke() ?? WithService(s => s.GetActualDeliveryOrders());
            _definitions = _loadDefinitions?.Invoke() ?? WithService(s => s.GetActualByProducts());
            _deliveries = WithService(s => s.GetDeliveries());
            _warehouses = WithService(s => s.GetProductionDeliveryWarehouses());
            SetWarehouseColumns();
            OrderBox.ItemsSource = _orders;
            DeliveryBox.ItemsSource = _deliveries;
            OrderBox.SelectedIndex = -1;
            DeliveryBox.SelectedIndex = -1;
            PendingOrderId = null;

            if (selectedDeliveryId is int deliveryId)
            {
                var selected = _deliveries.FirstOrDefault(d => d.Id == deliveryId);
                if (selected != null)
                {
                    DeliveryBox.SelectedItem = selected;
                    LoadDelivery(selected.Id);
                    return;
                }
            }

            var order = _orders.FirstOrDefault(o => o.OrderId == selectedOrderId)
                ?? _orders.FirstOrDefault(o => o.CanCreateDelivery)
                ?? _orders.FirstOrDefault(o => o.Recorded)
                ?? _orders.FirstOrDefault();
            if (order != null)
            {
                OrderBox.SelectedItem = order;
                LoadOrder(order);
            }
            else
            {
                _currentOrder = null;
                _currentDelivery = null;
                _sourceContext = new DeliverySourceContext();
                ClearRows();
                SetSummary(null, null);
                StatusLabel.Text = _deliveries.Count > 0
                    ? "لا توجد أوامر مفتوحة في القائمة؛ ابحث برقم مستند التسليم لفتح سجل تاريخي أو مستلم."
                    : "لا توجد أوامر إنتاج ذات تنفيذ فعلي محفوظ أو مستندات تسليم مطابقة.";
            }
        }
        catch (Exception ex)
        {
            ClearRows();
            StatusLabel.Text = $"تعذر تحميل دورة تسليم الإنتاج: {ex.Message} — تم إبقاء المستندات دون تغيير.";
            ErrorLog.Write(ex, "ProductionDelivery.LoadData");
        }
        finally { _loading = false; }
    }

    private void SetWarehouseColumns()
    {
        foreach (var grid in new[] { ItemsGrid, SecondaryGrid })
            foreach (var column in grid.Columns.OfType<DataGridComboBoxColumn>())
                column.ItemsSource = _warehouses;
    }

    private void Order_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_loading || OrderBox.SelectedItem is not ActualDeliveryOrderDto order) return;
        LoadOrder(order);
    }

    private void Delivery_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_loading || DeliveryBox.SelectedItem is not ProductionDeliveryCard card) return;
        LoadDelivery(card.Id);
    }

    private void LoadOrder(ActualDeliveryOrderDto order)
    {
        _loading = true;
        try
        {
            _currentOrder = order;
            _currentDelivery = null;
            DeliveryDateBox.SelectedDate = DateTime.Today;
            NotesBox.Text = order.Notes ?? "";
            _sourceContext = order.ExecutionId > 0
                ? WithService(s => s.GetSourceContext(DeliverySources.FromActual, order.ExecutionId))
                : new DeliverySourceContext { SourceType = DeliverySources.FromActual, SourceId = order.ExecutionId };

            var latest = order.ProductionDeliveryId > 0
                ? _deliveries.FirstOrDefault(d => d.Id == order.ProductionDeliveryId)
                : null;
            if (latest != null)
            {
                var comboItem = _deliveries.FirstOrDefault(d => d.Id == latest.Id);
                if (comboItem != null) DeliveryBox.SelectedItem = comboItem;
                LoadDelivery(latest.Id);
                return;
            }

            PopulateRows(order, null);
            SetSummary(order, null);
            StatusLabel.Text = order.Recorded
                ? order.CanCreateDelivery
                    ? "الفعلي محفوظ. أنشئ مسودة جديدة، راجع كل سطر ووجهته، ثم احفظها واعتمدها. لا حركة مخزون عند إنشاء المسودة أو تحرير أمر التسليم."
                    : order.Status ?? "لا توجد كمية فعلية متبقية لإنشاء أمر تسليم جديد."
                : "لا يوجد تنفيذ فعلي مقفل لهذا الأمر؛ شاشة التسليم لا تعدّل الفعلي. سجّل التنفيذ من شاشة إقفال الإنتاج أولاً.";
        }
        catch (Exception ex)
        {
            ClearRows();
            StatusLabel.Text = $"تعذر قراءة التنفيذ الفعلي لأمر الإنتاج: {ex.Message}";
            ErrorLog.Write(ex, "ProductionDelivery.LoadOrder");
        }
        finally { _loading = false; }
    }

    private void LoadDelivery(int deliveryId)
    {
        _loading = true;
        try
        {
            var card = WithService(s => s.GetDelivery(deliveryId));
            if (card == null)
            {
                StatusLabel.Text = "مستند التسليم غير موجود؛ حدّث القائمة قبل المتابعة.";
                return;
            }
            _currentDelivery = card;
            _currentOrder = _orders.FirstOrDefault(o => o.OrderId == card.OrderId)
                ?? _orders.FirstOrDefault(o => o.ProductionDeliveryId == card.Id);
            if (_currentOrder != null)
            {
                OrderBox.SelectedItem = _currentOrder;
                _sourceContext = card.SourceType == DeliverySources.FromActual
                    ? WithService(s => s.GetSourceContext(card.SourceType, card.SourceId))
                    : new DeliverySourceContext { SourceType = card.SourceType, SourceId = card.SourceId };
            }
            else
            {
                _sourceContext = card.SourceType == DeliverySources.FromActual
                    ? WithService(s => s.GetSourceContext(card.SourceType, card.SourceId))
                    : new DeliverySourceContext { SourceType = card.SourceType, SourceId = card.SourceId };
            }
            DeliveryDateBox.SelectedDate = DatesErp.Core.Common.UiFormat.TryParseDate(card.DeliveryDate, out var date) ? date : DateTime.Today;
            NotesBox.Text = card.Notes ?? "";
            PopulateRows(_currentOrder, card);
            SetSummary(_currentOrder, card);
            bool draft = card.Status == DocStatuses.Draft;
            StatusLabel.Text = $"{card.DocumentNumber} — {card.StatusAr} — أمر الإنتاج: {card.OrderNumber ?? "—"} — الخطة: {card.PlanNumber ?? "—"} — الاستلام: {ReceiptStatusAr(card.ReceiptStatus)}";
            if (draft)
                StatusLabel.Text += "\nالمسودة قابلة للتعديل. الحفظ لا ينشئ حركة مخزون.";
            else if (card.Status == DocStatuses.Issued)
                StatusLabel.Text += "\nحُرر الأمر للمخزن بلا ترحيل. نفّذ الاستلام من سند الاستلام المرتبط لتسجيل الحركات.";
            else if (card.Status == DocStatuses.Completed)
                StatusLabel.Text += "\nاكتمل الاستلام حسب سندات المخزن المعتمدة؛ يعرض هذا المستند التاريخ ولا يمكن تعديل بنوده.";
            else if (card.Status == DocStatuses.Cancelled)
                StatusLabel.Text += "\nهذا مستند ملغى محفوظ للتدقيق ولا يمكن إعادة استخدامه.";
            if (card.SourceType != DeliverySources.FromActual)
                StatusLabel.Text += "\nمستند تاريخي/مسار قديم — للقراءة والطباعة فقط؛ أنشئ المسار التشغيلي الجديد من تنفيذ فعلي مكتمل.";
        }
        catch (Exception ex)
        {
            StatusLabel.Text = $"تعذر فتح مستند التسليم: {ex.Message}";
            ErrorLog.Write(ex, "ProductionDelivery.LoadDelivery");
        }
        finally { _loading = false; }
    }

    private void PopulateRows(ActualDeliveryOrderDto order, ProductionDeliveryCard card)
    {
        ClearRows();
        bool draft = card == null || card.Status == DocStatuses.Draft;
        var currentLines = card?.Lines ?? new List<ProductionDeliveryLineRow>();
        var matched = new HashSet<int>();
        foreach (var source in _sourceContext.Lines)
        {
            var current = currentLines.FirstOrDefault(l => l.ByProductId == source.ByProductId
                && l.ProductId == source.ProductId && l.LotId == source.LotId
                && l.CustomerId == source.CustomerId && l.PackagingTypeId == source.PackagingTypeId);
            if (current != null) matched.Add(current.Id);
            double qty = current?.QtyKg ?? (card == null && source.ByProductId == null ? source.RemainingQtyKg : 0);
            int packages = current?.PackageCount ?? (card == null && source.ByProductId == null ? source.RemainingPackageCount : 0);
            double remaining = Math.Max(0, source.AvailableQtyKg - source.StockReceivedQtyKg);
            var row = new DeliveryEditRow
            {
                ItemId = current?.Id ?? 0,
                ProductId = source.ProductId,
                ByProductId = source.ByProductId,
                LotId = source.LotId,
                CustomerId = source.CustomerId,
                PackagingTypeId = source.PackagingTypeId,
                Product = source.ProductName,
                Customer = source.CustomerName ?? "—",
                Specification = source.ByProductId != null ? "مخرج ثانوي / كجم" : BuildSpecification(source),
                Lot = source.LotCode ?? "—",
                Unit = source.Unit,
                OutputType = source.ByProductId == null ? "منتج تام" : "مخرج ثانوي",
                MappingStatus = source.ByProductId == null ? "منتج تام" : "لا يوجد ربط مخزني معتمد؛ لا يمكن التسليم أو الاستلام",
                CanDeliver = draft && source.ByProductId == null && source.ProductId > 0,
                PlannedKg = source.PlannedQtyKg,
                PlannedCartons = source.PlannedCartons,
                ActualKg = source.AvailableQtyKg,
                ActualCartons = source.ActualCartons,
                PreviouslyDeliveredKg = Math.Max(0, source.StockReceivedQtyKg - (current?.ReceivedQtyKg ?? 0)),
                ExistingDocumentReceivedKg = current?.ReceivedQtyKg ?? 0,
                RemainingKg = remaining,
                QtyKg = qty,
                PackageCount = packages,
                WarehouseId = current?.WarehouseId,
                WarehouseName = source.ByProductId != null ? "غير متاح دون ربط مخزني" : current?.WarehouseName ?? "—",
                Notes = ""
            };
            if (source.ByProductId == null) _finishedRows.Add(row);
            else _secondaryRows.Add(row);
        }

        // تظهر نتيجة الفاقد الفعلية كما سُجلت في التنفيذ، لكنها غير قابلة للتحويل
        // إلى صنف مخزني لأن تصنيف KindLoss في المشروع لا يدخل المخزون.
        double wastage = order?.WastageQtyKg ?? card?.WastageQtyKg ?? 0;
        if (wastage > 0.001)
            _secondaryRows.Add(new DeliveryEditRow
            {
                Product = "فاقد تشغيل مسجل في التنفيذ",
                OutputType = "فاقد غير مخزني",
                Unit = "كجم",
                ActualKg = wastage,
                PreviouslyDeliveredKg = 0,
                RemainingKg = 0,
                QtyKg = 0,
                PackageCount = 0,
                CanDeliver = false,
                IsLoss = true,
                MappingStatus = "تصنيف خسارة غير مخزني؛ لا يُرحّل إلى الأرصدة",
                Notes = "القيمة للعرض فقط ولا تُعدّل من شاشة التسليم."
            });

        // تاريخياً، قد توجد بنود لا يقابلها سياق فعلي متاح (مستند قديم). نعرضها دون تمكين تعديلها.
        foreach (var line in currentLines.Where(l => !matched.Contains(l.Id)))
        {
            var row = new DeliveryEditRow
            {
                ItemId = line.Id,
                ProductId = line.ProductId,
                ByProductId = line.ByProductId,
                LotId = line.LotId,
                CustomerId = line.CustomerId,
                PackagingTypeId = line.PackagingTypeId,
                Product = line.ProductName,
                Customer = line.CustomerName ?? "—",
                Specification = line.PackagingName ?? "—",
                Lot = line.LotCode ?? "—",
                Unit = line.Unit,
                OutputType = line.ByProductId == null ? "منتج تام" : "مخرج ثانوي",
                PlannedKg = line.PlannedQtyKg,
                ActualKg = line.ActualQtyKg,
                PreviouslyDeliveredKg = line.PreviouslyReceivedQtyKg,
                ExistingDocumentReceivedKg = line.ReceivedQtyKg,
                RemainingKg = line.RemainingQtyKg,
                QtyKg = line.QtyKg,
                PackageCount = line.PackageCount,
                WarehouseId = line.WarehouseId,
                WarehouseName = line.WarehouseName ?? "—",
                CanDeliver = false,
                MappingStatus = "سطر تاريخي غير قابل للتعديل"
            };
            if (line.ByProductId == null) _finishedRows.Add(row); else _secondaryRows.Add(row);
        }
        ItemsGrid.IsReadOnly = !draft || !CanProduction("Edit");
        SecondaryGrid.IsReadOnly = true; // مخرجات فعلية للعرض فقط؛ لا يوجد ربط مخزني معتمد لها.
    }

    private static string BuildSpecification(DeliverySourceLine line)
    {
        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(line.PackagingName)) parts.Add(line.PackagingName);
        if (line.CartonWeightKg > 0.001) parts.Add($"{line.CartonWeightKg:N2} كجم/كرتون");
        return parts.Count == 0 ? "غير محددة" : string.Join(" · ", parts);
    }

    private void SetSummary(ActualDeliveryOrderDto order, ProductionDeliveryCard card)
    {
        var orderNo = card?.OrderNumber ?? order?.OrderNumber ?? "—";
        var customers = card?.CustomerSummary ?? order?.Customer ?? "—";
        var plan = card?.PlanNumber ?? order?.PlanNumber ?? "—";
        var date = card?.ProductionDate ?? order?.ProductionDate ?? "—";
        var shiftLine = string.Join(" / ", new[]
        {
            date,
            card?.ShiftName ?? order?.Shift ?? "وردية غير محددة",
            card?.LineName ?? order?.LineName ?? "خط غير محدد"
        }.Where(x => !string.IsNullOrWhiteSpace(x)));
        OrderChip.Text = $"أمر الإنتاج: {orderNo}";
        CustomerChip.Text = $"العملاء: {customers}";
        PlanChip.Text = $"الخطة: {plan}";
        ShiftLineChip.Text = $"التاريخ / الوردية / الخط: {shiftLine}";
        PlannedTotal.Text = $"{(card?.PlannedQtyKg ?? order?.PlannedQtyKg ?? _finishedRows.Sum(x => x.PlannedKg)):N1} كجم";
        ActualTotal.Text = $"{(card?.ActualQtyKg ?? order?.ActualQtyKg ?? _finishedRows.Sum(x => x.ActualKg)):N1} كجم";
        DeliveredTotal.Text = $"{(card?.StockReceivedQtyKg ?? order?.StockReceivedQtyKg ?? _finishedRows.Sum(x => x.PreviouslyDeliveredKg) + _secondaryRows.Sum(x => x.PreviouslyDeliveredKg)):N1} كجم";
        RemainingTotal.Text = $"{(order?.RemainingQtyKg ?? card?.Lines.Sum(l => l.RemainingQtyKg) ?? _finishedRows.Sum(x => x.RemainingKg)):N1} كجم";
        WastageTotal.Text = $"{(card?.WastageQtyKg ?? order?.WastageQtyKg ?? 0):N1} كجم";
    }

    private void NewDelivery()
    {
        if (_saving) return;
        if (_currentOrder is not { Recorded: true, ExecutionId: > 0 } order)
        {
            StatusLabel.Text = "اختر أمراً له تنفيذ فعلي مكتمل؛ هذه الشاشة لا تنشئ فعلياً ولا تعتمد على الخطة بدل الفعلي.";
            return;
        }
        if (!CanProduction("Create"))
        {
            StatusLabel.Text = "لا يمكن إنشاء مسودة: صلاحية production/Create مطلوبة.";
            return;
        }
        if (_currentDelivery?.Status == DocStatuses.Draft)
        {
            StatusLabel.Text = $"المسودة {_currentDelivery.DocumentNumber} مفتوحة بالفعل؛ عدّلها واحفظها بدلاً من إنشاء مستند مكرر.";
            return;
        }
        if (!order.CanCreateDelivery)
        {
            StatusLabel.Text = "لا توجد كمية فعلية متبقية غير مغطاة بأوامر تسليم غير ملغاة.";
            return;
        }
        try
        {
            var result = WithService(s => s.CreateDeliveryFromActual(order.ExecutionId,
                (DeliveryDateBox.SelectedDate ?? DateTime.Today).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture), NotesBox.Text));
            if (!result.Ok)
            {
                StatusLabel.Text = result.Message;
                return;
            }
            LoadData(order.OrderId, result.Id);
            StatusLabel.Text = result.Message + "\nالمسودة لا تنشئ حركة مخزون؛ وجّه كل بند إلى مخزنه قبل الحفظ والاعتماد.";
        }
        catch (Exception ex)
        {
            StatusLabel.Text = $"تعذر إنشاء مسودة التسليم: {ex.Message}";
            ErrorLog.Write(ex, "ProductionDelivery.NewDraft");
        }
    }

    private void EditSelected()
    {
        if (_currentDelivery?.Status != DocStatuses.Draft)
        {
            StatusLabel.Text = "التعديل متاح للمسودة فقط؛ المستند المعتمد للقراءة، ويُراجع بإجراءات الإلغاء المعتمدة.";
            return;
        }
        if (!CanProduction("Edit"))
        {
            StatusLabel.Text = "صلاحية production/Edit مطلوبة لتعديل المسودة.";
            return;
        }
        ItemsGrid.IsReadOnly = false;
        SecondaryGrid.IsReadOnly = true;
        StatusLabel.Text = $"المسودة {_currentDelivery.DocumentNumber} قابلة لتعديل المنتجات التامة فقط. المخرجات الثانوية والفاقد للعرض ولا تُرحّل بلا ربط مخزني معتمد.";
    }

    private void SaveDraft()
    {
        if (_saving) return;
        if (_currentDelivery == null || _currentDelivery.Id <= 0)
        {
            StatusLabel.Text = "أنشئ مسودة من أمر الإنتاج أولاً؛ الحفظ لا ينشئ مستنداً بلا مصدر فعلي.";
            return;
        }
        if (_currentDelivery.Status != DocStatuses.Draft)
        {
            StatusLabel.Text = "لا يمكن تعديل مستند بعد تحريره للمخزن أو استلامه.";
            return;
        }
        if (!CanProduction("Edit"))
        {
            StatusLabel.Text = "صلاحية production/Edit مطلوبة لحفظ مسودة التسليم.";
            return;
        }
        try
        {
            _saving = true;
            ItemsGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            ItemsGrid.CommitEdit(DataGridEditingUnit.Row, true);
            SecondaryGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            SecondaryGrid.CommitEdit(DataGridEditingUnit.Row, true);
            var items = _finishedRows.Concat(_secondaryRows)
                .Where(r => r.CanDeliver && r.QtyKg > 0.001)
                .Select(r => new ProductionDeliveryItemDto
                {
                    OrderId = _currentDelivery.OrderId ?? _currentOrder?.OrderId,
                    ProductId = r.ProductId,
                    LotId = r.LotId,
                    CustomerId = r.CustomerId,
                    PackagingTypeId = r.PackagingTypeId,
                    PackageCount = r.PackageCount,
                    WarehouseId = r.WarehouseId,
                    QtyKg = r.QtyKg
                }).ToList();
            if (items.Count == 0)
            {
                StatusLabel.Text = "أدخل كمية موجبة في بند صالح واحد على الأقل؛ الفاقد وغير المربوط لا يُرحّلان.";
                return;
            }
            string date = (DeliveryDateBox.SelectedDate ?? DateTime.Today).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            var result = WithService(s => s.UpdateDelivery(_currentDelivery.Id, date, items, NotesBox.Text));
            if (!result.Ok)
            {
                StatusLabel.Text = result.Message;
                return;
            }
            int id = _currentDelivery.Id;
            LoadData(_currentDelivery.OrderId ?? _currentOrder?.OrderId, id);
            StatusLabel.Text = result.Message + "\nلم تنشأ حركة مخزون؛ الاعتماد والتحرير للمخزن مرحلة مستقلة.";
        }
        catch (Exception ex)
        {
            StatusLabel.Text = $"تعذر حفظ المسودة: {ex.Message}";
            ErrorLog.Write(ex, "ProductionDelivery.SaveDraft");
        }
        finally { _saving = false; }
    }

    private void IssueDelivery()
    {
        if (_currentDelivery == null || _currentDelivery.Id <= 0)
        {
            StatusLabel.Text = "افتح مسودة محفوظة قبل اعتمادها.";
            return;
        }
        if (_currentDelivery.Status != DocStatuses.Draft)
        {
            StatusLabel.Text = "المستند ليس مسودة؛ لا يمكن تكرار الاعتماد.";
            return;
        }
        if (!CanProduction("Approve"))
        {
            StatusLabel.Text = "صلاحية production/Approve مطلوبة لتحرير أمر التسليم.";
            return;
        }
        if (!AppContainer.Get<DialogService>().Confirm(
            $"سيُحرر أمر التسليم {_currentDelivery.DocumentNumber} للمخزن. هذا الاعتماد لا يرحّل المخزون؛ على أمين المخزن إنشاء/تنفيذ سند استلام منفصل. متابعة؟")) return;
        try
        {
            var result = WithService(s => s.IssueDelivery(_currentDelivery.Id));
            if (!result.Ok)
            {
                StatusLabel.Text = result.Message;
                return;
            }
            int id = _currentDelivery.Id;
            int? orderId = _currentDelivery.OrderId ?? _currentOrder?.OrderId;
            LoadData(orderId, id);
            StatusLabel.Text = result.Message + "\nلم تتغير الأرصدة. استخدم «استلام مخزني» لإكمال المرحلة المخزنية بصلاحيتها.";
        }
        catch (Exception ex)
        {
            StatusLabel.Text = $"تعذر تحرير أمر التسليم: {ex.Message}";
            ErrorLog.Write(ex, "ProductionDelivery.Issue");
        }
    }

    private void CancelDelivery()
    {
        if (_currentDelivery == null || _currentDelivery.Id <= 0)
        {
            StatusLabel.Text = "اختر مستند تسليم محفوظاً لإلغائه.";
            return;
        }
        if (!CanProduction("Cancel"))
        {
            StatusLabel.Text = "صلاحية production/Cancel مطلوبة.";
            return;
        }
        if (!AppContainer.Get<DialogService>().Confirm(
            $"سيُلغى أمر التسليم {_currentDelivery.DocumentNumber} وفق قواعد الخدمة. لا يُحذف أي سجل، وأي استلام قائم يجب عكسه أولاً. متابعة؟")) return;
        try
        {
            var result = WithService(s => s.CancelDelivery(_currentDelivery.Id));
            if (!result.Ok)
            {
                StatusLabel.Text = result.Message;
                return;
            }
            int id = _currentDelivery.Id;
            int? orderId = _currentDelivery.OrderId ?? _currentOrder?.OrderId;
            LoadData(orderId, id);
            StatusLabel.Text = result.Message;
        }
        catch (Exception ex)
        {
            StatusLabel.Text = $"تعذر إلغاء أمر التسليم: {ex.Message}";
            ErrorLog.Write(ex, "ProductionDelivery.Cancel");
        }
    }

    private void OpenWarehouseReceipt()
    {
        if (_currentDelivery == null || _currentDelivery.Id <= 0)
        {
            StatusLabel.Text = "احفظ أمر التسليم واعتمده قبل فتح الاستلام المخزني.";
            return;
        }
        if (_currentDelivery.Status == DocStatuses.Draft)
        {
            StatusLabel.Text = "أمر التسليم ما زال مسودة؛ حرّره للمخزن أولاً. التحرير لا يرحّل المخزون.";
            return;
        }
        if (_currentDelivery.Status == DocStatuses.Cancelled)
        {
            StatusLabel.Text = "لا يمكن الاستلام من أمر ملغى.";
            return;
        }
        if (!CanFinishedGoods("Create"))
        {
            StatusLabel.Text = "صلاحية finishedgoods/Create مطلوبة لإنشاء سند الاستلام المخزني.";
            return;
        }
        FGReceiveView.PendingDeliveryId = _currentDelivery.Id;
        (Window.GetWindow(this) as MainWindow)?.OpenScreen("fgreceive");
    }

    private void Search_Click(object sender, RoutedEventArgs e)
    {
        var term = (SearchBox.Text ?? "").Trim();
        var orderMatches = string.IsNullOrWhiteSpace(term) ? _orders : _orders.Where(o =>
            Contains(o.OrderNumber, term) || Contains(o.Label, term) || Contains(o.Customer, term)
            || Contains(o.PlanNumber, term) || Contains(o.ProductionDate, term)).ToList();
        var deliveryMatches = string.IsNullOrWhiteSpace(term) ? _deliveries : _deliveries.Where(d =>
            Contains(d.DocumentNumber, term) || Contains(d.OrderNumber, term) || Contains(d.SourceNumber, term)
            || Contains(d.CustomerSummary, term) || Contains(d.StatusAr, term)).ToList();
        _loading = true;
        OrderBox.ItemsSource = orderMatches;
        DeliveryBox.ItemsSource = deliveryMatches;
        OrderBox.SelectedIndex = -1;
        DeliveryBox.SelectedIndex = -1;
        _loading = false;

        var exactDelivery = deliveryMatches.FirstOrDefault(d => string.Equals(d.DocumentNumber, term, StringComparison.OrdinalIgnoreCase));
        if (exactDelivery != null)
        {
            DeliveryBox.SelectedItem = exactDelivery;
            LoadDelivery(exactDelivery.Id);
            return;
        }
        var exactOrder = orderMatches.FirstOrDefault(o => string.Equals(o.OrderNumber, term, StringComparison.OrdinalIgnoreCase));
        if (exactOrder != null)
        {
            OrderBox.SelectedItem = exactOrder;
            LoadOrder(exactOrder);
            return;
        }
        StatusLabel.Text = string.IsNullOrWhiteSpace(term)
            ? "تم عرض الأوامر والمستندات المحفوظة. اختر أحدها للفتح."
            : $"نتائج البحث: {orderMatches.Count} أمر إنتاج و{deliveryMatches.Count} مستند تسليم. اختر من القوائم أعلاه.";
    }

    private static bool Contains(string value, string term)
        => !string.IsNullOrWhiteSpace(value) && value.Contains(term, StringComparison.CurrentCultureIgnoreCase);

    private void ClearSearch_Click(object sender, RoutedEventArgs e)
    {
        SearchBox.Text = "";
        LoadData(_currentOrder?.OrderId, _currentDelivery?.Id > 0 ? _currentDelivery.Id : null);
    }

    private void Undo()
    {
        if (_currentDelivery?.Id > 0)
        {
            LoadDelivery(_currentDelivery.Id);
            return;
        }
        if (_currentOrder != null)
        {
            var order = _orders.FirstOrDefault(o => o.OrderId == _currentOrder.OrderId) ?? _currentOrder;
            LoadOrder(order);
            return;
        }
        ClearRows();
        StatusLabel.Text = "لا توجد إدخالات غير محفوظة للتراجع عنها.";
    }

    private void Print()
    {
        if (_currentDelivery?.Id <= 0)
        {
            StatusLabel.Text = "اختر مستند تسليم محفوظاً؛ الطباعة لا تستخدم قيماً غير محفوظة.";
            return;
        }
        try
        {
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErp.Infrastructure.Persistence.DatesErpDbContext>();
            var model = Printing.StoredPrintModels.ProductionDelivery(db, _currentDelivery.Id);
            new PrintPreviewWindow(PhasePrint.Build(model), $"{model.DocTitle} {model.DocNo}")
            { Owner = Window.GetWindow(this) }.ShowDialog();
        }
        catch (Exception ex)
        {
            StatusLabel.Text = $"تعذرت طباعة أمر التسليم: {ex.Message}";
            ErrorLog.Write(ex, "ProductionDelivery.Print");
        }
    }

    private void ClearRows()
    {
        _finishedRows.Clear();
        _secondaryRows.Clear();
    }

    private static string ReceiptStatusAr(string state) => state switch
    {
        "Full" => "مستلم بالكامل",
        "Partial" => "مستلم جزئياً",
        _ => "لم يبدأ الاستلام"
    };

    private void Grid_SingleClickEdit(object sender, MouseButtonEventArgs e)
    {
        if (sender is not DataGrid grid || grid.IsReadOnly) return;
        var dep = e.OriginalSource as DependencyObject;
        while (dep is not null and not DataGridCell) dep = VisualTreeHelper.GetParent(dep);
        if (dep is DataGridCell { IsReadOnly: false, IsEditing: false } cell)
        {
            grid.CommitEdit(DataGridEditingUnit.Row, true);
            grid.CurrentCell = new DataGridCellInfo(cell);
            grid.BeginEdit();
        }
    }
}
