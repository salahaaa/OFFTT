إصلاح خطأ حفظ الخطة — LINQ Math.Max لا يُترجم
==========================================
التاريخ: 2026-09-17
الخطأ المبلغ:
The LINQ expression 'DbSet<RawTreatment>.Where(r => r.LotId == ... && r.Status == "InProgress" && r.ExpectedReadyAt <= ...).Sum(r => Math.Max(0, r.QtyKg - r.ReleasedQtyKg - r.RejectedQtyKg))' could not be translated.
Translation of method 'System.Math.Max' failed.

الموقع:
src/DatesErp.Application/Services/PlanningService.cs:1015-1016
في دالة ResolveSourceDraw التي تُستدعى عند SavePlan/UpdatePlan

السبب:
EF Core لا يستطيع ترجمة Math.Max داخل Sum على استعلام خادمي (server evaluation).
يجب تحويله لتقييم عميل (client evaluation) عبر ToList() ثم Sum مع Math.Max

الحل المطبق:
قبل:
  var maturing = Db.RawTreatments.AsNoTracking()
      .Where(t => t.LotId == lotId && t.Status == InProgress && t.ExpectedReadyAt <= end)
      .Sum(t => Math.Max(0, t.QtyKg - t.ReleasedQtyKg - t.RejectedQtyKg));

بعد:
  var maturing = Db.RawTreatments.AsNoTracking()
      .Where(t => t.LotId == lotId && t.Status == InProgress && t.ExpectedReadyAt <= end)
      .Select(t => t.QtyKg - t.ReleasedQtyKg - t.RejectedQtyKg)
      .ToList()
      .Sum(v => Math.Max(0, v));

النتيجة: حفظ الخطة يعمل بدون خطأ ترجمة LINQ، مع الحفاظ على منطق منع القيم السالبة.

الملفات في هذه الحزمة:
- PlanningService.cs (الإصلاح الأساسي)
- DeliveryView/PlanningView/ReceivingView.xaml.cs (إصلاحات الـ 6 أخطاء السابقة 1.50.69)

طريقة التركيب:
1. فك الضغط داخل UPDATE_WORK
2. dotnet build DatesErp.sln -c Release => 0 Error(s)
3. شغل UPDATE-EXISTING-INSTALL بات

Windows Installation NOT TESTED
