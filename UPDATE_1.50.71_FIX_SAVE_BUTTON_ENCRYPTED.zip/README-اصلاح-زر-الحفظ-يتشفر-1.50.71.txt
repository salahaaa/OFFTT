إصلاح زر الحفظ يتشفر في الخطط — 1.50.71
=====================================
المشكلة: زر الحفظ معطل (encrypted/disabled) بعد التحديث الأخير

السبب: SaveBtn.IsEnabled = !locked && _capacityValid
و _capacityValid يتطلب IsValid + completeRows>0
فلا يستطيع المستخدم الضغط ليرى سبب الرفض

الحل:
- الزر مفعل ما دام هناك بند له هوية (LotId/ProductId)
- التحقق الحقيقي في Save_Click والـ Backend
- يحافظ على منع الحفظ الفارغ

الملفات:
- PlanningView.xaml.cs
- PlanningView.Capacity.cs
- PlanningService.cs (Math.Max fix)
- DeliveryView/ReceivingView (6 errors fix)

التركيب: فك الضغط داخل UPDATE_WORK ثم dotnet build ثم UPDATE-EXISTING-INSTALL

Windows NOT TESTED
