using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Views.Screens;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace DatesErp.Tests;

/// <summary>
/// A draft may be saved when a finished-to-raw identity exists but no official quantitative
/// factor is available. Such a draft must never manufacture a 1:1 allocation or enter approval.
/// </summary>
public sealed class PlanningPendingRawFormulaTests
{
    private const int FinishedKhalas = 3;
    private const int RawKhalas = 1;
    private const int Customer = 1;
    private const string WorkDay = "2026-11-01";

    private sealed record RawLot(int Id, int WarehouseId);

    private static T Svc<T>(TestHost host) where T : notnull
        => host.Services.CreateScope().ServiceProvider.GetRequiredService<T>();

    private static DatesErpDbContext FreshDb(TestHost host)
        => new(new DbContextOptionsBuilder<DatesErpDbContext>().UseSqlite(host.Connection).Options);

    private static RawLot ReceiveRawLot(TestHost host, int rawProductId = RawKhalas)
    {
        var receiving = Svc<IReceivingService>(host);
        var shipment = receiving.SaveShipment(Customer, null, null, new List<ShipmentItemDto>
        {
            new()
            {
                TreatmentRequired = false,
                ProductId = rawProductId,
                QtyKg = 200,
                PackageCount = 10,
                UnitWeightKg = 20,
                ReceiptUnit = "سلة"
            }
        });
        Assert.True(shipment.Ok, shipment.Message);
        Assert.True(receiving.ApproveShipment(shipment.Id).Ok);

        using var db = FreshDb(host);
        var lot = db.Lots.Single(l => l.ShipmentId == shipment.Id && l.ProductId == rawProductId);
        var warehouseId = db.Shipments.Where(s => s.Id == shipment.Id)
            .Select(s => s.ReceivingWarehouseId).FirstOrDefault()
            ?? db.Warehouses.Where(w => w.WarehouseCode == "WRM").Select(w => w.Id).Single();
        return new RawLot(lot.Id, warehouseId);
    }

    private static PlanItemDto DraftItem(RawLot lot, bool includeUntrusted1To1Values = true)
        => new()
        {
            SourceType = "FromReceiving",
            LotId = lot.Id,
            SelectedRawProductId = RawKhalas,
            CustomerId = Customer,
            ProductId = FinishedKhalas,
            PlannedCartons = 2,
            PlannedQtyKg = 15,
            ScheduledDate = WorkDay,
            SuggestedShiftId = 1,
            SuggestedLineId = 1,
            SourceUnit = includeUntrusted1To1Values ? "سلة" : null,
            SourceQtyInUnit = includeUntrusted1To1Values ? 0.75 : 0,
            SourceUnitWeightKg = includeUntrusted1To1Values ? 20 : 0,
            SourceQtyKg = includeUntrusted1To1Values ? 15 : 0,
            Allocations = includeUntrusted1To1Values
                ? new List<PlanItemAllocationDto>
                {
                    new()
                    {
                        WarehouseId = lot.WarehouseId,
                        LotId = lot.Id,
                        CustomerId = Customer,
                        AllocatedQtyKg = 15 // Intentionally untrusted: finished kg is not raw kg.
                    }
                }
                : new List<PlanItemAllocationDto>()
        };

    [Fact]
    public void Missing_Formula_Saves_Unreserved_Draft_And_Blocks_Submission_Approval_And_Orders()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        var planning = Svc<IPlanningService>(host);

        var saved = planning.SavePlan("مسودة بمعامل معلق", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot) });

        Assert.True(saved.Ok, saved.Message);
        Assert.Contains("معلّق", saved.Message);
        Assert.Contains("لم يُنشأ تخصيص أو حجز أو سحب", saved.Message);
        var itemId = OnlyPlanItemId(host, saved.Id);
        AssertPendingItem(host, saved.Id, itemId, lot.Id);

        // Updating a draft also discards the UI's old 1:1 allocation/draw instead of persisting it.
        var updated = planning.UpdatePlan(saved.Id, "مسودة محدّثة", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot) }, scopeMode: "Multi");
        Assert.True(updated.Ok, updated.Message);
        Assert.Contains("معامل تحويل", updated.Message);
        itemId = OnlyPlanItemId(host, saved.Id);
        AssertPendingItem(host, saved.Id, itemId, lot.Id);

        Assert.False(planning.SubmitPlan(saved.Id).Ok);
        Assert.False(planning.ApprovePlan(saved.Id).Ok);
        using (var db = FreshDb(host))
            Assert.False(db.ProductionPlans.Single(p => p.Id == saved.Id).IsApproved);
        var orders = Svc<IProductionOrderService>(host);
        Assert.Empty(orders.GetOrderableItems(saved.Id));
        var issue = orders.IssueOrdersFromPlan(saved.Id);
        Assert.False(issue.Ok);
        Assert.Empty(issue.Created);

        var orderItem = new OrderItemDto
        {
            PlanItemId = itemId,
            CustomerId = Customer,
            ProductId = FinishedKhalas,
            LotId = lot.Id,
            PlannedCartons = 2,
            PlannedQtyKg = 15
        };
        var order = orders.SaveOrder(
            "FromPlan", saved.Id, Customer, WorkDay, 1, 1, new List<OrderItemDto> { orderItem });
        Assert.False(order.Ok);
        Assert.Contains("غير معتمدة", order.Message);
        using (var db = FreshDb(host))
            Assert.Empty(db.ProductionOrders);

        // Simulate a legacy/imported approved header: order services must still refuse a
        // formula-pending item rather than trusting status alone.
        using (var db = FreshDb(host))
        {
            var plan = db.ProductionPlans.Single(p => p.Id == saved.Id);
            plan.IsApproved = true;
            plan.Status = "Approved";
            db.SaveChanges();
        }
        Assert.Empty(orders.GetOrderableItems(saved.Id));
        Assert.Empty(orders.GetPendingPlanGroups());
        var today = orders.GetTodayProduction();
        Assert.False(today.CanIssue);
        Assert.Contains("معامل تحويل خام معتمد", today.Rows.Single().Status);
        var legacyIssue = orders.IssueOrdersFromPlan(saved.Id);
        Assert.False(legacyIssue.Ok);
        Assert.Empty(legacyIssue.Created);
        var scheduledDate = new DateTime(2026, 11, 1).ToString("dd/MM/yyyy");
        var planGroupIssue = orders.IssuePlanGroup(saved.Id, scheduledDate, Customer, 1, 1);
        Assert.False(planGroupIssue.Ok);
        Assert.Contains("معامل تحويل خام معتمد", planGroupIssue.Message);
        var multiCustomerIssue = orders.IssuePlanMultiCustomerGroup(saved.Id, scheduledDate, 1, 1);
        Assert.False(multiCustomerIssue.Ok);
        Assert.Contains("معامل تحويل خام معتمد", multiCustomerIssue.Message);
        var todayGroupIssue = orders.IssueTodayGroup(saved.Id, Customer, 1, 1);
        Assert.False(todayGroupIssue.Ok);
        Assert.Contains("معامل تحويل خام معتمد", todayGroupIssue.Message);
        var legacyOrder = orders.SaveOrder(
            "FromPlan", saved.Id, Customer, WorkDay, 1, 1, new List<OrderItemDto> { orderItem });
        Assert.False(legacyOrder.Ok);
        Assert.Contains("معامل تحويل خام معتمد", legacyOrder.Message);
        var todayIssue = orders.IssueTodayOrders();
        Assert.False(todayIssue.Ok);
        using (var db = FreshDb(host))
            Assert.Empty(db.ProductionOrders);
    }

    [Fact]
    public void Draft_Still_Rejects_A_Raw_Lot_That_Does_Not_Match_The_Product_Link()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var wrongLot = ReceiveRawLot(host, rawProductId: 2);
        int before;
        using (var db = FreshDb(host)) before = db.ProductionPlans.Count();

        var result = Svc<IPlanningService>(host).SavePlan("مصدر خام خاطئ", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(wrongLot) });

        Assert.False(result.Ok);
        Assert.Contains("لا يطابق", result.Message);
        using (var db = FreshDb(host))
            Assert.Equal(before, db.ProductionPlans.Count());
    }

    [Fact]
    public void Official_Factor_Allows_Draft_Recalculation_And_Approval_Without_1To1_Assumption()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        var planning = Svc<IPlanningService>(host);
        var draft = planning.SavePlan("مسودة أولية", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot, includeUntrusted1To1Values: false) });
        Assert.True(draft.Ok, draft.Message);
        AssertPendingItem(host, draft.Id, OnlyPlanItemId(host, draft.Id), lot.Id);

        // This is an explicit test fixture conversion, not a production default or inferred ratio.
        using (var db = FreshDb(host))
        {
            var product = db.Products.Single(p => p.Id == FinishedKhalas);
            product.YieldFactor = 1.25; // official outside/inside yield => 0.8 kg raw per kg finished
            db.SaveChanges();
        }
        Assert.Equal(200, planning.GetProductLotRemaining(lot.Id, FinishedKhalas), 0.01);

        var recalculated = DraftItem(lot, includeUntrusted1To1Values: false);
        recalculated.SourceUnit = "سلة";
        recalculated.SourceUnitWeightKg = 20;
        recalculated.SourceQtyKg = 12;
        recalculated.Allocations.Add(new PlanItemAllocationDto
        {
            WarehouseId = lot.WarehouseId,
            LotId = lot.Id,
            CustomerId = Customer,
            AllocatedQtyKg = 12
        });
        var updated = planning.UpdatePlan(draft.Id, "مسودة محسوبة", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { recalculated }, scopeMode: "Multi");
        Assert.True(updated.Ok, updated.Message);

        using (var db = FreshDb(host))
        {
            var item = db.ProductionPlanItems.Include(i => i.Allocations).Single(i => i.PlanId == draft.Id);
            Assert.Equal(12, (double)item.RawRequiredQtyKg, 0.01);
            Assert.Equal("سلة", item.SourceUnit);
            Assert.Equal(12, item.SourceQtyKg, 0.01);
            Assert.Equal(0.6, item.SourceQtyInUnit, 0.01);
            Assert.Equal(12, item.Allocations.Sum(a => a.AllocatedQtyKg), 0.01);
            Assert.Equal(12, db.Lots.Single(l => l.Id == lot.Id).ReservedQtyKg, 0.01);
        }
        Assert.True(planning.SubmitPlan(draft.Id).Ok);
        Assert.True(planning.ApprovePlan(draft.Id).Ok);
        var orders = Svc<IProductionOrderService>(host);
        Assert.Single(orders.GetOrderableItems(draft.Id));
        var order = orders.SaveOrder("FromPlan", draft.Id, Customer, WorkDay, 1, 1,
            new List<OrderItemDto>
            {
                new()
                {
                    PlanItemId = OnlyPlanItemId(host, draft.Id),
                    CustomerId = Customer,
                    ProductId = FinishedKhalas,
                    LotId = lot.Id,
                    PlannedCartons = 2,
                    PlannedQtyKg = 15
                }
            });
        Assert.True(order.Ok, order.Message);
    }

    [Fact]
    public void Update_To_Pending_Formula_Releases_The_Old_Raw_Reservation_And_Draw()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        using (var db = FreshDb(host))
        {
            var product = db.Products.Single(p => p.Id == FinishedKhalas);
            product.YieldFactor = 1.25;
            db.SaveChanges();
        }

        var planning = Svc<IPlanningService>(host);
        var official = DraftItem(lot, includeUntrusted1To1Values: false);
        official.SourceUnit = "سلة";
        official.SourceUnitWeightKg = 20;
        official.SourceQtyKg = 12;
        official.Allocations.Add(new PlanItemAllocationDto
        {
            WarehouseId = lot.WarehouseId,
            LotId = lot.Id,
            CustomerId = Customer,
            AllocatedQtyKg = 12
        });
        var saved = planning.SavePlan("خطة بمعامل", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { official });
        Assert.True(saved.Ok, saved.Message);
        using (var db = FreshDb(host))
            Assert.Equal(12, db.Lots.Single(l => l.Id == lot.Id).ReservedQtyKg, 0.01);

        using (var db = FreshDb(host))
        {
            var product = db.Products.Single(p => p.Id == FinishedKhalas);
            product.YieldFactor = null;
            db.SaveChanges();
        }
        var updated = planning.UpdatePlan(saved.Id, "مسودة بانتظار المعامل", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot) }, scopeMode: "Multi");
        Assert.True(updated.Ok, updated.Message);
        Assert.Contains("معامل تحويل", updated.Message);
        AssertPendingItem(host, saved.Id, OnlyPlanItemId(host, saved.Id), lot.Id);
        Assert.False(planning.SubmitPlan(saved.Id).Ok);
        Assert.False(planning.ApprovePlan(saved.Id).Ok);
    }

    [Fact]
    public void Raw_Need_Display_Does_Not_Fall_Back_To_Finished_Quantity()
    {
        var row = new LotEditorRow
        {
            AllProducts = new List<ProductOption>
            {
                new() { Id = FinishedKhalas, Name = "خلاص تام", CartonWeightKg = 7.5 }
            }
        };
        row.ProductId = FinishedKhalas;
        row.CartonsText = "2";

        Assert.Equal(15, row.ComputedKg, 0.01);
        Assert.Equal(0, row.RawRequiredKg, 0.001);
        Assert.Equal(0, row.SelectedQtyKg, 0.001);
        Assert.Equal("غير محسوب", row.SelectedQtyDisplay);

        var savedRow = new PlanRowUi
        {
            ItemId = 10,
            ProductId = FinishedKhalas,
            QtyKg = 15,
            SourceQtyKg = 15,
            AllocationSelectedQtyKg = 15,
            SavedRawRequiredKg = 15
        };
        Assert.Equal(0, savedRow.RawRequiredKg, 0.001);
        Assert.Equal("غير محسوب", savedRow.RawNeedDisplay);
        Assert.Contains("المعامل مفقود", savedRow.RawPlanStatus);
    }

    private static int OnlyPlanItemId(TestHost host, int planId)
    {
        using var db = FreshDb(host);
        return db.ProductionPlanItems.Where(i => i.PlanId == planId).Select(i => i.Id).Single();
    }

    private static void AssertPendingItem(TestHost host, int planId, int itemId, int lotId)
    {
        using var db = FreshDb(host);
        var item = db.ProductionPlanItems.Include(i => i.Allocations)
            .Single(i => i.Id == itemId && i.PlanId == planId);
        Assert.Equal(0, (double)item.RawRequiredQtyKg, 0.001);
        Assert.Empty(item.Allocations);
        Assert.Null(item.SourceUnit);
        Assert.Equal(0, item.SourceQtyInUnit, 0.001);
        Assert.Equal(0, item.SourceUnitWeightKg, 0.001);
        Assert.Equal(0, item.SourceQtyKg, 0.001);
        Assert.Equal(0, db.Lots.Single(l => l.Id == lotId).ReservedQtyKg, 0.001);
        Assert.Equal("Draft", db.ProductionPlans.Single(p => p.Id == planId).Status);
    }
}
