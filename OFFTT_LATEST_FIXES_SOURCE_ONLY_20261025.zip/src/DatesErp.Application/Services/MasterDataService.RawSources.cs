using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Exceptions;
using DatesErp.Core.Interfaces.Services;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Application.Services;

/// <summary>عرض قاعدة خام رسمية في شاشة إدارة معاملات التحويل المركزية.</summary>
public sealed class ProductRawSourceInfo
{
    public int Id { get; init; }
    public int FinishedProductId { get; init; }
    public string FinishedProductName { get; init; }
    public int RawProductId { get; init; }
    public string RawProductName { get; init; }
    public decimal RawKgPerFinishedKg { get; init; }
    public int? PackagingTypeId { get; init; }
    public string PackagingName { get; init; }
    public int PriorityNo { get; init; }
    public bool IsActive { get; init; }
    public string Notes { get; init; }
}

/// <summary>
/// معاملات الخام تُدار مرة في البيانات الأساسية وتُقرأ تلقائياً في كل خطة؛
/// لا يحرر المخطط معامل التحويل أثناء إنشاء الخطة.
/// </summary>
public partial class MasterDataService
{
    public List<ProductRawSourceInfo> GetProductRawSources(int finishedProductId)
    {
        Require("products", "View");
        if (!Db.Products.AsNoTracking().Any(p => p.Id == finishedProductId && p.IsActive && p.ItemType == "Finished"))
            throw new DomainException("الصنف التام غير موجود أو غير نشط.");

        return (from rule in Db.ProductRawSources.AsNoTracking()
                where rule.FinishedProductId == finishedProductId
                join finished in Db.Products.AsNoTracking() on rule.FinishedProductId equals finished.Id
                join raw in Db.Products.AsNoTracking() on rule.RawProductId equals raw.Id
                join package in Db.PackagingTypes.AsNoTracking()
                    on rule.PackagingTypeId equals (int?)package.Id into packages
                from package in packages.DefaultIfEmpty()
                orderby rule.PriorityNo, raw.ProductNameAr, rule.PackagingTypeId
                select new ProductRawSourceInfo
                {
                    Id = rule.Id,
                    FinishedProductId = rule.FinishedProductId,
                    FinishedProductName = finished.ProductNameAr,
                    RawProductId = rule.RawProductId,
                    RawProductName = raw.ProductNameAr,
                    RawKgPerFinishedKg = rule.RawKgPerFinishedKg,
                    PackagingTypeId = rule.PackagingTypeId,
                    PackagingName = package == null ? "عام — كل العبوات" : package.PackageNameAr,
                    PriorityNo = rule.PriorityNo,
                    IsActive = rule.IsActive,
                    Notes = rule.Notes
                }).ToList();
    }

}
