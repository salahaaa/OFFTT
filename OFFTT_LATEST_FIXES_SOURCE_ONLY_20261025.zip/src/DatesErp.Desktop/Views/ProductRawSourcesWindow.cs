using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using DatesErp.Application.Services;
using DatesErp.Core.Domain.Entities;
using DatesErp.Desktop.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Desktop.Views;

/// <summary>
/// محرر مركزي لقواعد الخام للمنتج التام. تحفظ القاعدة مرةً في بيانات المنتج
/// (منتج تام × مصدر خام × عبوة اختيارية) وتُستهلك تلقائياً في كل خطة لاحقة.
/// </summary>
public sealed class ProductRawSourcesWindow : Window
{
    private sealed class Choice
    {
        public int? Id { get; init; }
        public string Name { get; init; }
        public override string ToString() => Name;
    }

    private readonly int _finishedProductId;
    private readonly MasterDataService _service;
    private readonly DatesErpDbContext _db;
    private readonly ComboBox _rawBox = new() { MinWidth = 230 };
    private readonly ComboBox _packageBox = new() { MinWidth = 205 };
    private readonly TextBox _factorBox = new() { MinWidth = 140 };
    private readonly TextBox _priorityBox = new() { MinWidth = 70, Text = "1" };
    private readonly TextBox _notesBox = new() { MinWidth = 250 };
    private readonly DataGrid _grid = new()
    {
        AutoGenerateColumns = false,
        IsReadOnly = true,
        CanUserAddRows = false,
        SelectionMode = DataGridSelectionMode.Single,
        MinHeight = 220,
        MaxHeight = 420,
        RowHeight = 32,
        Margin = new Thickness(0, 8, 0, 8)
    };
    private int? _editingId;

    public ProductRawSourcesWindow(int finishedProductId, string finishedProductName,
        MasterDataService service, DatesErpDbContext db)
    {
        _finishedProductId = finishedProductId;
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _db = db ?? throw new ArgumentNullException(nameof(db));

        Title = $"معاملات الخام الرسمية — {finishedProductName}";
        FlowDirection = FlowDirection.RightToLeft;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Width = Math.Min(1120, SystemParameters.WorkArea.Width - 24);
        Height = Math.Min(680, SystemParameters.WorkArea.Height - 36);
        MinWidth = 760;
        MinHeight = 460;
        SetResourceReference(Control.BackgroundProperty, "ThemeWindowBackgroundBrush");

        var panel = new StackPanel { Margin = new Thickness(14) };
        panel.Children.Add(new TextBlock
        {
            Text = "عرّف معامل الخام مرةً هنا لكل مصدر/عبوة؛ خطط الإنتاج تقرأه تلقائياً ولا تطلب تعديل الصنف أو المعامل في كل خطة.",
            FontWeight = FontWeights.Bold,
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 0, 0, 5)
        });
        panel.Children.Add(new TextBlock
        {
            Text = "المعامل المباشر = كجم خام لكل 1 كجم منتج تام. احتياج الخام = وزن الإنتاج التام × هذا المعامل. هذا المحرر لا يخمّن قيمة ولا يحوّل وحدات.",
            TextWrapping = TextWrapping.Wrap,
            Foreground = System.Windows.Media.Brushes.DarkSlateBlue,
            Margin = new Thickness(0, 0, 0, 10)
        });

        BuildGrid();
        panel.Children.Add(_grid);
        panel.Children.Add(BuildEditor());
        Content = panel;

        LoadLookups();
        RefreshRules();
        _grid.SelectionChanged += (_, _) => LoadSelectedRule();
    }

    private void BuildGrid()
    {
        _grid.Columns.Add(new DataGridTextColumn
        {
            Header = "مصدر الخام",
            Binding = new Binding(nameof(ProductRawSourceInfo.RawProductName)),
            Width = new DataGridLength(1.2, DataGridLengthUnitType.Star)
        });
        _grid.Columns.Add(new DataGridTextColumn
        {
            Header = "العبوة",
            Binding = new Binding(nameof(ProductRawSourceInfo.PackagingName)),
            Width = new DataGridLength(1.1, DataGridLengthUnitType.Star)
        });
        _grid.Columns.Add(new DataGridTextColumn
        {
            Header = "كجم خام / كجم تام",
            Binding = new Binding(nameof(ProductRawSourceInfo.RawKgPerFinishedKg)) { StringFormat = "N4" },
            Width = 150
        });
        _grid.Columns.Add(new DataGridTextColumn
        {
            Header = "الأولوية",
            Binding = new Binding(nameof(ProductRawSourceInfo.PriorityNo)),
            Width = 75
        });
        _grid.Columns.Add(new DataGridTextColumn
        {
            Header = "الحالة",
            Binding = new Binding(nameof(ProductRawSourceInfo.IsActive)) { Converter = new ActiveStateConverter() },
            Width = 90
        });
        _grid.Columns.Add(new DataGridTextColumn
        {
            Header = "ملاحظة",
            Binding = new Binding(nameof(ProductRawSourceInfo.Notes)),
            Width = new DataGridLength(1.4, DataGridLengthUnitType.Star)
        });
    }

    private UIElement BuildEditor()
    {
        var editor = new StackPanel();
        var fields = new WrapPanel { Margin = new Thickness(0, 4, 0, 4) };
        fields.Children.Add(Field("مصدر الخام", _rawBox));
        fields.Children.Add(Field("العبوة (اختياري)", _packageBox));
        fields.Children.Add(Field("كجم خام لكل كجم تام *", _factorBox));
        fields.Children.Add(Field("الأولوية", _priorityBox));
        fields.Children.Add(Field("ملاحظة", _notesBox));
        editor.Children.Add(fields);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
        buttons.Children.Add(MakeButton("➕ قاعدة جديدة", "ErpButton", (_, _) => ResetEditor()));
        buttons.Children.Add(MakeButton("💾 حفظ / تحديث المعامل", "ErpPrimaryButton", SaveRule_Click));
        buttons.Children.Add(MakeButton("🔄 تحديث", "ErpButton", (_, _) => RefreshRules()));
        buttons.Children.Add(MakeButton("إغلاق", "ErpButton", (_, _) => Close()));
        editor.Children.Add(buttons);
        return editor;
    }

    private static StackPanel Field(string label, FrameworkElement control)
    {
        var stack = new StackPanel { Margin = new Thickness(0, 0, 12, 4) };
        stack.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 3) });
        stack.Children.Add(control);
        return stack;
    }

    private static Button MakeButton(string caption, string styleKey, RoutedEventHandler handler)
    {
        var button = new Button
        {
            Content = caption,
            Style = (Style)Application.Current.FindResource(styleKey),
            Margin = new Thickness(0, 0, 7, 0),
            Padding = new Thickness(9, 5, 9, 5)
        };
        button.Click += handler;
        return button;
    }

    private void LoadLookups()
    {
        var raws = _db.Products.AsNoTracking()
            .Where(p => p.IsActive && p.ItemType == "Raw")
            .OrderBy(p => p.ProductNameAr)
            .Select(p => new Choice { Id = p.Id, Name = p.ProductNameAr + " (" + p.ProductCode + ")" })
            .ToList();
        _rawBox.ItemsSource = raws;
        _rawBox.DisplayMemberPath = nameof(Choice.Name);
        _rawBox.SelectedValuePath = nameof(Choice.Id);

        var packages = new List<Choice> { new() { Id = null, Name = "عام — كل العبوات" } };
        packages.AddRange(_db.PackagingTypes.AsNoTracking()
            .Where(p => p.IsActive)
            .OrderBy(p => p.PackageNameAr)
            .Select(p => new Choice { Id = p.Id, Name = p.PackageNameAr })
            .ToList());
        _packageBox.ItemsSource = packages;
        _packageBox.DisplayMemberPath = nameof(Choice.Name);
        _packageBox.SelectedValuePath = nameof(Choice.Id);
        _packageBox.SelectedIndex = 0;
    }

    private void RefreshRules()
    {
        try
        {
            _grid.ItemsSource = _service.GetProductRawSources(_finishedProductId);
            _grid.SelectedItem = null;
        }
        catch (Exception ex)
        {
            AppContainer.Get<DialogService>().HandleException(ex, "ProductRawSources.Refresh");
        }
    }

    private void LoadSelectedRule()
    {
        if (_grid.SelectedItem is not ProductRawSourceInfo rule) return;
        _editingId = rule.Id;
        _rawBox.SelectedValue = rule.RawProductId;
        if (rule.PackagingTypeId == null) _packageBox.SelectedIndex = 0;
        else _packageBox.SelectedValue = rule.PackagingTypeId;
        _factorBox.Text = rule.RawKgPerFinishedKg.ToString("0.####", CultureInfo.CurrentCulture);
        _priorityBox.Text = rule.PriorityNo.ToString(CultureInfo.CurrentCulture);
        _notesBox.Text = rule.Notes ?? "";
    }

    private void ResetEditor()
    {
        _editingId = null;
        _grid.SelectedItem = null;
        _rawBox.SelectedIndex = -1;
        _packageBox.SelectedIndex = 0;
        _factorBox.Clear();
        _priorityBox.Text = "1";
        _notesBox.Clear();
        _rawBox.Focus();
    }

    private void SaveRule_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_rawBox.SelectedValue is not int rawId)
            {
                AppContainer.Get<DialogService>().Error("اختر مصدر الخام الرسمي.");
                return;
            }
            if (!TryReadFactor(_factorBox.Text, out var factor) || factor <= 0)
            {
                AppContainer.Get<DialogService>().Error("أدخل معامل تحويل رسمي موجباً: كجم خام لكل كجم منتج تام.");
                return;
            }
            if (_grid.SelectedItem is ProductRawSourceInfo inactiveRule && !inactiveRule.IsActive
                && !AppContainer.Get<DialogService>().Confirm(
                    "هذه القاعدة معطّلة. حفظها سيعيد تفعيلها للاستخدام في الخطط الجديدة. هل تريد المتابعة؟"))
                return;
            int? packageId = _packageBox.SelectedValue is int selectedPackage ? selectedPackage : null;
            int priority = int.TryParse(_priorityBox.Text, NumberStyles.Integer, CultureInfo.CurrentCulture, out var parsedPriority)
                ? Math.Max(1, parsedPriority) : 1;
            var result = _service.SaveProductRawSource(_editingId, _finishedProductId, rawId, factor,
                packageId, priority, true, _notesBox.Text?.Trim());
            if (!result.Ok)
            {
                AppContainer.Get<DialogService>().Error(result.Message);
                return;
            }
            AppContainer.Get<DialogService>().Info(result.Message);
            RefreshRules();
            ResetEditor();
        }
        catch (Exception ex)
        {
            AppContainer.Get<DialogService>().HandleException(ex, "ProductRawSources.Save");
        }
    }

    private static bool TryReadFactor(string text, out decimal factor)
    {
        if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.CurrentCulture, out factor)) return true;
        return decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out factor);
    }

    private sealed class ActiveStateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool active ? (active ? "فعّال" : "معطّل") : "—";

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => Binding.DoNothing;
    }
}
