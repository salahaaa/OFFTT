using System.Diagnostics;
using System.IO.Compression;
using System.Security.Cryptography;

namespace DateErp.SafeUpdater;

public sealed record UpdateInspection(
    string PackageFileName,
    string Sha256,
    string CurrentVersion,
    int FileCount,
    long ExpandedBytes,
    long MainExecutableBytes);

public sealed record UpdateResult(
    string BackupDirectory,
    string Sha256,
    string PreviousVersion,
    string InstalledVersion);

/// <summary>
/// Offline updater for one explicitly approved publish directory. It never downloads a package,
/// reads connection settings, touches a database, force-kills the ERP, or removes the old publish.
/// </summary>
public static class UpdateEngine
{
    public const string TargetDirectory = @"C:\Users\LENOVO\.gemini\antigravity-ide\scratch\DateERP\publish";

    private const long MaxEntryBytes = 1_000_000_000;
    private const long MaxExpandedBytes = 2_000_000_000;
    private const int MaxArchiveFiles = 20_000;
    private const int GracefulCloseMilliseconds = 20_000;
    private static readonly HashSet<string> ForbiddenDatabaseExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".db", ".sqlite", ".sqlite3", ".mdf", ".ldf", ".bak"
    };

    public static async Task<UpdateInspection> InspectPackageAsync(
        string packagePath,
        string expectedSha256,
        IProgress<string> progress = null,
        CancellationToken cancellationToken = default)
    {
        ValidateTargetDirectory();
        var fullPackagePath = ValidatePackagePath(packagePath);
        var expected = NormalizeExpectedHash(expectedSha256);
        progress?.Report("جارٍ حساب SHA-256 للحزمة…");

        using var package = OpenPackageReadOnly(fullPackagePath);
        var actual = await ComputeSha256Async(package, cancellationToken).ConfigureAwait(false);
        VerifyHash(actual, expected);
        package.Position = 0;

        using var archive = new ZipArchive(package, ZipArchiveMode.Read, leaveOpen: true);
        var summary = ValidateArchive(archive);
        var currentVersion = ReadVersion(Path.Combine(TargetDirectory, "MfgSystem.exe"));
        progress?.Report("اكتمل الفحص: البصمة مطابقة وبنية الحزمة مقبولة.");
        return new UpdateInspection(
            Path.GetFileName(fullPackagePath),
            actual,
            currentVersion,
            summary.FileCount,
            summary.ExpandedBytes,
            summary.MainExecutableBytes);
    }

    public static async Task<UpdateResult> InstallPackageAsync(
        string packagePath,
        string expectedSha256,
        IProgress<string> progress = null,
        CancellationToken cancellationToken = default)
    {
        ValidateTargetDirectory();
        var fullPackagePath = ValidatePackagePath(packagePath);
        var expected = NormalizeExpectedHash(expectedSha256);
        var parentDirectory = Directory.GetParent(TargetDirectory)?.FullName
            ?? throw new InvalidOperationException("تعذر تحديد المجلد الأب لمجلد النشر.");
        EnsureNotReparsePoint(parentDirectory, "مجلد النشر الأب");

        string stagingDirectory = Path.Combine(parentDirectory, $".DateERP_update_staging_{Guid.NewGuid():N}");
        string backupDirectory = Path.Combine(parentDirectory,
            $"publish_backup_{DateTime.Now:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}");
        string failedDirectory = Path.Combine(parentDirectory,
            $"publish_failed_update_{DateTime.Now:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}");
        bool packageMoved = false;
        string actualHash;
        string previousVersion = ReadVersion(Path.Combine(TargetDirectory, "MfgSystem.exe"));
        string installedVersion = "غير محدد";

        try
        {
            progress?.Report("إعادة التحقق من البصمة وفحص محتويات ZIP…");
            using (var package = OpenPackageReadOnly(fullPackagePath))
            {
                actualHash = await ComputeSha256Async(package, cancellationToken).ConfigureAwait(false);
                VerifyHash(actualHash, expected);
                package.Position = 0;
                using var archive = new ZipArchive(package, ZipArchiveMode.Read, leaveOpen: true);
                var summary = ValidateArchive(archive);
                Directory.CreateDirectory(stagingDirectory);
                progress?.Report($"استخراج {summary.FileCount:N0} ملفاً إلى مساحة مؤقتة آمنة…");
                await ExtractValidatedArchiveAsync(archive, stagingDirectory, progress, cancellationToken)
                    .ConfigureAwait(false);
            }

            var stagedExecutable = Path.Combine(stagingDirectory, "MfgSystem.exe");
            if (!File.Exists(stagedExecutable) || new FileInfo(stagedExecutable).Length == 0)
                throw new InvalidDataException("الحزمة لا تحتوي MfgSystem.exe صالحاً في جذرها.");
            installedVersion = ReadVersion(stagedExecutable);
            cancellationToken.ThrowIfCancellationRequested();

            progress?.Report("إغلاق DateERP إغلاقاً طبيعياً إن كان يعمل…");
            await Task.Run(() => StopTargetApplicationGracefully(cancellationToken), cancellationToken)
                .ConfigureAwait(false);
            cancellationToken.ThrowIfCancellationRequested();

            progress?.Report("نقل النسخة الحالية إلى نسخة احتياطية؛ لا يُحذف المجلد القديم…");
            Directory.Move(TargetDirectory, backupDirectory);

            try
            {
                Directory.Move(stagingDirectory, TargetDirectory);
                packageMoved = true;
                if (!File.Exists(Path.Combine(TargetDirectory, "MfgSystem.exe")))
                    throw new IOException("لم يظهر MfgSystem.exe بعد نقل الحزمة إلى مجلد النشر.");
                var movedVersion = ReadVersion(Path.Combine(TargetDirectory, "MfgSystem.exe"));
                if (!string.Equals(movedVersion, installedVersion, StringComparison.Ordinal))
                    throw new IOException("فشل تحقق النسخة بعد النقل؛ سيُستعاد مجلد النشر السابق.");
            }
            catch (Exception installError)
            {
                try
                {
                    if (packageMoved && Directory.Exists(TargetDirectory))
                        Directory.Move(TargetDirectory, failedDirectory);
                    if (!Directory.Exists(TargetDirectory) && Directory.Exists(backupDirectory))
                        Directory.Move(backupDirectory, TargetDirectory);
                }
                catch (Exception rollbackError)
                {
                    throw new AggregateException(
                        $"فشل تثبيت الحزمة وفشل الاسترجاع التلقائي. لا تحذف أي مجلد يدوياً. \nالهدف: {TargetDirectory}\nالنسخة الاحتياطية: {backupDirectory}\nنسخة التحديث الفاشلة إن وُجدت: {failedDirectory}",
                        installError, rollbackError);
                }
                throw;
            }

            progress?.Report("تم التثبيت والتحقق. احتُفظ بالنسخة السابقة بجانب مجلد publish.");
            return new UpdateResult(backupDirectory, actualHash, previousVersion, installedVersion);
        }
        finally
        {
            // This removes only an incomplete temporary staging directory, never the backup or target.
            if (Directory.Exists(stagingDirectory))
            {
                try { Directory.Delete(stagingDirectory, recursive: true); }
                catch { /* Keep the staging directory for manual recovery if cleanup is blocked. */ }
            }
        }
    }

    private static void ValidateTargetDirectory()
    {
        if (!Directory.Exists(TargetDirectory))
            throw new DirectoryNotFoundException($"مجلد التطبيق غير موجود؛ لم يُنشأ أي مجلد: {TargetDirectory}");
        EnsureNotReparsePoint(TargetDirectory, "مجلد التطبيق");
        var executable = Path.Combine(TargetDirectory, "MfgSystem.exe");
        if (!File.Exists(executable) || new FileInfo(executable).Length == 0)
            throw new FileNotFoundException("المجلد المستهدف لا يحتوي MfgSystem.exe؛ أُوقف التحديث دون كتابة.", executable);

        var processPath = Environment.ProcessPath;
        if (!string.IsNullOrWhiteSpace(processPath) && IsInsideDirectory(processPath, TargetDirectory))
            throw new InvalidOperationException("شغّل أداة التحديث من خارج مجلد publish حتى لا تنقل الأداة نفسها أثناء التحديث.");
    }

    private static string ValidatePackagePath(string packagePath)
    {
        if (string.IsNullOrWhiteSpace(packagePath))
            throw new InvalidOperationException("اختر ملف ZIP أولاً.");
        var fullPath = Path.GetFullPath(packagePath);
        if (!File.Exists(fullPath))
            throw new FileNotFoundException("ملف الحزمة المحدد غير موجود.", fullPath);
        if (IsInsideDirectory(fullPath, TargetDirectory))
            throw new InvalidOperationException("ضع ملف ZIP خارج مجلد publish قبل فحصه أو تثبيته.");
        var file = new FileInfo(fullPath);
        if ((file.Attributes & FileAttributes.ReparsePoint) != 0)
            throw new InvalidOperationException("لا يُقبل ملف حزمة رمزي/مرتبط؛ اختر ملف ZIP عادياً.");
        return fullPath;
    }

    private static FileStream OpenPackageReadOnly(string path)
        => new(path, FileMode.Open, FileAccess.Read, FileShare.Read, 128 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan);

    private static string NormalizeExpectedHash(string value)
    {
        var hash = (value ?? string.Empty).Trim().Replace(" ", string.Empty, StringComparison.Ordinal);
        if (hash.Length != 64 || hash.Any(c => !Uri.IsHexDigit(c)))
            throw new InvalidOperationException("أدخل بصمة SHA-256 كاملة من 64 خانة سداسية عشرية ومن قناة موثوقة منفصلة.");
        return hash.ToUpperInvariant();
    }

    private static async Task<string> ComputeSha256Async(Stream stream, CancellationToken cancellationToken)
    {
        using var sha = SHA256.Create();
        var digest = await sha.ComputeHashAsync(stream, cancellationToken).ConfigureAwait(false);
        return Convert.ToHexString(digest);
    }

    private static void VerifyHash(string actualHash, string expectedHash)
    {
        var actual = Convert.FromHexString(actualHash);
        var expected = Convert.FromHexString(expectedHash);
        if (!CryptographicOperations.FixedTimeEquals(actual, expected))
            throw new InvalidDataException(
                $"بصمة الحزمة لا تطابق القيمة الموثوقة المدخلة. المتوقع: {expectedHash} | المحسوب: {actualHash}. لم يُعدّل مجلد التطبيق.");
    }

    private static ArchiveSummary ValidateArchive(ZipArchive archive)
    {
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        long expandedBytes = 0;
        long executableBytes = 0;
        int fileCount = 0;
        bool foundExecutable = false;

        foreach (var entry in archive.Entries)
        {
            var relativePath = NormalizeArchivePath(entry.FullName, out bool isDirectory);
            if (!paths.Add(relativePath))
                throw new InvalidDataException($"الحزمة تحتوي مساراً مكرراً أو متعارضاً على Windows: {entry.FullName}");
            var unixFileType = (entry.ExternalAttributes >> 16) & 0xF000;
            if (IsSymbolicLink(entry))
                throw new InvalidDataException($"لا تُقبل الروابط الرمزية داخل الحزمة: {entry.FullName}");
            if (unixFileType != 0 && unixFileType != 0x8000 && unixFileType != 0x4000)
                throw new InvalidDataException($"نوع إدخال غير عادي داخل الحزمة: {entry.FullName}");
            if ((isDirectory && unixFileType == 0x8000) || (!isDirectory && unixFileType == 0x4000))
                throw new InvalidDataException($"وصف الملف/المجلد داخل ZIP غير متسق: {entry.FullName}");
            if (relativePath.Length > 240)
                throw new InvalidDataException($"مسار ملف طويل أكثر من الحد الآمن: {entry.FullName}");
            if (HasWindowsDeviceSegment(relativePath))
                throw new InvalidDataException($"اسم ملف غير مسموح على Windows: {entry.FullName}");
            if (IsProtectedFile(relativePath))
                throw new InvalidDataException(
                    $"الحزمة تتضمن ملف إعداد/قاعدة بيانات محمياً؛ رُفضت دون تعديل الهدف: {entry.FullName}");

            if (isDirectory)
            {
                if (entry.Length != 0)
                    throw new InvalidDataException($"إدخال مجلد ZIP يحتوي بيانات غير متوقعة: {entry.FullName}");
                continue;
            }

            if (entry.Length < 0 || entry.Length > MaxEntryBytes)
                throw new InvalidDataException($"حجم ملف منفرد يتجاوز الحد الآمن: {entry.FullName}");
            expandedBytes = checked(expandedBytes + entry.Length);
            if (expandedBytes > MaxExpandedBytes)
                throw new InvalidDataException("إجمالي حجم فك الضغط يتجاوز الحد الآمن البالغ 2 GB.");
            fileCount++;
            if (fileCount > MaxArchiveFiles)
                throw new InvalidDataException("عدد ملفات الحزمة يتجاوز الحد الآمن.");

            if (string.Equals(relativePath, "MfgSystem.exe", StringComparison.OrdinalIgnoreCase))
            {
                if (foundExecutable)
                    throw new InvalidDataException("الحزمة تحتوي أكثر من MfgSystem.exe في الجذر.");
                foundExecutable = true;
                executableBytes = entry.Length;
                if (executableBytes == 0)
                    throw new InvalidDataException("ملف MfgSystem.exe داخل الحزمة فارغ.");
            }
        }

        if (!foundExecutable)
            throw new InvalidDataException(
                "الحزمة ليست محتويات مجلد publish المتوقع: يجب أن يكون MfgSystem.exe في جذر ZIP، لا داخل مجلد فرعي.");
        return new ArchiveSummary(fileCount, expandedBytes, executableBytes);
    }

    private static string NormalizeArchivePath(string fullName, out bool isDirectory)
    {
        if (string.IsNullOrWhiteSpace(fullName) || fullName.IndexOf('\0') >= 0)
            throw new InvalidDataException("الحزمة تحتوي اسماً فارغاً أو محرفاً غير مسموح.");
        var normalized = fullName.Replace('\\', '/');
        isDirectory = normalized.EndsWith("/", StringComparison.Ordinal);
        if (normalized.StartsWith("/", StringComparison.Ordinal)
            || normalized.Contains("//", StringComparison.Ordinal)
            || Path.IsPathRooted(normalized)
            || normalized.Contains(':'))
            throw new InvalidDataException($"مسار مطلق/غير آمن داخل ZIP: {fullName}");

        var segments = normalized.Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (segments.Length == 0 || segments.Any(s => s is "." or ".." || s.Trim() != s || s.EndsWith('.') || s.EndsWith(' ') || s.Any(char.IsControl)))
            throw new InvalidDataException($"مسار اجتياز/غير آمن داخل ZIP: {fullName}");
        return string.Join(Path.DirectorySeparatorChar, segments);
    }

    private static bool IsSymbolicLink(ZipArchiveEntry entry)
    {
        var unixFileType = (entry.ExternalAttributes >> 16) & 0xF000;
        return unixFileType == 0xA000;
    }

    private static bool HasWindowsDeviceSegment(string relativePath)
    {
        foreach (var segment in relativePath.Split(Path.DirectorySeparatorChar))
        {
            var name = segment.Split('.')[0].TrimEnd(' ', '.').ToUpperInvariant();
            if (name is "CON" or "PRN" or "AUX" or "NUL") return true;
            if (name.Length == 4 && (name.StartsWith("COM", StringComparison.Ordinal) || name.StartsWith("LPT", StringComparison.Ordinal))
                && name[3] is >= '1' and <= '9') return true;
        }
        return false;
    }

    private static bool IsProtectedFile(string relativePath)
    {
        var fileName = Path.GetFileName(relativePath);
        if (string.Equals(fileName, "config.json", StringComparison.OrdinalIgnoreCase)) return true;
        if (ForbiddenDatabaseExtensions.Contains(Path.GetExtension(fileName))) return true;
        return fileName.EndsWith(".db-wal", StringComparison.OrdinalIgnoreCase)
            || fileName.EndsWith(".db-shm", StringComparison.OrdinalIgnoreCase)
            || fileName.EndsWith(".sqlite-wal", StringComparison.OrdinalIgnoreCase)
            || fileName.EndsWith(".sqlite-shm", StringComparison.OrdinalIgnoreCase)
            || fileName.EndsWith(".sqlite-journal", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsInsideDirectory(string candidatePath, string directory)
    {
        var candidate = Path.GetFullPath(candidatePath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var root = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        return candidate.Equals(root, StringComparison.OrdinalIgnoreCase)
            || candidate.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
            || candidate.StartsWith(root + Path.AltDirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    }

    private static void EnsureNotReparsePoint(string path, string label)
    {
        var info = new DirectoryInfo(path);
        if ((info.Attributes & FileAttributes.ReparsePoint) != 0)
            throw new InvalidOperationException($"{label} رابط/نقطة إعادة توجيه؛ أُوقف التحديث لحماية مجلد آخر.");
    }

    private static async Task ExtractValidatedArchiveAsync(
        ZipArchive archive,
        string stagingDirectory,
        IProgress<string> progress,
        CancellationToken cancellationToken)
    {
        var root = Path.GetFullPath(stagingDirectory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        int completedFiles = 0;
        foreach (var entry in archive.Entries)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var relativePath = NormalizeArchivePath(entry.FullName, out bool isDirectory);
            var destination = Path.GetFullPath(Path.Combine(stagingDirectory, relativePath));
            if (!destination.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"مسار الملف خرج من مجلد الفك الآمن: {entry.FullName}");

            if (isDirectory)
            {
                Directory.CreateDirectory(destination);
                continue;
            }

            var parent = Path.GetDirectoryName(destination)
                ?? throw new InvalidDataException($"تعذر تحديد مجلد الملف: {entry.FullName}");
            Directory.CreateDirectory(parent);
            await using var input = entry.Open();
            await using var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                128 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
            await input.CopyToAsync(output, 128 * 1024, cancellationToken).ConfigureAwait(false);
            await output.FlushAsync(cancellationToken).ConfigureAwait(false);
            if (output.Length != entry.Length)
                throw new InvalidDataException($"طول الملف بعد فك الضغط لا يطابق سجل ZIP: {entry.FullName}");

            completedFiles++;
            if (completedFiles % 25 == 0)
                progress?.Report($"فُكّ {completedFiles:N0} ملفاً…");
        }
    }

    private static void StopTargetApplicationGracefully(CancellationToken cancellationToken)
    {
        var targetExecutable = Path.GetFullPath(Path.Combine(TargetDirectory, "MfgSystem.exe"));
        foreach (var process in Process.GetProcessesByName("MfgSystem"))
        {
            using (process)
            {
                cancellationToken.ThrowIfCancellationRequested();
                string processExecutable;
                try
                {
                    processExecutable = process.MainModule?.FileName;
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException(
                        "تعذر التحقق من مسار عملية MfgSystem؛ أغلق DateERP يدوياً ثم أعد المحاولة.", ex);
                }
                if (string.IsNullOrWhiteSpace(processExecutable)
                    || !Path.GetFullPath(processExecutable).Equals(targetExecutable, StringComparison.OrdinalIgnoreCase))
                    continue;

                process.CloseMainWindow();
                if (!process.WaitForExit(GracefulCloseMilliseconds))
                    throw new InvalidOperationException(
                        "DateERP لم يُغلق خلال 20 ثانية. احفظ العمل وأغلقه يدوياً؛ لم يُنهِه المحدّث قسراً ولم يبدأ النسخ.");
            }
        }
    }

    private static string ReadVersion(string executablePath)
    {
        var version = FileVersionInfo.GetVersionInfo(executablePath).FileVersion;
        return string.IsNullOrWhiteSpace(version) ? "غير محدد" : version;
    }

    private sealed record ArchiveSummary(int FileCount, long ExpandedBytes, long MainExecutableBytes);
}
