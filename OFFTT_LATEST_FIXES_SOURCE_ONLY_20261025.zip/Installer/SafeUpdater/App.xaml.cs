using System.Windows;

namespace DateErp.SafeUpdater;

public partial class App : Application
{
}
