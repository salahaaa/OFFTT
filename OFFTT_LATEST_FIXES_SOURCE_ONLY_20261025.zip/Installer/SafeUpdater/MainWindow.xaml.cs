using System.Diagnostics;
using System.Windows;
using Microsoft.Win32;

namespace DateErp.SafeUpdater;

public partial class MainWindow : Window
{
    private UpdateInspection _inspection;
    private string _inspectedPackagePath;
    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        TargetPathTextBox.Text = UpdateEngine.TargetDirectory;
    }

    private void BrowsePackageButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "اختر حزمة نشر DateERP الموثوقة",
            Filter = "حزم ZIP (*.zip)|*.zip",
            CheckFileExists = true,
            Multiselect = false
        };
        if (dialog.ShowDialog(this) != true) return;
        PackagePathTextBox.Text = dialog.FileName;
        InvalidateInspection();
    }

    private async void CheckButton_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        InvalidateInspection();
        try
        {
            SetBusy(true);
            var progress = new Progress<string>(message => StatusText.Text = message);
            var result = await UpdateEngine.InspectPackageAsync(
                PackagePathTextBox.Text,
                Sha256TextBox.Text,
                progress);
            _inspection = result;
            _inspectedPackagePath = PackagePathTextBox.Text.Trim();
            InstallButton.IsEnabled = VerifiedBuildCheckBox.IsChecked == true;
            StatusText.Text =
                "فحص ناجح — لم تُكتب أي ملفات إلى مجلد التطبيق.\n\n"
                + $"الحزمة: {result.PackageFileName}\n"
                + $"SHA-256 المطابق: {result.Sha256}\n"
                + $"إصدار التطبيق الحالي: {result.CurrentVersion}\n"
                + $"عدد الملفات: {result.FileCount:N0}\n"
                + $"الحجم بعد الفك: {result.ExpandedBytes / 1024d / 1024d:N1} MB\n"
                + $"حجم MfgSystem.exe: {result.MainExecutableBytes / 1024d / 1024d:N1} MB\n\n"
                + "عند التثبيت سيُطلب إغلاق التطبيق طبيعياً، ثم يُنقل المجلد الحالي إلى نسخة احتياطية محفوظة بجانب publish.";
        }
        catch (Exception ex)
        {
            StatusText.Text = "فشل الفحص — لم يُعدّل مجلد التطبيق.\n\n" + ex.Message;
            InvalidateInspection();
        }
        finally
        {
            SetBusy(false);
        }
    }

    private async void InstallButton_Click(object sender, RoutedEventArgs e)
    {
        if (_busy || _inspection == null || VerifiedBuildCheckBox.IsChecked != true) return;
        if (!string.Equals(PackagePathTextBox.Text.Trim(), _inspectedPackagePath, StringComparison.OrdinalIgnoreCase))
        {
            InvalidateInspection();
            StatusText.Text = "تغيّر ملف الحزمة بعد الفحص؛ افحص الحزمة من جديد قبل التثبيت.";
            return;
        }

        var confirmation = MessageBox.Show(
            this,
            "هل تريد تثبيت هذه الحزمة؟\n\n"
            + $"الملف: {_inspection.PackageFileName}\n"
            + $"البصمة: {_inspection.Sha256}\n"
            + $"الوجهة الثابتة: {UpdateEngine.TargetDirectory}\n\n"
            + "سيعاد التحقق من البصمة، ويُحتفظ بنسخة كاملة من publish الحالي. لن تُحذف النسخة الاحتياطية، ولن يُقتل التطبيق قسراً.",
            "تأكيد التحديث",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning,
            MessageBoxResult.No);
        if (confirmation != MessageBoxResult.Yes) return;

        try
        {
            SetBusy(true);
            var progress = new Progress<string>(message => StatusText.Text = message);
            var result = await UpdateEngine.InstallPackageAsync(
                PackagePathTextBox.Text,
                Sha256TextBox.Text,
                progress);
            StatusText.Text =
                "اكتمل التحديث والتحقق بنجاح.\n\n"
                + $"الإصدار السابق: {result.PreviousVersion}\n"
                + $"الإصدار الجديد: {result.InstalledVersion}\n"
                + $"SHA-256: {result.Sha256}\n"
                + $"النسخة الاحتياطية المحفوظة: {result.BackupDirectory}\n\n"
                + "لم يُحذف المجلد السابق.";
            InstallButton.IsEnabled = false;
            _inspection = null;

            if (LaunchAfterInstallCheckBox.IsChecked == true
                && MessageBox.Show(this, "تم التحديث. هل تريد تشغيل DateERP الآن؟", "تشغيل التطبيق",
                    MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.Yes) == MessageBoxResult.Yes)
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = Path.Combine(UpdateEngine.TargetDirectory, "MfgSystem.exe"),
                        WorkingDirectory = UpdateEngine.TargetDirectory,
                        UseShellExecute = true
                    });
                }
                catch (Exception launchError)
                {
                    StatusText.Text += "\nتعذر التشغيل تلقائياً؛ شغّل MfgSystem.exe يدوياً. سبب الخطأ: " + launchError.Message;
                }
            }
        }
        catch (Exception ex)
        {
            StatusText.Text = "لم يكتمل التحديث. راجع الرسالة والمسارات أدناه؛ سيُستعاد المجلد السابق تلقائياً إذا كان النقل قد بدأ.\n\n"
                + ex.Message;
            InvalidateInspection();
        }
        finally
        {
            SetBusy(false);
        }
    }

    private void Sha256TextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        => InvalidateInspection();

    private void VerifiedBuildCheckBox_Changed(object sender, RoutedEventArgs e)
    {
        if (!_busy && InstallButton != null)
            InstallButton.IsEnabled = _inspection != null && VerifiedBuildCheckBox.IsChecked == true;
    }

    private void InvalidateInspection()
    {
        _inspection = null;
        _inspectedPackagePath = null;
        if (VerifiedBuildCheckBox != null) VerifiedBuildCheckBox.IsChecked = false;
        if (!_busy && InstallButton != null) InstallButton.IsEnabled = false;
    }

    private void SetBusy(bool value)
    {
        _busy = value;
        BusyProgress.Visibility = value ? Visibility.Visible : Visibility.Collapsed;
        BrowsePackageButton.IsEnabled = !value;
        CheckButton.IsEnabled = !value;
        Sha256TextBox.IsEnabled = !value;
        InstallButton.IsEnabled = !value && _inspection != null && VerifiedBuildCheckBox.IsChecked == true;
    }
}
