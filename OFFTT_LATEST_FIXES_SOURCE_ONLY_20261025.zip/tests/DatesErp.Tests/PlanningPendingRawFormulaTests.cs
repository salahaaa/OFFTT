using DatesErp.Application.Services;
using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Views.Screens;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace DatesErp.Tests;

/// <summary>
/// A draft may be saved when a finished-to-raw identity exists but no official quantitative
/// factor is available. Such a draft must never manufacture a 1:1 allocation or enter approval.
/// </summary>
public sealed class PlanningPendingRawFormulaTests
{
    private const int FinishedKhalas = 3;
    private const int RawKhalas = 1;
    private const int Customer = 1;
    private const string WorkDay = "2026-11-01";

    private sealed record RawLot(int Id, int WarehouseId);

    private static T Svc<T>(TestHost host) where T : notnull
        => host.Services.CreateScope().ServiceProvider.GetRequiredService<T>();

    private static DatesErpDbContext FreshDb(TestHost host)
        => new(new DbContextOptionsBuilder<DatesErpDbContext>().UseSqlite(host.Connection).Options);

    private static RawLot ReceiveRawLot(TestHost host, int rawProductId = RawKhalas)
    {
        var receiving = Svc<IReceivingService>(host);
        var shipment = receiving.SaveShipment(Customer, null, null, new List<ShipmentItemDto>
        {
            new()
            {
                TreatmentRequired = false,
                ProductId = rawProductId,
                QtyKg = 200,
                PackageCount = 10,
                UnitWeightKg = 20,
                ReceiptUnit = "سلة"
            }
        });
        Assert.True(shipment.Ok, shipment.Message);
        Assert.True(receiving.ApproveShipment(shipment.Id).Ok);

        using var db = FreshDb(host);
        var lot = db.Lots.Single(l => l.ShipmentId == shipment.Id && l.ProductId == rawProductId);
        var warehouseId = db.Shipments.Where(s => s.Id == shipment.Id)
            .Select(s => s.ReceivingWarehouseId).FirstOrDefault()
            ?? db.Warehouses.Where(w => w.WarehouseCode == "WRM").Select(w => w.Id).Single();
        return new RawLot(lot.Id, warehouseId);
    }

    private static PlanItemDto DraftItem(RawLot lot, bool includeUntrusted1To1Values = true)
        => new()
        {
            SourceType = "FromReceiving",
            LotId = lot.Id,
            SelectedRawProductId = RawKhalas,
            CustomerId = Customer,
            ProductId = FinishedKhalas,
            PlannedCartons = 2,
            PlannedQtyKg = 15,
            ScheduledDate = WorkDay,
            SuggestedShiftId = 1,
            SuggestedLineId = 1,
            SourceUnit = includeUntrusted1To1Values ? "سلة" : null,
            SourceQtyInUnit = includeUntrusted1To1Values ? 0.75 : 0,
            SourceUnitWeightKg = includeUntrusted1To1Values ? 20 : 0,
            SourceQtyKg = includeUntrusted1To1Values ? 15 : 0,
            Allocations = includeUntrusted1To1Values
                ? new List<PlanItemAllocationDto>
                {
                    new()
                    {
                        WarehouseId = lot.WarehouseId,
                        LotId = lot.Id,
                        CustomerId = Customer,
                        AllocatedQtyKg = 15 // Intentionally untrusted: finished kg is not raw kg.
                    }
                }
                : new List<PlanItemAllocationDto>()
        };

    [Fact]
    public void Missing_Formula_Saves_Unreserved_Draft_And_Blocks_Submission_Approval_And_Orders()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        var planning = Svc<IPlanningService>(host);

        var saved = planning.SavePlan("مسودة بمعامل معلق", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot) });

        Assert.True(saved.Ok, saved.Message);
        Assert.Contains("معلّق", saved.Message);
        Assert.Contains("لم يُنشأ تخصيص أو حجز أو سحب", saved.Message);
        var itemId = OnlyPlanItemId(host, saved.Id);
        AssertPendingItem(host, saved.Id, itemId, lot.Id);

        // Updating a draft also discards the UI's old 1:1 allocation/draw instead of persisting it.
        var updated = planning.UpdatePlan(saved.Id, "مسودة محدّثة", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot) }, scopeMode: "Multi");
        Assert.True(updated.Ok, updated.Message);
        Assert.Contains("معامل تحويل", updated.Message);
        itemId = OnlyPlanItemId(host, saved.Id);
        AssertPendingItem(host, saved.Id, itemId, lot.Id);

        Assert.False(planning.SubmitPlan(saved.Id).Ok);
        Assert.False(planning.ApprovePlan(saved.Id).Ok);
        using (var db = FreshDb(host))
            Assert.False(db.ProductionPlans.Single(p => p.Id == saved.Id).IsApproved);
        var orders = Svc<IProductionOrderService>(host);
        Assert.Empty(orders.GetOrderableItems(saved.Id));
        var issue = orders.IssueOrdersFromPlan(saved.Id);
        Assert.False(issue.Ok);
        Assert.Empty(issue.Created);

        var orderItem = new OrderItemDto
        {
            PlanItemId = itemId,
            CustomerId = Customer,
            ProductId = FinishedKhalas,
            LotId = lot.Id,
            PlannedCartons = 2,
            PlannedQtyKg = 15
        };
        var order = orders.SaveOrder(
            "FromPlan", saved.Id, Customer, WorkDay, 1, 1, new List<OrderItemDto> { orderItem });
        Assert.False(order.Ok);
        Assert.Contains("غير معتمدة", order.Message);
        using (var db = FreshDb(host))
            Assert.Empty(db.ProductionOrders);

        // Simulate a legacy/imported approved header: order services must still refuse a
        // formula-pending item rather than trusting status alone.
        using (var db = FreshDb(host))
        {
            var plan = db.ProductionPlans.Single(p => p.Id == saved.Id);
            plan.IsApproved = true;
            plan.Status = "Approved";
            db.SaveChanges();
        }
        Assert.Empty(orders.GetOrderableItems(saved.Id));
        Assert.Empty(orders.GetPendingPlanGroups());
        var today = orders.GetTodayProduction();
        Assert.False(today.CanIssue);
        Assert.Contains("معامل تحويل خام معتمد", today.Rows.Single().Status);
        var legacyIssue = orders.IssueOrdersFromPlan(saved.Id);
        Assert.False(legacyIssue.Ok);
        Assert.Empty(legacyIssue.Created);
        var scheduledDate = new DateTime(2026, 11, 1).ToString("dd/MM/yyyy");
        var planGroupIssue = orders.IssuePlanGroup(saved.Id, scheduledDate, Customer, 1, 1);
        Assert.False(planGroupIssue.Ok);
        Assert.Contains("معامل تحويل خام معتمد", planGroupIssue.Message);
        var multiCustomerIssue = orders.IssuePlanMultiCustomerGroup(saved.Id, scheduledDate, 1, 1);
        Assert.False(multiCustomerIssue.Ok);
        Assert.Contains("معامل تحويل خام معتمد", multiCustomerIssue.Message);
        var todayGroupIssue = orders.IssueTodayGroup(saved.Id, Customer, 1, 1);
        Assert.False(todayGroupIssue.Ok);
        Assert.Contains("معامل تحويل خام معتمد", todayGroupIssue.Message);
        var legacyOrder = orders.SaveOrder(
            "FromPlan", saved.Id, Customer, WorkDay, 1, 1, new List<OrderItemDto> { orderItem });
        Assert.False(legacyOrder.Ok);
        Assert.Contains("معامل تحويل خام معتمد", legacyOrder.Message);
        var todayIssue = orders.IssueTodayOrders();
        Assert.False(todayIssue.Ok);
        using (var db = FreshDb(host))
            Assert.Empty(db.ProductionOrders);
    }

    [Fact]
    public void Draft_Still_Rejects_A_Raw_Lot_That_Does_Not_Match_The_Product_Link()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var wrongLot = ReceiveRawLot(host, rawProductId: 2);
        int before;
        using (var db = FreshDb(host)) before = db.ProductionPlans.Count();

        var result = Svc<IPlanningService>(host).SavePlan("مصدر خام خاطئ", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(wrongLot) });

        Assert.False(result.Ok);
        Assert.Contains("لا يطابق", result.Message);
        using (var db = FreshDb(host))
            Assert.Equal(before, db.ProductionPlans.Count());
    }

    [Fact]
    public void Legacy_Formula_Plan_Without_Any_Raw_Lot_Cannot_Be_Approved_Or_Issued()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        using (var db = FreshDb(host))
        {
            db.Products.Single(p => p.Id == FinishedKhalas).YieldFactor = 1.25;
            db.SaveChanges();
        }

        var item = DraftItem(lot);
        item.SourceQtyInUnit = 0.6;
        item.SourceUnitWeightKg = 20;
        item.SourceQtyKg = 12;
        item.Allocations.Single().AllocatedQtyKg = 12;
        var planning = Svc<IPlanningService>(host);
        var saved = planning.SavePlan("خطة خام مرجعية", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { item });
        Assert.True(saved.Ok, saved.Message);

        using (var db = FreshDb(host))
        {
            var stored = db.ProductionPlanItems.Include(i => i.Allocations).Single(i => i.PlanId == saved.Id);
            db.ProductionPlanItemAllocations.RemoveRange(stored.Allocations);
            stored.LotId = null;
            stored.SourceUnit = null;
            stored.SourceQtyInUnit = 0;
            stored.SourceUnitWeightKg = 0;
            stored.SourceQtyKg = 0;
            db.SaveChanges();
        }

        Assert.False(planning.SubmitPlan(saved.Id).Ok);
        var approval = planning.ApprovePlan(saved.Id);
        Assert.False(approval.Ok);
        Assert.Contains("دفعة خام مرجعية", approval.Message);

        // Simulate a legacy/imported approved header. Every order path must repeat the raw-source guard.
        using (var db = FreshDb(host))
        {
            var plan = db.ProductionPlans.Single(p => p.Id == saved.Id);
            plan.IsApproved = true;
            plan.Status = "Approved";
            db.SaveChanges();
        }
        var orders = Svc<IProductionOrderService>(host);
        Assert.Empty(orders.GetOrderableItems(saved.Id));
        var issue = orders.IssueOrdersFromPlan(saved.Id);
        Assert.False(issue.Ok);
        Assert.Empty(issue.Created);
        var direct = orders.SaveOrder("FromPlan", saved.Id, Customer, WorkDay, 1, 1,
            new List<OrderItemDto>
            {
                new()
                {
                    PlanItemId = OnlyPlanItemId(host, saved.Id),
                    CustomerId = Customer,
                    ProductId = FinishedKhalas,
                    PlannedCartons = 2,
                    PlannedQtyKg = 15
                }
            });
        Assert.False(direct.Ok);
        using (var db = FreshDb(host)) Assert.Empty(db.ProductionOrders);
    }

    [Fact]
    public void Official_Formula_Without_A_Batch_Saves_Unreserved_Draft_And_Blocks_Approval_And_Orders()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        Assert.True(Svc<MasterDataService>(host)
            .SaveProductRawSource(null, FinishedKhalas, RawKhalas, 0.8m).Ok);

        var item = DraftItem(lot, includeUntrusted1To1Values: false);
        item.SourceType = "Manual";
        item.LotId = null;
        item.SelectedRawProductId = RawKhalas;
        var planning = Svc<IPlanningService>(host);
        var saved = planning.SavePlan("مسودة بمعامل دون دفعة", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { item });
        Assert.True(saved.Ok, saved.Message);
        Assert.Contains("بلا تخصيص خام", saved.Message);

        using (var db = FreshDb(host))
        {
            var planItem = db.ProductionPlanItems.Single(i => i.PlanId == saved.Id);
            Assert.Equal(12m, planItem.RawRequiredQtyKg);
            Assert.Null(planItem.LotId);
            Assert.Empty(db.ProductionPlanItemAllocations.Where(a => a.PlanItemId == planItem.Id));
            Assert.Equal(0d, db.Lots.Single(l => l.Id == lot.Id).ReservedQtyKg);
        }

        Assert.False(planning.SubmitPlan(saved.Id).Ok);
        var approval = planning.ApprovePlan(saved.Id);
        Assert.False(approval.Ok);
        Assert.Contains("دفعة خام مرجعية", approval.Message);

        // Even a legacy/imported approved header cannot issue an order from the unallocated draft.
        using (var db = FreshDb(host))
        {
            var plan = db.ProductionPlans.Single(p => p.Id == saved.Id);
            plan.IsApproved = true;
            plan.Status = "Approved";
            db.SaveChanges();
        }
        var orders = Svc<IProductionOrderService>(host);
        Assert.Empty(orders.GetOrderableItems(saved.Id));
        var issue = orders.IssueOrdersFromPlan(saved.Id);
        Assert.False(issue.Ok);
        Assert.Empty(issue.Created);
        using (var db = FreshDb(host)) Assert.Empty(db.ProductionOrders);
    }

    [Fact]
    public void Order_Approval_Rejects_Allocations_That_Differ_From_Its_Approved_Plan()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        Assert.True(Svc<MasterDataService>(host)
            .SaveProductRawSource(null, FinishedKhalas, RawKhalas, 0.8m).Ok);

        var item = DraftItem(lot, includeUntrusted1To1Values: false);
        item.SourceUnit = "سلة";
        item.SourceQtyInUnit = 0.6;
        item.SourceUnitWeightKg = 20;
        item.SourceQtyKg = 12;
        item.Allocations.Add(new PlanItemAllocationDto
        {
            WarehouseId = lot.WarehouseId,
            LotId = lot.Id,
            CustomerId = Customer,
            AllocatedQtyKg = 12
        });
        var planning = Svc<IPlanningService>(host);
        var saved = planning.SavePlan("تخصيص خام معتمد", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { item });
        Assert.True(saved.Ok, saved.Message);
        Assert.True(planning.SubmitPlan(saved.Id).Ok);
        Assert.True(planning.ApprovePlan(saved.Id).Ok);

        var orders = Svc<IProductionOrderService>(host);
        var scheduledDate = new DateTime(2026, 11, 1).ToString("dd/MM/yyyy");
        var issued = orders.IssuePlanMultiCustomerGroup(saved.Id, scheduledDate, 1, 1);
        Assert.True(issued.Ok, issued.Message);

        using (var db = FreshDb(host))
        {
            var orderItem = db.ProductionOrderItems.Include(i => i.Allocations).Single(i => i.OrderId == issued.Id);
            Assert.Single(orderItem.Allocations);
            orderItem.Allocations.Single().AllocatedQtyKg = 11; // intentional tamper for the guard test
            db.SaveChanges();
        }

        var approved = orders.ApproveOrder(issued.Id);
        Assert.False(approved.Ok);
        Assert.Contains("تخصيص الخام في أمر الإنتاج", approved.Message);
        using (var db = FreshDb(host))
            Assert.False(db.ProductionOrders.Single(o => o.Id == issued.Id).IsApproved);
    }

    [Fact]
    public void One_Plan_Item_Cannot_Mix_Alternative_Raw_Sources_At_Approval_Or_Order_Issuance()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var raw1Lot = ReceiveRawLot(host, RawKhalas);
        var raw2Lot = ReceiveRawLot(host, rawProductId: 2);
        var master = Svc<MasterDataService>(host);
        Assert.True(master.SaveProductRawSource(null, FinishedKhalas, RawKhalas, 0.8m).Ok);
        // The same explicit fixture factor keeps the test focused on source identity, not a different calculation.
        Assert.True(master.SaveProductRawSource(null, FinishedKhalas, 2, 0.8m).Ok);

        var item = DraftItem(raw1Lot, includeUntrusted1To1Values: false);
        item.SourceUnit = "سلة";
        item.SourceQtyInUnit = 0.6;
        item.SourceUnitWeightKg = 20;
        item.SourceQtyKg = 12;
        item.Allocations.Add(new PlanItemAllocationDto
        {
            WarehouseId = raw1Lot.WarehouseId,
            LotId = raw1Lot.Id,
            CustomerId = Customer,
            AllocatedQtyKg = 12
        });
        var planning = Svc<IPlanningService>(host);
        var saved = planning.SavePlan("مصدر بديل واحد لكل بند", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { item });
        Assert.True(saved.Ok, saved.Message);

        using (var db = FreshDb(host))
        {
            var planItem = db.ProductionPlanItems.Include(i => i.Allocations).Single(i => i.PlanId == saved.Id);
            var original = Assert.Single(planItem.Allocations);
            original.AllocatedQtyKg = 6;
            db.ProductionPlanItemAllocations.Add(new ProductionPlanItemAllocation
            {
                PlanItemId = planItem.Id,
                WarehouseId = raw2Lot.WarehouseId,
                LotId = raw2Lot.Id,
                CustomerId = Customer,
                AllocatedQtyKg = 6,
                Status = "Reserved"
            });
            db.SaveChanges();
        }

        var submit = planning.SubmitPlan(saved.Id);
        Assert.False(submit.Ok);
        Assert.Contains("مصادر خام مختلفة", submit.Message);
        var approval = planning.ApprovePlan(saved.Id);
        Assert.False(approval.Ok);
        Assert.Contains("مصادر خام مختلفة", approval.Message);

        using (var db = FreshDb(host))
        {
            var plan = db.ProductionPlans.Single(p => p.Id == saved.Id);
            plan.IsApproved = true;
            plan.Status = "Approved";
            db.SaveChanges();
        }
        var orders = Svc<IProductionOrderService>(host);
        Assert.Empty(orders.GetOrderableItems(saved.Id));
        var issue = orders.IssueOrdersFromPlan(saved.Id);
        Assert.False(issue.Ok);
        Assert.Empty(issue.Created);
        using (var db = FreshDb(host)) Assert.Empty(db.ProductionOrders);
    }

    [Fact]
    public void Explicit_Raw_Allocation_Must_Equal_Official_Formula_Requirement()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        using (var db = FreshDb(host))
        {
            db.Products.Single(p => p.Id == FinishedKhalas).YieldFactor = 1.25;
            db.SaveChanges(); // fixture explicitly states 12 kg raw for 15 kg finished
        }

        var mismatchedAllocation = DraftItem(lot);
        mismatchedAllocation.SourceQtyInUnit = 0.6;
        mismatchedAllocation.SourceUnitWeightKg = 20;
        mismatchedAllocation.SourceQtyKg = 12; // source draw is correct; only the explicit allocation is wrong
        var result = Svc<IPlanningService>(host).SavePlan("تخصيص خام لا يطابق الاحتياج", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { mismatchedAllocation }); // deliberately allocates 15 kg instead of calculated 12 kg

        Assert.False(result.Ok);
        Assert.Contains("لا يساوي الاحتياج المحسوب", result.Message);
        using var verify = FreshDb(host);
        Assert.Empty(verify.ProductionPlans);
        Assert.Equal(0, verify.Lots.Single(l => l.Id == lot.Id).ReservedQtyKg, 0.001);
    }

    [Fact]
    public void Central_ProductRawSource_Factor_Is_Reused_Without_Editing_Product_Per_Plan()
    {
        using var host = new TestHost();
        host.LoginAsAdmin();
        var master = Svc<MasterDataService>(host);

        // Explicitly supplied official fixture value; no factor is inferred or defaulted.
        var saved = master.SaveProductRawSource(null, FinishedKhalas, RawKhalas, 0.8m);
        Assert.True(saved.Ok, saved.Message);
        var rules = master.GetProductRawSources(FinishedKhalas);
        var rule = Assert.Single(rules);
        Assert.Equal(RawKhalas, rule.RawProductId);
        Assert.Equal(0.8m, rule.RawKgPerFinishedKg);
        Assert.True(rule.IsActive);

        using var db = FreshDb(host);
        Assert.Null(db.Products.Single(p => p.Id == FinishedKhalas).YieldFactor);
        var firstPlanQuantity = RawRequirementEngine.Calculate(db, FinishedKhalas, 1000, RawKhalas);
        var secondPlanQuantity = RawRequirementEngine.Calculate(db, FinishedKhalas, 2500, RawKhalas);
        Assert.True(firstPlanQuantity.IsConfigured, firstPlanQuantity.Error);
        Assert.True(secondPlanQuantity.IsConfigured, secondPlanQuantity.Error);
        Assert.Equal(800m, firstPlanQuantity.RawRequiredQtyKg);
        Assert.Equal(2000m, secondPlanQuantity.RawRequiredQtyKg);
    }

    [Fact]
    public void Official_Factor_Allows_Draft_Recalculation_And_Approval_Without_1To1_Assumption()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        var planning = Svc<IPlanningService>(host);
        var draft = planning.SavePlan("مسودة أولية", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot, includeUntrusted1To1Values: false) });
        Assert.True(draft.Ok, draft.Message);
        AssertPendingItem(host, draft.Id, OnlyPlanItemId(host, draft.Id), lot.Id);

        // This is an explicit test fixture conversion, not a production default or inferred ratio.
        using (var db = FreshDb(host))
        {
            var product = db.Products.Single(p => p.Id == FinishedKhalas);
            product.YieldFactor = 1.25; // official outside/inside yield => 0.8 kg raw per kg finished
            db.SaveChanges();
        }
        Assert.Equal(200, planning.GetProductLotRemaining(lot.Id, FinishedKhalas), 0.01);

        var recalculated = DraftItem(lot, includeUntrusted1To1Values: false);
        recalculated.SourceUnit = "سلة";
        recalculated.SourceUnitWeightKg = 20;
        recalculated.SourceQtyKg = 12;
        recalculated.Allocations.Add(new PlanItemAllocationDto
        {
            WarehouseId = lot.WarehouseId,
            LotId = lot.Id,
            CustomerId = Customer,
            AllocatedQtyKg = 12
        });
        var updated = planning.UpdatePlan(draft.Id, "مسودة محسوبة", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { recalculated }, scopeMode: "Multi");
        Assert.True(updated.Ok, updated.Message);

        using (var db = FreshDb(host))
        {
            var item = db.ProductionPlanItems.Include(i => i.Allocations).Single(i => i.PlanId == draft.Id);
            Assert.Equal(12, (double)item.RawRequiredQtyKg, 0.01);
            Assert.Equal("سلة", item.SourceUnit);
            Assert.Equal(12, item.SourceQtyKg, 0.01);
            Assert.Equal(0.6, item.SourceQtyInUnit, 0.01);
            Assert.Equal(12, item.Allocations.Sum(a => a.AllocatedQtyKg), 0.01);
            Assert.Equal(12, db.Lots.Single(l => l.Id == lot.Id).ReservedQtyKg, 0.01);
        }
        Assert.True(planning.SubmitPlan(draft.Id).Ok);
        Assert.True(planning.ApprovePlan(draft.Id).Ok);
        var orders = Svc<IProductionOrderService>(host);
        Assert.Single(orders.GetOrderableItems(draft.Id));
        var order = orders.SaveOrder("FromPlan", draft.Id, Customer, WorkDay, 1, 1,
            new List<OrderItemDto>
            {
                new()
                {
                    PlanItemId = OnlyPlanItemId(host, draft.Id),
                    CustomerId = Customer,
                    ProductId = FinishedKhalas,
                    LotId = lot.Id,
                    PlannedCartons = 2,
                    PlannedQtyKg = 15
                }
            });
        Assert.True(order.Ok, order.Message);
    }

    [Fact]
    public void Official_Factor_Derives_Source_Draw_When_Only_Receipt_Unit_Metadata_Is_Sent()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        using (var db = FreshDb(host))
        {
            var product = db.Products.Single(p => p.Id == FinishedKhalas);
            product.YieldFactor = 1.25;
            db.SaveChanges();
        }

        var itemDto = DraftItem(lot, includeUntrusted1To1Values: false);
        itemDto.SourceUnit = "سلة"; // unit metadata only; the official formula supplies the kilograms
        var saved = Svc<IPlanningService>(host).SavePlan("سحب محسوب بالمعامل", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { itemDto });

        Assert.True(saved.Ok, saved.Message);
        using var verify = FreshDb(host);
        var item = verify.ProductionPlanItems.Include(i => i.Allocations).Single(i => i.PlanId == saved.Id);
        Assert.Equal(12, (double)item.RawRequiredQtyKg, 0.01);
        Assert.Equal("سلة", item.SourceUnit);
        Assert.Equal(12, item.SourceQtyKg, 0.01);
        Assert.Equal(0.6, item.SourceQtyInUnit, 0.01);
        Assert.Equal(12, item.Allocations.Sum(a => a.AllocatedQtyKg), 0.01);
    }

    [Fact]
    public void Update_To_Pending_Formula_Releases_The_Old_Raw_Reservation_And_Draw()
    {
        using var host = new TestHost();
        host.SetBusinessDate(WorkDay);
        host.LoginAsAdmin();
        var lot = ReceiveRawLot(host);
        using (var db = FreshDb(host))
        {
            var product = db.Products.Single(p => p.Id == FinishedKhalas);
            product.YieldFactor = 1.25;
            db.SaveChanges();
        }

        var planning = Svc<IPlanningService>(host);
        var official = DraftItem(lot, includeUntrusted1To1Values: false);
        official.SourceUnit = "سلة";
        official.SourceUnitWeightKg = 20;
        official.SourceQtyKg = 12;
        official.Allocations.Add(new PlanItemAllocationDto
        {
            WarehouseId = lot.WarehouseId,
            LotId = lot.Id,
            CustomerId = Customer,
            AllocatedQtyKg = 12
        });
        var saved = planning.SavePlan("خطة بمعامل", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { official });
        Assert.True(saved.Ok, saved.Message);
        using (var db = FreshDb(host))
            Assert.Equal(12, db.Lots.Single(l => l.Id == lot.Id).ReservedQtyKg, 0.01);

        using (var db = FreshDb(host))
        {
            var product = db.Products.Single(p => p.Id == FinishedKhalas);
            product.YieldFactor = null;
            db.SaveChanges();
        }
        var updated = planning.UpdatePlan(saved.Id, "مسودة بانتظار المعامل", "Daily", WorkDay, WorkDay, 1, 1,
            new List<PlanItemDto> { DraftItem(lot) }, scopeMode: "Multi");
        Assert.True(updated.Ok, updated.Message);
        Assert.Contains("معامل تحويل", updated.Message);
        AssertPendingItem(host, saved.Id, OnlyPlanItemId(host, saved.Id), lot.Id);
        Assert.False(planning.SubmitPlan(saved.Id).Ok);
        Assert.False(planning.ApprovePlan(saved.Id).Ok);
    }

    [Fact]
    public void Raw_Need_Display_Does_Not_Fall_Back_To_Finished_Quantity()
    {
        var row = new LotEditorRow
        {
            AllProducts = new List<ProductOption>
            {
                new() { Id = FinishedKhalas, Name = "خلاص تام", CartonWeightKg = 7.5 }
            }
        };
        row.ProductId = FinishedKhalas;
        row.CartonsText = "2";

        Assert.Equal(15, row.ComputedKg, 0.01);
        Assert.Equal(0, row.RawRequiredKg, 0.001);
        Assert.Equal(0, row.SelectedQtyKg, 0.001);
        Assert.Equal("غير محسوب", row.SelectedQtyDisplay);

        var savedRow = new PlanRowUi
        {
            ItemId = 10,
            ProductId = FinishedKhalas,
            QtyKg = 15,
            SourceQtyKg = 15,
            AllocationSelectedQtyKg = 15,
            SavedRawRequiredKg = 15
        };
        Assert.Equal(0, savedRow.RawRequiredKg, 0.001);
        Assert.Equal("غير محسوب", savedRow.RawNeedDisplay);
        Assert.Contains("المعامل مفقود", savedRow.RawPlanStatus);
    }

    private static int OnlyPlanItemId(TestHost host, int planId)
    {
        using var db = FreshDb(host);
        return db.ProductionPlanItems.Where(i => i.PlanId == planId).Select(i => i.Id).Single();
    }

    private static void AssertPendingItem(TestHost host, int planId, int itemId, int lotId)
    {
        using var db = FreshDb(host);
        var item = db.ProductionPlanItems.Include(i => i.Allocations)
            .Single(i => i.Id == itemId && i.PlanId == planId);
        Assert.Equal(0, (double)item.RawRequiredQtyKg, 0.001);
        Assert.Empty(item.Allocations);
        Assert.Null(item.SourceUnit);
        Assert.Equal(0, item.SourceQtyInUnit, 0.001);
        Assert.Equal(0, item.SourceUnitWeightKg, 0.001);
        Assert.Equal(0, item.SourceQtyKg, 0.001);
        Assert.Equal(0, db.Lots.Single(l => l.Id == lotId).ReservedQtyKg, 0.001);
        Assert.Equal("Draft", db.ProductionPlans.Single(p => p.Id == planId).Status);
    }
}
