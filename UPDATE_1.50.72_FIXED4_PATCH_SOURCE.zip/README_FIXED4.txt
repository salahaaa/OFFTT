﻿=========================================================================
 UPDATE_1.50.72_FIXED4_PATCH_SOURCE — نسخة البناء (5) — آخر 9 أخطاء
 التاريخ: 18/09/2026 · الفرع: arena/01a0ac34-offtt
=========================================================================

 الأخطاء التسعة المتبقية كانت كلها انزياح API في ملفات الاختبارات
 (الاختبارات كُتبت على نموذج أقدم من النموذج الحالي) — وبناءك يثبت
 أن بقية الحل سليم (0 أخطاء في src/tools).

 ما رُمّم في هذه الحزمة (6 ملفات — usings/ملاءمة للنموذج فقط،
 ولا تغيير إطلاقاً في منطق النظام العامل):
 1) DeliveryPickingDirectiveTests.cs        + using Microsoft.Extensions.DependencyInjection;
 2) UsersSecurityDelegationAuditTests.cs     + using Microsoft.Extensions.DependencyInjection;
 3) FullCycleFourCustomersAcceptanceTests.cs + using Microsoft.Extensions.DependencyInjection;
    (السبب: CreateScope() دالة امتداد من هذا الماسورة — بلا using لا توجد)
 4) UnitsGoldenRuleTests.cs                  + using Microsoft.Extensions.DependencyInjection;
 5) LayeredWriteEnforcementTests.cs          + using Microsoft.EntityFrameworkCore;
    (السبب: AsNoTracking() امتداد EF — بلا using لا يوجد)
 6) PlanningFifoTests.cs: أُزيلت ProductionDate الميتة من initializers
    الدفعتين. لماذا هذا هو الإصلاح الصحيح:
    - نموذج Lot الحالي لا يملك ProductionDate (لذلك الخطأ CS0117).
    - منطق FIFO الذي يختبره الاختبار يرتّب فعلياً حسب
      Shipment.ArrivalDate (PlanningService: OrderBy(ArrivalDate))،
      والتواريخ الصحيحة معبأة أصلاً في ship1/ship2 داخل الاختبار.
    - إزالة السطرين لا تغيّر نتيجة الاختبار ولا تضيف خاصية وهمية:
      الاختبار يقيس نفس السلوك على النموذج الحالي كما هو.

 ملاحظة: ReportsAuditDirectiveTests.cs (مُرمَّمة في FIXED3) عاد مطابقاً
 لقاعدة 1.50.67 — أُبقيت في الحزمة صراحةً لتبقى الحزمة كاملة لأي أساس.

 فحص شامل بعد الإصلاح للتأكد ألا انزياح آخر:
 - كل طرق الاختبارات المشبوهة روجعت مقابل تعريف الواجهات الفعلية:
   موجودة كلها (CloseProductionDay، SaveCheck، Receive، Update،
   UpdatePlan، GetDailyPlan، UpdatePlanItem، CancelOrder، Login،
   UnapproveShipment، DeleteDraft، GetProductLotRemaining...).
 - initializers الكيانات مقابل خصائص النماذج الحالية: 0 مشكلة.
 - سلاسل/escape/أقواس لملفات الإصلاح الستة: 0 مشكلة.
 - CreateScope/AsNoTracking بلا using: 0 متبقٍ.
 (تنبيه صادق: بيئة التحضير بلا .NET SDK — البوابة هي بناءك على Windows.
  إن بقي خطأ فأرسل القائمة كاملة حرفيًا.)

 تسلسل الاستخدام على Windows:
 1) فكّ الحزمة فوق UPDATE_WORK.
 2) VERIFY-SOURCE-1.50.72.bat → 5× [OK] ثم [PASS].
 3) dotnet build DatesErp.sln -c Release --no-incremental
    → متوقع: Build succeeded — 0 Error.
 4) فقط عند 0 Error: BUILD-PUBLISH-1.50.72-WINDOWS.bat ثم تشغيل
    MfgSystem.exe من publish_1.50.72\ واختباره.
 5) لا لمس publish_FINAL ولا نسخة 1.50.71 العاملة قبل نجاح 3+4.

 المحتوى (93 مدخلاً): 90 ملف مصدر/اختبار/أداة + الباتان + README.
=========================================================================
