إصلاح تعارض وزن الكرتون في شاشة تخطيط الإنتاج — مصدر فقط

المحتويات:
- src/DatesErp.Desktop/Mvvm/PlanningRows.cs
- src/DatesErp.Desktop/Views/Screens/PlanningView.xaml.cs
- tests/DatesErp.Tests/PlanningPackSpecsAndLockTests.cs

التعديل يوحّد وزن الكرتون المعروض والمحسوب مع UnitsPolicy: تستخدم العبوة الافتراضية/المحددة إذا كانت معرّفة، وإلا يستخدم وزن بطاقة الصنف؛ ولا يختار أول عبوة عامة بالتخمين.

هذه حزمة مصدر وليست EXE أو Publish. لم يُشغّل Build أو Test في Arena لعدم توفر أدوات .NET. لا تُستبدل بها نسخة التشغيل؛ ادمج الملفات المطابقة، ثم ابنِ واختبر محلياً قبل أي نشر. لم تُعدّل قاعدة البيانات أو إعدادات الاتصال.
