﻿UPDATE_1.50.72_PATCH_SOURCE.txt
================================
Patch source-only for version 1.50.72 — fix of all 19 post-plan inspection findings + fix of the
Arabic text corruption (BOM). Apply on top of UPDATE_WORK (source 1.50.68-1.50.71).

WHAT THIS PATCH CONTAINS (25 source files — full files, not diffs):
---------------------------------------------------------------
A) Arabic corruption fix (BOM) — the "save button still garbled" problem:
   1. src/DatesErp.Desktop/Views/Screens/PlanningView.xaml     + UTF-8 BOM
   2. src/DatesErp.Desktop/Views/LotPickerWindow.xaml          + UTF-8 BOM (the lot selection window)
   3. src/DatesErp.Desktop/Themes/DateErpTheme.xaml            + UTF-8 BOM
   4. src/DatesErp.Desktop/App.xaml                             + UTF-8 BOM
   Content is byte-identical except the 3-byte BOM. Without it the WPF XAML compiler on an
   Arabic Windows reads these files as cp1256 -> every Arabic string in them renders garbled.

B) P1 (critical):
   5. src/DatesErp.Application/Services/CustomerDeliveryService.cs
      P1-1: quality gate + plan sync + unsync now derive each item's order/plan from the item's
      own lot (mixed multi-order vouchers no longer pass through the header order's checks).
   6. src/DatesErp.Application/Services/QualityGate.cs
      P1-1: the approved-accepted qty cap is scoped to the item's own order first.
   7. src/DatesErp.Desktop/Views/Screens/FinishedGoodsView.xaml.cs
      P1-2: partial delivery sends PROPORTIONAL cartons (the "half" button no longer gets
      silently replaced by the full produced quantity); "available" now = actually-received kg.
   8. src/DatesErp.Desktop/Views/Screens/FGReceiveView.xaml.cs
      P1-2: same proportional-cartons fix + same available-quantity fix (direct path).

C) P2 (high):
   9. src/DatesErp.Application/Services/DeliveryPickService.cs
      P2-1: FG receipt date query uses IsApproved (receipts are never Status="Approved" -> the
      date/stage-days columns were always "-" and FIFO broken).
      P2-2: final-check filter uses IsApproved + CheckType containing "نهائي" (the exact match
      "نهائي" never matched the real values -> grade column always "awaiting inspection").
   10. src/DatesErp.Application/Services/ReportService.cs
      P2-2: same filter fix in the customer delivery report.
   11. src/DatesErp.Application/Services/ExecutionService.cs
      P2-3: day-close aux reconciliation can no longer drive WAUX negative (explicit refusal
      with a clear message instead of a silent negative balance).
      P3-6: raw-consumption fallback to planned is now TAGGED in the ledger note AND in the
      close-result message (was a silent drift).
   12. src/DatesErp.Application/Services/InspectionService.cs
      P2-4: invalid decision strings are rejected (no silent "Passed"); a check with rejected
      cartons saved as "Passed" now returns an explicit warning.

D) P3 (medium):
   13. src/DatesErp.Desktop/Views/Screens/DeliveryView.xaml.cs
      P3-1: batch-picker rows now get the lot's carton weight (editing cartons no longer
      silently zeroes the weight).
      P3-3: rows without valid cartons are reported before save (no more silent exclusion).
      P4-1: the 60s auto-save draft (DeliveryDraft_*.json) is REMOVED (consistency with the
      planning screen decision).
      P4-2: opening a delivery now pre-checks carton weights with a friendly message (no
      generic exception with a half-loaded form).
      P4-6: kg-only balances (no carton weight defined) are surfaced in the balance chip
      instead of hiding real quantity.
   14. src/DatesErp.Application/Services/FinishedGoodsService.cs
      P3-2: the success message no longer claims "quality approved" while the check is still
      pending (cooling period); the dead coolingNote variable is now used.
   15. src/DatesErp.Application/Services/ProductionOrderService.cs
      P3-4: if a product has NEW-system auxiliary requirements they are the only source
      (the legacy ConsumptionFormula path is skipped for that product -> no double issue).
   16. src/DatesErp.Desktop/Views/Screens/ProductBOMView.xaml
      P3-5: the quantity field label follows the calculation method ("per kg" when per-kg is
      selected) so per-kg values are not entered under a "per carton" label (x8 over-issue).
   17. src/DatesErp.Desktop/Views/Screens/ProductBOMView.xaml.cs
      P3-5: the label/hint/error-message handler for the calculation method.
   18. src/DatesErp.Desktop/Views/Screens/QualityView.xaml.cs
      P2-4: a check containing rejected cartons must have an EXPLICIT decision before save.
      P4-3: the prefilled "all accepted" values are now flagged in the status line.

E) P4 (low):
   19. src/DatesErp.Desktop/Views/QCWindow.xaml.cs
      P2-4: the save confirmation warns when rejected kg exist under a "Passed" decision.
      P4-4: client-side cap — inspected quantity cannot exceed the remaining uninspected.
   20. src/DatesErp.Application/Services/PlanProgressService.cs
      P4-5: MarkInvoiced runs read+increment+save inside one transaction (no double invoice
      under concurrency).

F) Version + previous-round files (kept from the 1.50.71 patch so this zip is cumulative):
   21. src/DatesErp.Desktop/DatesErp.Desktop.csproj            Version -> 1.50.72
   22. src/DatesErp.Desktop/Services/BuildInfo.cs              dynamic version stamp
   23. src/DatesErp.Desktop/Views/Screens/PlanningView.xaml.cs P1 fingerprint guard
   24. audit/UnitRuleAudit/Program.cs
   25. audit/UnitRuleAudit/UnitRuleAudit.csproj

HOW TO APPLY (same proven method):
1. Copy the 25 files over UPDATE_WORK keeping the exact paths (extract over the root).
2. Build + publish: run BUILD-PUBLISH-1.50.72-WINDOWS.bat on LENOVO (or:
   dotnet build DateERP.sln -c Release && dotnet build DatesErp.sln -c Release &&
   dotnet publish src\DatesErp.Desktop\DatesErp.Desktop.csproj -c Release -r win-x64
   --self-contained true -o publish_1.50.72).
3. The build bat produces UPDATE_1.50.72_PACKAGE\ with the one-click update bat.
4. Deploy with UPDATE-1.50.72-ONECLICK.bat (copy-only; it NEVER deletes anything from the
   run folder; DB and config are excluded and live outside the run folder anyway).
5. Verify in the app: title bar shows 1.50.72; the planning screen Arabic (save button
   included) is readable; a half-delivery in Finished Goods stays half.

DATA SAFETY (unchanged guarantee):
- No schema change, no migration, no seed change.
- The update copies application files only; mfgsystem_local.db / config.json are excluded
  explicitly and also live in %LocalAppData% (outside the run folder).
- If anything fails mid-update, the previous version files remain untouched (copy-only).

NOTE ON THE PREVIOUS UPDATE FAILURE:
The one-click bat now logs every step to update_1.50.72.log (app closed? copy size check?
launch?) — if the update fails again, that log will say exactly where.
