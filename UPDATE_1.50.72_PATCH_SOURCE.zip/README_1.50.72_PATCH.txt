﻿=========================================================================
 تحديث المصدر 1.50.72 — حزمة مكمَّلة (الفروقات الكاملة 1.50.67 → 1.50.72)
 التاريخ: 18/09/2026 · الفرع: arena/01a0ac34-offtt
=========================================================================

 لماذا هذه النسخة من الحزمة؟
 - الحزمة الأولى (25 ملفاً) كانت تدريجية: افترضت أن UPDATE_WORK تحمل مصادر
   1.50.68–1.50.71 كاملة. بعد فشل تحديث 1.50.71 وعدم التأكد من حالة
   UPDATE_WORK، أُعيد بناؤها كاملة: كل ملف اختلف بين مصدر 1.50.67 الرسمي
   والمصدر الحالي — 90 ملفاً، أسماء مسارات أصلية.
 - التطبيق فوق UPDATE_WORK يعمل من أي أساس (1.50.67 أو 1.50.71):
   النتيجة النهائية = المصدر الحالي حرفياً (تحقق بايت‑بايت لكل مدخل).

 ⚠ أهم ملف في الحزمة — رسالة «حدث خطأ أثناء تنفيذ العملية» عند حفظ الخطة:
 - src/DatesErp.Application/Services/PlanningService.cs
   إصلاح §1.50.70: «Math.Max داخل Sum لا يُترجم في EF Core» (خطأ
   System.Data...SqlException: The specified LINQ expression ... Math.Max ...
   could not be translated) يظهر عند حفظ خطة فيها بند لدفعة قيد المعالجة.
   النسقة المشغّلة 1.50.67 ما قبل هذا الإصلاح — لذلك ظهر الخطأ عندك،
   ومع بناء هذه الحزمة يختفي. (تقييم الكمية أصبح عميلياً: ToList ثم Sum.)

 ما الجديد 1.50.68 → 1.50.72 (ملخص):
 1) 1.50.68–1.50.70: 12 ملاحظة من تقرير 24 ساعة (وزن الكرتون من
    PackagingType بدل 7.5/5kg الثابتة، رفض القيمة 0 كغير معرَّفة، قاعدة
    completeRows، تحذير فوري عند عدم تطابق وزن الكرتون/العبوة) + إصلاح Math.Max.
 2) 1.50.71: دمج مصادر 1.50.68–71 + إصلاحات P1/P4 + إعادة بناء شاشة التخطيط
    من الصفر (§B66) + بصمة الإنشاء/الاعتماد (§B75) + فرض نطاق العميل الواحد
    من الخلفية (§B76) + حارس تواريخ البنود داخل الفترة (§B80) + تنبيهات الطاقة
    غير المعرَّفة (§B85/H4) + إصلاح SaveAsTemplate (int? ) .
 3) 1.50.72: الملاحظات الـ19 (P1×2 حرج، P2×4 عالٍ، P3×6، P4×7) —
    التفاصيل الكاملة في FIXES_1.50.72_AR.md بجذر المستودع.
 4) استعادة BOM (UTF-8) لأربعة XAML — سبب تشفير النصوص العربية
    (زر الحفظ، نافذة الدفعة، الثيم، شاشة التخطيط).

-------------------------------------------------------------------------
 الملفات المجموعة في 1.50.72 (21) — السبب لكل ملف:
  src/DatesErp.Application/Services/CustomerDeliveryService.cs  —  P1-1 بوابة الجودة لكل بند على أمر دفعته
  src/DatesErp.Application/Services/DeliveryPickService.cs  —  P2-1 تاريخ IsApproved + P2-2 فلترة «نهائي»
  src/DatesErp.Application/Services/ExecutionService.cs  —  P2-3 حارس WAUX السالب + P3-6 وسم «بالمخطط»
  src/DatesErp.Application/Services/FinishedGoodsService.cs  —  P3-2 رسالة نجاح بفترة التبريد
  src/DatesErp.Application/Services/InspectionService.cs  —  P2-4 قرار الفحص (رفض غير صالح/تحذير مرفوضات)
  src/DatesErp.Application/Services/PlanProgressService.cs  —  P4-5 فوترة داخل معاملة واحدة
  src/DatesErp.Application/Services/ProductionOrderService.cs  —  P3-4 منع ازدواج صرف الأصناف المساعدة
  src/DatesErp.Application/Services/QualityGate.cs  —  P1-1 أولوية الدفعة/الأمر في سقف «المطابق المعتمد»
  src/DatesErp.Application/Services/ReportService.cs  —  P2-2 تقرير التسليمات بنفس الفلترة
  src/DatesErp.Desktop/App.xaml  —  استعادة BOM (تشفير النصوص)
  src/DatesErp.Desktop/DatesErp.Desktop.csproj  —  رفع الإصدار إلى 1.50.72
  src/DatesErp.Desktop/Themes/DateErpTheme.xaml  —  استعادة BOM + ثيم موحّد
  src/DatesErp.Desktop/Views/LotPickerWindow.xaml  —  استعادة BOM (تشفير نصوص نافذة الدفعة)
  src/DatesErp.Desktop/Views/QCWindow.xaml.cs  —  P2-4 + P4-4 سقف محلي للمفحوص
  src/DatesErp.Desktop/Views/Screens/DeliveryView.xaml.cs  —  P3-1 وزن الكرتون من الدفعة + P3-3 بلا بنود صامتة + P4-1 إزالة الحفظ التلقائي + P4-2 فحص الأوزان + P4-6
  src/DatesErp.Desktop/Views/Screens/FGReceiveView.xaml.cs  —  P1-2 كراتين تناسبية + متاح = Σ ReceivedQtyKg
  src/DatesErp.Desktop/Views/Screens/FinishedGoodsView.xaml.cs  —  P1-2 كراتين تناسبية + المتاح
  src/DatesErp.Desktop/Views/Screens/PlanningView.xaml  —  استعادة BOM + إعادة بناء §B66 + شرائح الحالة
  src/DatesErp.Desktop/Views/Screens/ProductBOMView.xaml  —  P3-5 أوسمة شاشة BOM
  src/DatesErp.Desktop/Views/Screens/ProductBOMView.xaml.cs  —  P3-5 حسابات/رسائل BOM
  src/DatesErp.Desktop/Views/Screens/QualityView.xaml.cs  —  P2-4 منع الحفظ بمرفوضات + P4-3 تمييز المعبأ مسبقاً
-------------------------------------------------------------------------
 مصادر 1.50.68–1.50.71 (56) — نظام الوحدات + 12 ملاحظة + إعادة بناء
 شاشة التخطيط/الثيم + إصلاحات الدمج (تفصيلها في UPDATES_1.50.71_INSPECTION_AR.md):
  src/DatesErp.Application/Services/PlanningService.cs
  src/DatesErp.Application/Services/ReportServiceOperations.cs
  src/DatesErp.Application/Services/UnitsPolicy.cs
  src/DatesErp.Desktop/Mvvm/PlanningRows.cs
  src/DatesErp.Desktop/Services/AutoBackup.cs
  src/DatesErp.Desktop/Services/BuildInfo.cs
  src/DatesErp.Desktop/Views/AuxAdminWindow.xaml
  src/DatesErp.Desktop/Views/ConnectionSetupWindow.xaml
  src/DatesErp.Desktop/Views/CustomerAvailabilityWindow.xaml
  src/DatesErp.Desktop/Views/DeliveryReviewWindow.xaml
  src/DatesErp.Desktop/Views/ErpChrome.xaml
  src/DatesErp.Desktop/Views/FinishedBatchPickerWindow.xaml
  src/DatesErp.Desktop/Views/InputDialog.xaml
  src/DatesErp.Desktop/Views/LoginWindow.xaml
  src/DatesErp.Desktop/Views/MainWindow.xaml
  src/DatesErp.Desktop/Views/OrderDetailWindow.xaml
  src/DatesErp.Desktop/Views/PlanDetailWindow.xaml
  src/DatesErp.Desktop/Views/PrintPreviewWindow.xaml
  src/DatesErp.Desktop/Views/ProductPickerWindow.xaml
  src/DatesErp.Desktop/Views/QCWindow.xaml
  src/DatesErp.Desktop/Views/ReceiptWindow.xaml
  src/DatesErp.Desktop/Views/Screens/AuditFilterView.xaml
  src/DatesErp.Desktop/Views/Screens/AuxiliarySetupView.xaml
  src/DatesErp.Desktop/Views/Screens/BackupView.xaml
  src/DatesErp.Desktop/Views/Screens/CartonView.xaml
  src/DatesErp.Desktop/Views/Screens/CustomerCartonMappingView.xaml
  src/DatesErp.Desktop/Views/Screens/DashboardView.xaml
  src/DatesErp.Desktop/Views/Screens/DeliveryView.xaml
  src/DatesErp.Desktop/Views/Screens/FGReceiveView.xaml
  src/DatesErp.Desktop/Views/Screens/FinishedGoodsView.xaml
  src/DatesErp.Desktop/Views/Screens/GenericListView.xaml
  src/DatesErp.Desktop/Views/Screens/ItemsCapacitiesView.xaml
  src/DatesErp.Desktop/Views/Screens/ItemsView.xaml
  src/DatesErp.Desktop/Views/Screens/ItemsView.xaml.cs
  src/DatesErp.Desktop/Views/Screens/MaterialsView.xaml
  src/DatesErp.Desktop/Views/Screens/MyTasksView.xaml
  src/DatesErp.Desktop/Views/Screens/OrdersView.xaml
  src/DatesErp.Desktop/Views/Screens/PermissionsView.xaml
  src/DatesErp.Desktop/Views/Screens/PlanClosureView.xaml
  src/DatesErp.Desktop/Views/Screens/PlanningView.Capacity.cs
  src/DatesErp.Desktop/Views/Screens/PlanningView.xaml.cs
  src/DatesErp.Desktop/Views/Screens/ProductionAuxiliaryView.xaml
  src/DatesErp.Desktop/Views/Screens/QualityView.xaml
  src/DatesErp.Desktop/Views/Screens/ReceivingView.xaml
  src/DatesErp.Desktop/Views/Screens/ReceivingView.xaml.cs
  src/DatesErp.Desktop/Views/Screens/ReportsView.xaml
  src/DatesErp.Desktop/Views/Screens/ShiftsView.xaml
  src/DatesErp.Desktop/Views/Screens/ShipmentReportView.xaml
  src/DatesErp.Desktop/Views/Screens/SupplierMovementReportView.xaml
  src/DatesErp.Desktop/Views/Screens/SystemInfoView.xaml
  src/DatesErp.Desktop/Views/Screens/UsersView.xaml
  src/DatesErp.Desktop/Views/Screens/WarehouseVariablesView.xaml
  src/DatesErp.Desktop/Views/ShipmentPickerWindow.xaml
  src/DatesErp.Desktop/Views/SplashWindow.xaml
  src/DatesErp.Desktop/Views/TemplatePickerWindow.xaml
  src/DatesErp.Desktop/app.manifest
-------------------------------------------------------------------------
 اختبارات حديثة (11) — مطلوبة لبناء DateERP.sln/DatesErp.sln (كلاهما)
 يتضمن مشروع الاختبارات) — مخطوطات محدثة لقواعد 1.50.68–72:
  tests/DatesErp.Tests/DeliveryPickingDirectiveTests.cs
  tests/DatesErp.Tests/FullCycleFourCustomersAcceptanceTests.cs
  tests/DatesErp.Tests/LayeredWriteEnforcementTests.cs
  tests/DatesErp.Tests/OrdersScreenToolbarTests.cs
  tests/DatesErp.Tests/PlanClosureTests.cs
  tests/DatesErp.Tests/PlanningFifoTests.cs
  tests/DatesErp.Tests/PrintingApprovedDesignTests.cs
  tests/DatesErp.Tests/ReportsAuditDirectiveTests.cs
  tests/DatesErp.Tests/UiWiringTests.cs
  tests/DatesErp.Tests/UnitsGoldenRuleTests.cs
  tests/DatesErp.Tests/UsersSecurityDelegationAuditTests.cs
 أدوات:
  tools/PlanningAcceptance/ActualDeliveryScenarios.cs — سيناريوهات التخطيط
  tools/SqlFixes/1.50.66_StockBalance_PackagingType_Fix.sql — (اختياري) تصحيح
    أرصدة التغليف؛ شغّله فقط إن ظهرت مشكلة أرصدة قديمة على قاعدة SQL Server.
-------------------------------------------------------------------------
 طريقة التطبيق (نفس المنهج — لا حذف قاعدة بيانات ولا إعدادات):
 1) أغلق MfgSystem.exe.
 2) فكّ ضغط الحزمة فوق UPDATE_WORK (استبدال الملفات المتطابقة المسار فقط).
 3) شغّل BUILD-PUBLISH-1.50.72-WINDOWS.bat
    (يبني DateERP.sln + DatesErp.sln ثم ينشر MfgSystem.exe في publish_1.50.72\).
 4) شغّل UPDATE_1.50.72_ONECLICK\UPDATE-1.50.72-ONECLICK.bat
    (نسخ فقط، يستثني db/settings، يسجّل كل خطوة في update_1.50.72.log
    ويتحقق من تطابق حجم MfgSystem.exe بعد النسخ).
 5) تحقق بعد التشغيل: عنوان النافذة يعرض 1.50.72، النصوص العربية سليمة،
    واحفظ خطة فيها بند لدفعة قيد المعالجة → لا خطأ LINQ.

 ضمانات: لا ترحيل، لا بذور، لا لمس لقاعدة البيانات أو الإعدادات.
 فحص استاتيكي (لا dotnet في بيئة التحضير) — البناء والتشغيل على LENOVO.
