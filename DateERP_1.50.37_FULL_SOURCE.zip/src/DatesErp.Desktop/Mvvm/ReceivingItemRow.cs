#nullable enable annotations
using System.ComponentModel;
using DatesErp.Core.Common;

namespace DatesErp.Desktop.Mvvm;

/// <summary>حقول المعالجة في صف الاستلام نفسه. لا افتراض نعم/لا من بطاقة الصنف.</summary>
public sealed class ReceivingItemRow : INotifyPropertyChanged
{
    private int _rowNo;
    private bool _isEditable;
    private bool? _treatmentRequired;
    private DateTime? _until;
    private string _status = "مستلم", _state;
    public int ShipmentItemId { get; set; }
    public int RowNo { get => _rowNo; set { _rowNo = value; Raise(nameof(RowNo)); } }
    public int ProductId { get; set; }
    public int? PackId { get; set; }
    public string ProductCode { get; set; }
    public string ProductName { get; set; }
    public string PackName { get; set; }
    public string ReceiptUnit { get; set; }
    public int PackageCount { get; set; }
    public double UnitWeightKg { get; set; }
    public double QtyKg { get; set; }
    public string Status { get => _status; set { _status = value; Raise(nameof(Status)); } }
    public bool HasLegacyTreatment { get; set; }
    public bool? TreatmentRequired
    {
        get => _treatmentRequired;
        set
        {
            _treatmentRequired = value;
            if (value != true) _until = null;
            _state = null;
            Raise(nameof(TreatmentRequired)); Raise(nameof(TreatmentChoiceAr)); Raise(nameof(ShowUntilDate));
            Raise(nameof(TreatmentUntilDate)); Raise(nameof(TreatmentStateAr));
        }
    }
    public string? TreatmentChoiceAr
    {
        get => TreatmentRequired == null ? null : TreatmentRequired.Value ? "نعم" : "لا";
        set => TreatmentRequired = value switch { "نعم" => true, "لا" => false, _ => null };
    }
    public DateTime? TreatmentUntilDate
    {
        get => _until;
        set { _until = TreatmentRequired == false ? null : value?.Date; Raise(nameof(TreatmentUntilDate)); Raise(nameof(TreatmentStateAr)); }
    }
    public bool ShowUntilDate => TreatmentRequired == true || HasLegacyTreatment;
    public bool IsEditable { get => _isEditable; set { _isEditable = value; Raise(nameof(IsEditable)); } }
    public string TreatmentStateAr
    {
        get => _state ?? (TreatmentRequired == null ? "اختر نعم/لا" : TreatmentRequired == false ? "لا يحتاج معالجة"
            : TreatmentUntilDate == null ? "اختر حتى تاريخ" : "معالجة حتى " + TreatmentUntilDate.Value.ToString("dd/MM/yyyy"));
        set { _state = value; Raise(nameof(TreatmentStateAr)); }
    }
    public void ValidateTreatment(DateTime receiptDate)
        => ReceivingLineTreatmentPolicy.Validate(TreatmentRequired, TreatmentUntilDate, receiptDate);
    public event PropertyChangedEventHandler? PropertyChanged;
    private void Raise(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
