#nullable enable annotations
using System.Collections.ObjectModel;
using System.ComponentModel;
using DatesErp.Core.Interfaces.Services;
namespace DatesErp.Desktop.Views.Screens;

public class LotEditorRow : INotifyPropertyChanged
{
    public Func<int, string> QuantityGuard { get; set; }
    public string QuantityError { get; private set; }
    private PlanCapacityRow _capacity;
    public PlanCapacityRow Capacity { get => _capacity; set { _capacity = value; OnChange(nameof(Capacity)); OnChange(nameof(CapAlert)); OnChange(nameof(ProductCapacityDisplay)); } }
    private void GuardQuantity(int quantity)
    {
        QuantityError = quantity < 0 ? "الكمية لا يمكن أن تكون سالبة." : QuantityGuard?.Invoke(quantity);
        OnChange(nameof(QuantityError));
        if (!string.IsNullOrEmpty(QuantityError)) throw new ArgumentException(QuantityError);
    }

    public List<ProductOption> RawOptions { get; set; } = new();
    public bool CanChangeRaw => LotId == null;
    public Func<int, List<ProductOption>> LoadFinishedProducts { get; set; }
    private int? _rawProductId;
    public int? RawProductId
    {
        get => _rawProductId;
        set { if (_rawProductId == value) return; _rawProductId = value; ReloadFinishedProducts(); OnChange(nameof(RawProductId)); }
    }
    public string LinkMessage => RawProductId == null ? "اختر الصنف الخام أولاً." : AllProducts.Count == 0
        ? "لا توجد أصناف تامة مرتبطة بهذا الصنف الخام." : "";
    public void ReloadFinishedProducts()
    {
        List<ProductOption> next;
        try { next = RawProductId != null && LoadFinishedProducts != null ? LoadFinishedProducts(RawProductId.Value) : new(); }
        catch { ApplyLinkedProducts(new()); throw; }
        ApplyLinkedProducts(next);
    }
    private void ApplyLinkedProducts(List<ProductOption> next)
    {
        if (ProductId != null && !next.Any(p => p.Id == ProductId))
        { ProductId = null; CartonsText = "0"; IsChecked = false; }
        if (!AllProducts.Select(p => (p.Id, p.Name)).SequenceEqual(next.Select(p => (p.Id, p.Name)))) AllProducts = next;
        OnChange(nameof(LinkMessage));
    }

    // هوية الشحنة/الدفعة
    public int? LotId { get; set; }
    public int? ShipmentId { get; set; }
    public string ShipmentNo { get; set; }
    public string LotCode { get; set; }
    public int? CustomerId { get; set; }
    public string CustomerName { get; set; }
    public string RawName { get; set; }
    public double Available { get; set; }
    public string DaysInStockText { get; set; } = "";
    public string PresetDate { get; set; }

    // الوردية
    public List<ShiftOption> AllShifts { get; set; } = new();
    private int? _shiftId;
    public int? ShiftId
    {
        get => _shiftId;
        set { _shiftId = value; var hit = value != null ? AllShifts.FirstOrDefault(s => s.Id == value.Value) : null; if (hit != null) ShiftName = hit.Name; OnChange(nameof(ShiftId)); }
    }
    public string ShiftName { get; set; } = "—";
    private DateTime? _dateValue;
    public DateTime? DateValue
    {
        get => _dateValue;
        set { if (_dateValue == value) return; _dateValue = value; OnChange(nameof(DateValue)); Recalc(); }
    }

    // ═══ §المعالجة والتعقيم — حالة جاهزية الخام (أحمر) + منع الإنتاج قبل تاريخ المعالجة ═══
    public bool TreatmentRequired { get; set; }
    public DateTime? TreatmentUntilDate { get; set; }
    public DateTime? TreatmentReadyDate { get; set; }
    public double UnderTreatmentKg { get; set; }
    public bool TreatmentBlocked { get; private set; }
    public string TreatmentBlockReason { get; private set; }
    public string TreatmentDisplay
    {
        get
        {
            if (!TreatmentRequired) return "لا معالجة";
            bool under = UnderTreatmentKg > 0;
            if (!under) return "معالجة مكتملة ✓";
            DateTime? until = TreatmentBlockUntil();
            if (TreatmentBlocked) return $"🔴 قيد المعالجة حتى {until:dd/MM/yyyy}";
            return $"🟢 جاهز من {until:dd/MM/yyyy}";
        }
    }
    private DateTime? TreatmentBlockUntil()
    {
        DateTime? until = null;
        if (TreatmentUntilDate != null) until = TreatmentUntilDate;
        if (TreatmentReadyDate != null && (until == null || TreatmentReadyDate > until)) until = TreatmentReadyDate;
        return until?.Date;
    }
    private void RecalcTreatment()
    {
        var date = DateValue?.Date;
        var until = TreatmentBlockUntil();
        bool blocked = TreatmentRequired && UnderTreatmentKg > 0 && date.HasValue && until.HasValue
            && date.Value < until.Value;
        TreatmentBlocked = blocked;
        TreatmentBlockReason = blocked
            ? $"خام الدفعة قيد المعالجة حتى {until:dd/MM/yyyy} — لا يمكن الإنتاج قبل هذا التاريخ."
            : null;
        OnChange(nameof(TreatmentDisplay)); OnChange(nameof(TreatmentBlocked)); OnChange(nameof(TreatmentBlockReason));
    }

    // تعريف الصنف التام
    public Dictionary<int, string> ProductUnits { get; set; } = new();
    public string UnitDisplay => _productId != null && ProductUnits.TryGetValue(_productId.Value, out var u) && !string.IsNullOrWhiteSpace(u) ? u : "—";
    public Dictionary<int, double> PerProductAvailable { get; set; } = new();
    private bool _isChecked;
    public bool IsChecked
    {
        get => _isChecked;
        set
        {
            if (value && QuantityGuard != null && int.TryParse(CartonsText, out var q))
            { try { GuardQuantity(q); } catch (ArgumentException) { OnChange(nameof(IsChecked)); return; } }
            _isChecked = value; OnChange(nameof(IsChecked));
        }
    }

    private int? _productId;
    public int? ProductId
    {
        get => _productId;
        set { _productId = value; OnChange(nameof(ProductId)); OnChange(nameof(UnitDisplay)); RebuildPacks(); Recalc(); }
    }
    private ObservableCollection<PackOption> _packs = new();
    public ObservableCollection<PackOption> Packs { get => _packs; private set { _packs = value; OnChange(nameof(Packs)); } }
    private int? _packId;
    public int? PackId { get => _packId; set { _packId = value; OnChange(nameof(PackId)); Recalc(); } }

    // §الإنتاج (كرتون) — المدخل الوحيد. الوحدة والمواصفات تأتي تلقائياً من الصنف التام.
    private string _cartonsText = "0";
    public string CartonsText
    {
        get => _cartonsText;
        set
        {
            if (int.TryParse(value, out var q)) GuardQuantity(q);
            else { QuantityError = "أدخل عدداً صحيحاً من الكراتين."; OnChange(nameof(QuantityError)); }
            _cartonsText = value; OnChange(nameof(CartonsText)); Recalc();
            if (QuantityGuard != null && int.TryParse(value, out _)) IsChecked = q > 0;
        }
    }
    private double _computedKg;
    public double ComputedKg { get => _computedKg; private set { _computedKg = value; OnChange(nameof(ComputedKg)); } }

    // مواصفات الصنف التام (تلقائية من العبوة المختارة — لا يُدخلها المستخدم)
    public double PackWeight { get => _packWeight; private set { _packWeight = value; OnChange(nameof(PackWeight)); } }
    private double _packWeight;
    public int MoldsCount { get => _moldsCount; private set { _moldsCount = value; OnChange(nameof(MoldsCount)); } }
    private int _moldsCount;

    // الخام المطلوب + كفاية الخام (تلقائي)
    public double RawRequiredKg { get => _rawRequiredKg; private set { _rawRequiredKg = value; OnChange(nameof(RawRequiredKg)); } }
    private double _rawRequiredKg;
    public double RawShortageKg { get => _rawShortageKg; private set { _rawShortageKg = value; OnChange(nameof(RawShortageKg)); } }
    private double _rawShortageKg;
    public bool RawSufficient { get => _rawSufficient; private set { _rawSufficient = value; OnChange(nameof(RawSufficient)); } }
    private bool _rawSufficient;
    public string RawStatusText { get => _rawStatusText; private set { _rawStatusText = value; OnChange(nameof(RawStatusText)); } }
    private string _rawStatusText;

    // ═══ §سحب الخام (مصغّر) — الوحدة من سطر الاستلام، والكمية تُشتق من الإنتاج × وزن العبوة ═══
    public ShipmentQuantityContext Ctx { get; set; }
    public string ReceiptUnitText => string.IsNullOrWhiteSpace(Ctx?.ReceiptUnit) ? "—" : Ctx.ReceiptUnit;
    public double UnitWeight => Ctx?.UnitWeightKg ?? 0;
    public List<string> SourceModes { get; private set; } = new();
    private string _sourceMode;
    public string SourceMode
    {
        get => _sourceMode;
        set { if (_sourceMode == value) return; _sourceMode = value; OnChange(nameof(SourceMode)); OnChange(nameof(AvailableDisplay)); Recalc(); }
    }
    /// <summary>يبني خيارات طريقة السحب من وحدة الاستلام الفعلية (سلة/كرتون/كجم) + كجم.</summary>
    public void SetContext()
    {
        var m = new List<string>();
        string u = ReceiptUnitText;
        if (!string.IsNullOrWhiteSpace(u) && u != "—") m.Add(u);
        if (m.Count > 0 && !string.Equals(u, "كجم", StringComparison.OrdinalIgnoreCase)) m.Add("كجم");
        if (m.Count == 0) m.Add("كجم");
        SourceModes = m;
        if (string.IsNullOrEmpty(_sourceMode) || !m.Contains(_sourceMode)) _sourceMode = m[0];
        OnChange(nameof(SourceModes)); OnChange(nameof(SourceMode)); OnChange(nameof(ContextDisplay));
        OnChange(nameof(AvailableDisplay)); Recalc();
    }
    public string ContextDisplay => Ctx == null ? "—"
        : $"{ReceiptUnitText}: مستلم {Ctx.ReceivedUnits:N0} ({Ctx.ReceivedKg:N0} كجم) — متاح {Math.Floor(Ctx.AvailableUnits):N0} {ReceiptUnitText} ({Ctx.AvailableKg:N0} كجم)";
    /// <summary>المتاح يتغيّر مع طريقة السحب: بالوحدة (وحدات + كجم) أو بالكيلو فقط.</summary>
    public string AvailableDisplay
    {
        get
        {
            if (Ctx == null) return "—";
            bool units = !string.Equals(SourceMode, "كجم", StringComparison.OrdinalIgnoreCase);
            return units ? $"{Math.Floor(Ctx.AvailableUnits):N0} {ReceiptUnitText} / {Ctx.AvailableKg:N0} كجم" : $"{Ctx.AvailableKg:N0} كجم";
        }
    }

    // التتبع المحفوظ للسحب (يُشتق من الإنتاج × وزن العبوة — يُنقل إلى بند الخطة)
    public string SourceUnit { get; set; }
    public double SourceQtyInUnit { get; set; }
    public double SourceUnitWeightKg { get; set; }
    public double SourceQtyKg { get; set; }
    public string SourceError { get => _sourceError; private set { _sourceError = value; OnChange(nameof(SourceError)); } }
    private string _sourceError;

    // مراجع الحساب
    private List<ProductOption> _allProducts = new();
    public List<ProductOption> AllProducts { get => _allProducts; set { _allProducts = value; OnChange(nameof(AllProducts)); OnChange(nameof(LinkMessage)); } }
    public List<PackOption> AllPacks { get; set; } = new();
    private void RebuildPacks()
    {
        Packs = new ObservableCollection<PackOption>(ProductId == null ? new List<PackOption>() : AllPacks);
        var prod = ProductId != null ? AllProducts.FirstOrDefault(p => p.Id == ProductId) : null;
        int? prefer = prod?.DefaultPackagingTypeId;
        if (_packId != null && Packs.Any(p => p.Id == _packId)) { /* keep */ }
        else if (prefer != null && Packs.Any(p => p.Id == prefer)) _packId = prefer;
        else _packId = Packs.Count > 0 ? Packs[0].Id : (int?)null;
        OnChange(nameof(PackId));
    }

    public void Recalc()
    {
        int.TryParse(_cartonsText, out var ctn);
        var pack = AllPacks.FirstOrDefault(p => p.Id == _packId);
        var prod = _productId != null ? AllProducts.FirstOrDefault(p => p.Id == _productId) : null;
        // §v1.50.35: وزن العبوة وعدد القوالب من بطاقة الصنف التام (شاشة الأصناف)،
        // لا من أول عبوة عامة في جدول العبوات (كانت تُظهر 5.0 / 5 لكل الأصناف).
        double packW = (prod != null && prod.CartonWeightKg > 0) ? prod.CartonWeightKg : (pack?.UnitWeightKg ?? 0);
        PackWeight = packW;
        MoldsCount = (prod != null && prod.MoldsCount > 0) ? prod.MoldsCount : (pack?.MoldsCount ?? 0);
        ComputedKg = ctn > 0 && packW > 0 ? Math.Round(ctn * packW, 2) : 0;
        RawRequiredKg = ComputedKg;

        if (Ctx == null)
        {
            // بند بلا شحنة/دفعة (إدخال يدوي) — لا تتبع خام، ولا يُرسل أي سحب إلى الخلفية.
            SourceUnit = null; SourceUnitWeightKg = 0; SourceQtyKg = 0; SourceQtyInUnit = 0;
            RawShortageKg = 0; RawSufficient = true; _sourceError = null;
            RawStatusText = RawRequiredKg > 0 ? "— (بلا شحنة)" : "—";
        }
        else
        {
            // اشتقاق التتبع: الوحدة من سطر الاستلام، والكمية = الإنتاج × وزن العبوة.
            double uw = Ctx.UnitWeightKg;
            SourceUnit = Ctx.ReceiptUnit;
            SourceUnitWeightKg = uw;
            SourceQtyKg = RawRequiredKg;
            SourceQtyInUnit = uw > 0 ? Math.Round(RawRequiredKg / uw, 2) : 0;

            double availKg = Ctx.AvailableKg;
            var date = DateValue?.Date;
            var untilT = TreatmentBlockUntil();
            bool treatMatures = TreatmentRequired && UnderTreatmentKg > 0 && untilT.HasValue
                && date.HasValue && date.Value >= untilT.Value;
            // §بعد تاريخ المعالجة تُضاف الكمية التي ستكتمل إلى المتاح؛ قبلها تُحسب المتاح فقط.
            double availForRow = treatMatures ? availKg + UnderTreatmentKg : availKg;
            RawShortageKg = Math.Max(0, RawRequiredKg - availForRow);
            RawSufficient = RawRequiredKg <= 0 || availForRow <= 0 ? true : RawRequiredKg <= availForRow + 0.001;
            _sourceError = RawSufficient ? null
                : $"غير كافٍ — المطلوب {RawRequiredKg:N1} كجم / المتاح {availForRow:N1} كجم (عجز {RawShortageKg:N1} كجم)";
            RawStatusText = RawRequiredKg <= 0 ? "أدخل كمية الإنتاج"
                : RawSufficient ? "متوفر ✓" : "غير كافٍ ❌";
        }
        OnChange(nameof(PackWeight)); OnChange(nameof(MoldsCount)); OnChange(nameof(ComputedKg)); OnChange(nameof(ProductCapacityDisplay));
        OnChange(nameof(RawRequiredKg)); OnChange(nameof(RawShortageKg)); OnChange(nameof(RawSufficient));
        OnChange(nameof(RawStatusText)); OnChange(nameof(SourceError));
        RecalcTreatment();
    }

    private string _capAlert = "حدد الصنف والكمية…";
    public string CapAlert { get => QuantityError ?? Capacity?.Error ?? (Capacity == null ? "اختر الصنف والكمية" : $"الحد الأقصى {Capacity.MaximumCartons:N0} كرتون | المتبقي {Capacity.RemainingCartons:N0}"); private set { _capAlert = value; OnChange(nameof(CapAlert)); } }

    /// <summary>§v1.50.35 — طاقة الصنف بجوار الصنف التام في نافذة الاختيار.</summary>
    public string ProductCapacityDisplay
    {
        get
        {
            if (Capacity != null && Capacity.ProductCapacity > 0)
                return Capacity.ProductCapacity.ToString("N0") + " كرتون/وردية";
            var prod = _productId != null ? AllProducts.FirstOrDefault(p => p.Id == _productId) : null;
            if (prod != null && prod.HourlyRate > 0) return prod.HourlyRate.ToString("N0") + " كرتون/س";
            return "—";
        }
    }
    public bool IsOverCapacity => QuantityError != null || Capacity?.Error != null;

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnChange(string n) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}

public class ProductOption
{
    public int Id { get; set; }
    public string Name { get; set; }
    /// <summary>§v1.50.35 — مواصفات بطاقة الصنف التام (شاشة الأصناف) لا عبوة عامة.</summary>
    public double CartonWeightKg { get; set; }
    public int MoldsCount { get; set; }
    public double MoldWeightKg { get; set; }
    public double HourlyRate { get; set; }
    public int? DefaultPackagingTypeId { get; set; }
}
/// <summary>§B92 — خيار وردية في الاختيار اليدوي (الاسم يتضمن الساعات الفعالة لقرار الإدارة).</summary>
public class ShiftOption { public int Id { get; set; } public string Name { get; set; } }
public class PackOption { public int Id { get; set; } public string Name { get; set; } public double UnitWeightKg { get; set; } public int MoldsCount { get; set; } public double MoldWeightKg { get; set; } }


public class PlanRowUi : System.ComponentModel.INotifyPropertyChanged
{
    public Func<int, string> QuantityGuard { get; set; }
    public string QuantityError { get; private set; }
    private PlanCapacityRow _capacity;
    public PlanCapacityRow Capacity { get => _capacity; set { _capacity = value; OnChanged(nameof(Capacity)); } }
    private void GuardQuantity(int quantity)
    {
        QuantityError = quantity < 0 ? "الكمية لا يمكن أن تكون سالبة." : QuantityGuard?.Invoke(quantity);
        OnChanged(nameof(QuantityError));
        if (!string.IsNullOrEmpty(QuantityError)) throw new ArgumentException(QuantityError);
    }

    public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
    private void OnChanged(string n) => PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(n));

    private int _no;
    public int No { get => _no; set { if (_no != value) { _no = value; OnChanged(nameof(No)); } } }

    /// <summary>
    /// §B108 — معرّف بند الخطة المحفوظ (0 = صف جديد لم يُحفظ بعد).
    ///
    /// أُضيف عند حذف لوحة «بنود اليوم»: كان تعديل البند المحفوظ يمر حصراً عبر تلك اللوحة
    /// لأنها وحدها تحمل <c>PlanRowDto.ItemId</c>. وبدونه كان حذف اللوحة سيُسقط
    /// <c>UpdatePlanItem</c> من الواجهة كلياً — أي فقدان وظيفة لا تنظيفاً.
    /// </summary>
    public int ItemId { get; set; }

    public int? CustomerId { get; set; }
    public string CustomerName { get; set; }
    public int? ShipmentId { get; set; }
    public string ShipmentNo { get; set; }
    public int? LotId { get; set; }
    public int? RawProductId { get; set; }
    public string LotCode { get; set; }
    public string RawName { get; set; }
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    private int? _planPackId;
    public int? PackId { get => _planPackId; set { _planPackId = value; OnChanged(nameof(PackId)); } }
    public string PackName { get; set; }
    /// <summary>§B80: وحدة الصنف التام كما في بطاقته (شاشة الأصناف) — مثل «كرتون 5كجم».</summary>
    public string UnitDisplay { get; set; }
    public double QtyKg { get; set; }
    /// <summary>§B58: وزن كرتون الصنف لاشتقاق الكيلو عند تعديل الكراتين داخل الجدول.</summary>
    public double CartonWeight { get; set; }
    private int _cartons;
    public int Cartons { get => _cartons; set { if (_cartons != value) { GuardQuantity(value); _cartons = value; _cartonsText = value.ToString(); OnChanged(nameof(Cartons)); OnChanged(nameof(CartonsText)); } } }
    private string _cartonsText = "0";
    /// <summary>§B58: تحرير الكراتين داخل الجدول يعيد حساب الوزن المكافئ آلياً.</summary>
    public string CartonsText
    {
        get => _cartonsText;
        set
        {
            if (int.TryParse(value, out var proposed)) GuardQuantity(proposed);
            else { QuantityError = "أدخل عدداً صحيحاً من الكراتين."; OnChanged(nameof(QuantityError)); }
            if (_cartonsText == value) return;
            _cartonsText = value; OnChanged(nameof(CartonsText));
            if (int.TryParse(value, out var c) && c >= 0)
            {
                _cartons = c; OnChanged(nameof(Cartons));
                if (CartonWeight > 0) { QtyKg = Math.Round(c * CartonWeight, 1); OnChanged(nameof(QtyKg)); }
            }
        }
    }
    private string _date;
    public string Date
    {
        get => _date;
        set
        {
            if (_date == value) return;
            _date = value; OnChanged(nameof(Date));
            // §B80: المزامنة مع DatePicker — تحرير نصي أو اختيار من التقويم يحدّث الطرفين
            if (DatesErp.Core.Common.UiFormat.TryParseDate(value, out var dv)) { _dateValue = dv; OnChanged(nameof(DateValue)); }
        }
    }
    private DateTime? _dateValue;
    /// <summary>§B80: تاريخ الإنتاج كتاريخ حقيقي لعمود DatePicker — قابل للتعديل دائماً في الجدول.</summary>
    public DateTime? DateValue
    {
        get => _dateValue;
        set
        {
            if (_dateValue == value) return;
            _dateValue = value; OnChanged(nameof(DateValue));
            _date = value?.ToString("dd/MM/yyyy") ?? ""; OnChanged(nameof(Date));
        }
    }
    private int _shiftId;
    public int ShiftId { get => _shiftId; set { if (_shiftId != value) { _shiftId = value; OnChanged(nameof(ShiftId)); } } }
    public string ShiftName { get; set; }
    public string LineName { get; set; }
    private int _lineId;
    public int LineId { get => _lineId; set { if (_lineId != value) { _lineId = value; OnChanged(nameof(LineId)); } } }
    public int Priority { get; set; }

    // ═══ §تتبع سحب الخام من الشحنة — تُنقل إلى PlanItemDto وتُحفظ على البند ═══
    public string SourceUnit { get; set; }
    public double SourceQtyInUnit { get; set; }
    public double SourceUnitWeightKg { get; set; }
    public double SourceQtyKg { get; set; }
}

