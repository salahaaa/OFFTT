using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using PdfSharp.Drawing;
using PdfSharp.Pdf;

namespace DatesErp.Desktop.Printing;

/// <summary>One frozen page tree for preview, printer and PDF. Arabic shaping is performed by WPF, not PDFsharp.</summary>
public static class PrintRenderer
{
    private static readonly Brush Ink = Brush("#203846"), Green = Brush("#145C54"), Muted = Brush("#526572");
    private static Brush Brush(string hex) { var b=(SolidColorBrush)new BrushConverter().ConvertFromString(hex); b.Freeze(); return b; }
    private static Brush StatusBrush(string s)=> s==null?Ink
        :s.Contains("مسودة")?Brush("#B45309"):s.Contains("ملغى")?Brush("#B91C1C"):s.Contains("مقفل")?Brush("#475569"):Brush("#145C54");
    public static FormattedText Text(string value, double width, double size, bool bold=false, Brush foreground=null)
    {
        var ft=new FormattedText(value??"",CultureInfo.GetCultureInfo("ar-YE"),FlowDirection.RightToLeft,
            new Typeface(new FontFamily("Tahoma"),FontStyles.Normal,bold?FontWeights.Bold:FontWeights.Normal,FontStretches.Normal),size,foreground??Ink,1);
        ft.MaxTextWidth=Math.Max(1,width); ft.LineHeight=Math.Max(PrintLayout.LineHeight,Math.Ceiling(size*1.35));
        ft.TextAlignment=TextAlignment.Right; ft.Trimming=TextTrimming.None;
        return ft;
    }
    public static FixedDocument Build(PrintSpec spec)
    {
        ArgumentNullException.ThrowIfNull(spec);
        double w=spec.Landscape?PrintLayout.A4Height:PrintLayout.A4Width;
        double h=spec.Landscape?PrintLayout.A4Width:PrintLayout.A4Height;
        double contentW=w-PrintLayout.Margin*2;
        // Header and all cell measurements use precisely the same font, width and line spacing as drawing.
        var company=Text(spec.Company,contentW-64,18,true,Green);
        var title=Text(spec.Title,contentW,22,true,Green);
        // §v1.50.25: الحالة بخط أثقل ولون دالّ (معتمد أخضر/مسودة كهرماني/ملغى أحمر/مقفل رمادي) — والبيانات أوضح
        var status=Text(spec.Status,contentW,12.5,true,StatusBrush(spec.Status));
        var meta=Text($"{spec.Number}  |  نسخة: {spec.CapturedAt:dd/MM/yyyy HH:mm}",Math.Max(200,contentW-status.Width-14),12,false,Muted);
        double titleY=PrintLayout.Margin+Math.Max(48,company.Height)+8;
        double metaY=titleY+title.Height+5;
        double headerBottom=metaY+Math.Max(meta.Height,status.Height)+16;
        var pages=PrintLayout.Paginate(spec,headerBottom,(s,width,size,bold)=>
            Math.Max(1,(int)Math.Ceiling(Text(s,width,size,bold).Height/PrintLayout.LineHeight)));
        var doc=new FixedDocument(); doc.DocumentPaginator.PageSize=new Size(w,h);
        BitmapImage logo=null;
        if(spec.Logo is {Length:>0})
        {
            try { using var stream=new MemoryStream(spec.Logo); logo=new BitmapImage(); logo.BeginInit();logo.CacheOption=BitmapCacheOption.OnLoad;logo.StreamSource=stream;logo.EndInit();logo.Freeze(); }
            catch { logo=null; } // Company name remains visible if its optional logo is corrupt.
        }
        for(int pi=0;pi<pages.Count;pi++)
        {
            var visual=new DrawingVisual();
            using(var dc=visual.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White,null,new Rect(0,0,w,h));
                dc.DrawText(company,new Point(PrintLayout.Margin+64,PrintLayout.Margin));
                if(logo!=null)
                {
                    double scale=Math.Min(48/logo.Width,48/logo.Height);
                    dc.DrawImage(logo,new Rect(PrintLayout.Margin,PrintLayout.Margin,logo.Width*scale,logo.Height*scale));
                }
                dc.DrawText(title,new Point(PrintLayout.Margin,titleY)); dc.DrawText(status,new Point(PrintLayout.Margin,metaY)); dc.DrawText(meta,new Point(PrintLayout.Margin,metaY));
                dc.DrawLine(new Pen(Green,1.5),new Point(PrintLayout.Margin,headerBottom-8),new Point(w-PrintLayout.Margin,headerBottom-8));
                foreach(var band in pages[pi].Slices)
                {
                    bool bold=band.Style is "header" or "title" or "total" or "signature";
                    Brush bg=band.Style switch {"header"=>Green,"title"=>Brush("#E7F1EF"),"total"=>Brush("#FFF3D9"),"signature"=>Brushes.White,_=>band.RowIndex%2==0?Brushes.White:Brush("#F3F6F8")};
                    double x=w-PrintLayout.Margin;
                    for(int c=0;c<band.Cells.Length;c++)
                    {
                        x-=band.Widths[c]; var cell=new Rect(x,band.Y,band.Widths[c],band.Height);
                        dc.DrawRectangle(bg,new Pen(Brush("#8CA0AC"),0.75),cell); // §v1.50.25: مسطرة ظاهرة عند الطباعة (كانت 0.5 باهتة)
                        // Clip each line fragment only; all other lines are rendered on following pages.
                        dc.PushClip(new RectangleGeometry(new Rect(x+PrintLayout.Padding,band.Y+PrintLayout.Padding,band.Widths[c]-2*PrintLayout.Padding,band.LineCount*PrintLayout.LineHeight)));
                        var text=Text(band.Cells[c],band.Widths[c]-2*PrintLayout.Padding,band.FontSize,bold,band.Style=="header"?Brushes.White:Ink);
                        // Repeat a short first-cell identifier on continuation pages for traceability.
                        double offset=band.FirstLine*PrintLayout.LineHeight;
                        if(c==0 && band.Cells.Length>1 && text.Height<=PrintLayout.LineHeight) offset=0;
                        dc.DrawText(text,new Point(x+PrintLayout.Padding,band.Y+PrintLayout.Padding-offset));
                        dc.Pop();
                    }
                }
                dc.DrawLine(new Pen(Brush("#CBD6DE"),0.5),new Point(PrintLayout.Margin,h-37),new Point(w-PrintLayout.Margin,h-37));
                dc.DrawText(Text($"صفحة {pi+1} من {pages.Count}",contentW,11,false,Muted),new Point(PrintLayout.Margin,h-31));
            }
            var page=new FixedPage { Width=w,Height=h,Background=Brushes.White,FlowDirection=FlowDirection.LeftToRight };
            page.Children.Add(new DrawingPage(visual,w,h));
            page.Measure(new Size(w,h));page.Arrange(new Rect(0,0,w,h));page.UpdateLayout();
            var content=new PageContent();((IAddChild)content).AddChild(page);doc.Pages.Add(content);
        }
        return doc;
    }
    private sealed class DrawingPage : FrameworkElement
    {
        private readonly DrawingVisual _visual;
        public DrawingPage(DrawingVisual visual,double width,double height) { _visual=visual;Width=width;Height=height;AddVisualChild(visual); }
        protected override int VisualChildrenCount=>1;
        protected override Visual GetVisualChild(int index)=>index==0?_visual:throw new ArgumentOutOfRangeException(nameof(index));
    }
    public static BitmapSource RenderPage(DocumentPaginator paginator,int index,double dpi=300)
    {
        var page=paginator.GetPage(index);
        int width=(int)Math.Ceiling(page.Size.Width*dpi/96),height=(int)Math.Ceiling(page.Size.Height*dpi/96);
        var bitmap=new RenderTargetBitmap(width,height,dpi,dpi,PixelFormats.Pbgra32);
        var visual=new DrawingVisual();
        using(var dc=visual.RenderOpen())
        {
            dc.DrawRectangle(Brushes.White,null,new Rect(page.Size));
            dc.DrawRectangle(new VisualBrush(page.Visual) {Stretch=Stretch.Fill},null,new Rect(page.Size));
        }
        bitmap.Render(visual);bitmap.Freeze();return bitmap;
    }
    /// <summary>Faithful 300 DPI image PDF (not searchable text). Atomic replacement avoids partial output.</summary>
    public static void ExportPdf(FixedDocument document,string path,string title)
    {
        var paginator=document.DocumentPaginator; paginator.ComputePageCount();
        if(paginator.PageCount<1) throw new InvalidOperationException("لا صفحات للتصدير.");
        var full=Path.GetFullPath(path); var temp=full+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            using var pdf=new PdfDocument();pdf.Info.Title=title;pdf.Info.Subject="نسخة مطابقة للمعاينة — صور 300 DPI";
            for(int i=0;i<paginator.PageCount;i++)
            {
                var image=RenderPage(paginator,i);
                var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(image));
                using var buffer=new MemoryStream();encoder.Save(buffer);buffer.Position=0;
                var page=pdf.AddPage();page.Width=PdfSharp.Drawing.XUnit.FromPoint(paginator.PageSize.Width*72/96);page.Height=PdfSharp.Drawing.XUnit.FromPoint(paginator.PageSize.Height*72/96);
                using var ximage=XImage.FromStream(buffer);using var gfx=XGraphics.FromPdfPage(page);
                gfx.DrawImage(ximage,0,0,page.Width.Point,page.Height.Point);
            }
            pdf.Save(temp);File.Move(temp,full,true);
        }
        finally { if(File.Exists(temp)) File.Delete(temp); }
    }
}
