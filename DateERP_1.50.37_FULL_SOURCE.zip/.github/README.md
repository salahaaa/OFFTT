# التكامل المستمر

التعريف الوحيد المعتمد موجود في `.github/workflows/ci.yml`.
يبني الحل ويشغّل الاختبارات وأداتي القبول والتدقيق على Windows وLinux.
يدعم البناء المتقاطع لـWPF على Linux عبر `EnableWindowsTargeting`، لكن تشغيل الواجهة يحتاج Windows.

لا تُنشئ نسخاً أخرى من التعريف في `.github/ci.yml` أو `tools/ci/ci.yml`.
التعريف جاهز محلياً؛ تنفيذ GitHub Actions يبدأ بعد دفع الملفات إلى GitHub بصلاحية تعديل workflows.
