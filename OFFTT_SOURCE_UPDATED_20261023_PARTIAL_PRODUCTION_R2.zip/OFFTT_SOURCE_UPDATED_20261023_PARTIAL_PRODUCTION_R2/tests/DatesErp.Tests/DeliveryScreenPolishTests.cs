using System.IO;
using Xunit;

namespace DatesErp.Tests;

/// <summary>
/// حراس تصميم شاشتي تسجيل الفعلي وتسليم الإنتاج بعد فصل دورة العمل بينهما.
/// ١) جدول التسليم ذو مساحة عمل عملية ورسائل صريحة عند غياب تنفيذ قابل للتسليم.
/// ٢) الفرق عن المخطط ملوّن في شاشة إقفال الإنتاج.
/// ٣) المخرجات الثانوية تُسجل في شاشة الفعلي، وتُعرض في التسليم للقراءة فقط.
/// ٤) التواريخ في شريطي الكروم وساعة النافذة بصيغة ثابتة الاتجاه.
/// </summary>
public class DeliveryScreenPolishTests
{
    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null && !File.Exists(Path.Combine(dir.FullName, "DateERP.sln"))) dir = dir.Parent;
        return dir!.FullName;
    }

    private static string Read(string rel) => File.ReadAllText(Path.Combine(RepoRoot(), rel));

    [Fact]
    public void Items_Grid_Always_Keeps_A_Real_Working_Height()
    {
        string xaml = Read("src/DatesErp.Desktop/Views/Screens/ProductionDeliveryView.xaml");
        Assert.Contains("Height=\"260\" MinHeight=\"220\" RowHeight=\"32\"", xaml);
        Assert.Contains("VerticalScrollBarVisibility=\"Auto\"", xaml);
        string cs = Read("src/DatesErp.Desktop/Views/Screens/ProductionDeliveryView.xaml.cs");
        Assert.Contains("لا توجد أوامر إنتاج ذات تنفيذ فعلي محفوظ", cs);
        Assert.Contains("لا توجد كمية فعلية متبقية لإنشاء أمر تسليم جديد", cs);
    }

    [Fact]
    public void Difference_Column_Shows_An_Explicit_Color_State()
    {
        string xaml = Read("src/DatesErp.Desktop/Views/Screens/ProductionActualCloseView.xaml");
        string rows = Read("src/DatesErp.Desktop/Mvvm/ActualProductionRows.cs");
        Assert.Contains("DiffState", rows);
        Assert.Contains("Changed(nameof(DiffState))", rows);
        Assert.Contains("DataTrigger Binding=\"{Binding DiffState}\" Value=\"match\"", xaml);
        Assert.Contains("Value=\"gap\"", xaml);
        Assert.Contains("Value=\"invalid\"", xaml);
        Assert.Contains("Header=\"المتبقي بعد الجلسة\"", xaml);
    }

    [Fact]
    public void Secondary_Output_Is_Entered_At_Actual_Close_And_Read_Only_In_Delivery()
    {
        string closeXaml = Read("src/DatesErp.Desktop/Views/Screens/ProductionActualCloseView.xaml");
        string closeCs = Read("src/DatesErp.Desktop/Views/Screens/ProductionActualCloseView.xaml.cs");
        string deliveryXaml = Read("src/DatesErp.Desktop/Views/Screens/ProductionDeliveryView.xaml");
        string deliveryCs = Read("src/DatesErp.Desktop/Views/Screens/ProductionDeliveryView.xaml.cs");
        Assert.Contains("x:Name=\"SecondaryGrid\"", closeXaml);
        Assert.Contains("AddByProduct_Click", closeXaml);
        Assert.Contains("_secondary.Add(new ActualSecondaryRow())", closeCs);
        Assert.Contains("CanUserAddRows=\"False\"", deliveryXaml);
        Assert.Contains("SecondaryGrid.IsReadOnly = true", deliveryCs);
        Assert.Contains("لا يوجد ربط مخزني معتمد؛ لا يمكن التسليم أو الاستلام", deliveryCs);
    }

    [Fact]
    public void Chrome_Dates_Are_Invariant_And_Left_To_Right()
    {
        string chrome = Read("src/DatesErp.Desktop/Views/ErpChrome.xaml.cs");
        string main = Read("src/DatesErp.Desktop/Views/MainWindow.xaml.cs");
        // بعد توحيد الكروم، التاريخ وساعة النظام يوجدان في MainWindow فقط.
        Assert.Contains("\\u200E", main);
        Assert.Contains("CultureInfo.InvariantCulture", main);
        Assert.DoesNotContain("AuditText", chrome);
        Assert.DoesNotContain("UserText", chrome);
        Assert.DoesNotContain("DateTime.Now.ToString(\"dd/MM/yyyy HH:mm:ss\")", main);
    }
}
