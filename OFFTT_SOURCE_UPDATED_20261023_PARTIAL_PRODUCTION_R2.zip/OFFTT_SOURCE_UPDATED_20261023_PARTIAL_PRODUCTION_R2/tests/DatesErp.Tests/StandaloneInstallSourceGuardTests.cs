using System.IO;
using Xunit;

namespace DatesErp.Tests;

/// <summary>حراس مصدرية لوضع OFFTT المنفصل؛ لا تتصل بأي قاعدة بيانات.</summary>
public sealed class StandaloneInstallSourceGuardTests
{
    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null && !File.Exists(Path.Combine(dir.FullName, "DateERP.sln"))) dir = dir.Parent;
        return dir?.FullName ?? throw new DirectoryNotFoundException("لم يُعثر على جذر DateERP.sln.");
    }

    private static string Read(string relativePath) =>
        File.ReadAllText(Path.Combine(RepoRoot(), relativePath.Replace('/', Path.DirectorySeparatorChar)));

    [Fact]
    public void Standalone_Mode_Uses_Its_Own_Data_Folder_Without_Overriding_Test_Mode()
    {
        var config = Read("src/DatesErp.Infrastructure/Connection/AppConfig.cs");
        var entry = Read("src/DatesErp.Desktop/App.xaml.cs");
        int testFolder = config.IndexOf("if (IsolatedTestRun.IsEnabled)", StringComparison.Ordinal);
        int standaloneFolder = config.IndexOf("if (StandaloneInstall.IsEnabled)", testFolder, StringComparison.Ordinal);

        Assert.True(testFolder >= 0 && standaloneFolder > testFolder);
        Assert.Contains("StandaloneInstall.LocalDataFolder", config);
        Assert.Contains("StandaloneInstall.StartupSwitch", entry);
    }

    [Fact]
    public void Standalone_Mode_Is_SQL_Only_And_Does_Not_Discover_Or_Fallback()
    {
        var resolver = Read("src/DatesErp.Desktop/Services/AutoDbResolver.cs");
        int standalone = resolver.IndexOf("if (StandaloneInstall.IsEnabled)", StringComparison.Ordinal);
        int discovery = resolver.IndexOf("GetLocalSqlInstanceNames()", standalone, StringComparison.Ordinal);
        int normalDiscovery = resolver.IndexOf("GetLocalSqlInstanceNames()", StringComparison.Ordinal);

        Assert.True(standalone >= 0);
        Assert.True(normalDiscovery >= 0);
        Assert.Contains("StandaloneInstall.ProbeConfiguredDatabase(cfg)", resolver);
        Assert.Contains("لم يحدث رجوع إلى SQLite", resolver);
        Assert.True(discovery < 0 || discovery > standalone);
    }

    [Fact]
    public void Database_Identity_And_Empty_First_Run_Are_Checked_Before_Initialization()
    {
        var bootstrap = Read("src/DatesErp.Desktop/Services/Bootstrapper.cs");
        int verify = bootstrap.IndexOf("StandaloneInstall.VerifyTargetDatabase(activeConnection, AppConfig.Load())", StringComparison.Ordinal);
        int create = bootstrap.IndexOf("db.Database.EnsureCreated()", verify, StringComparison.Ordinal);
        int commit = bootstrap.IndexOf("StandaloneInstall.CommitTargetDatabase()", verify, StringComparison.Ordinal);
        int confirmedCreate = bootstrap.IndexOf("db.Database.EnsureCreated()", commit, StringComparison.Ordinal);
        int seed = bootstrap.IndexOf("DbSeeder.Seed(db)", verify, StringComparison.Ordinal);
        int migrate = bootstrap.IndexOf("SchemaMigrator.Migrate(db)", verify, StringComparison.Ordinal);
        var guard = Read("src/DatesErp.Infrastructure/Connection/StandaloneInstall.cs");

        Assert.True(verify >= 0 && create > verify && seed > verify && migrate > verify);
        Assert.True(commit > verify && confirmedCreate > commit,
            "يُحفظ ربط القاعدة بعد موافقة المستخدم وقبل إنشاء المخطط فقط.");
        Assert.Contains("SELECT DB_NAME()", guard);
        Assert.Contains("sys.tables WHERE is_ms_shipped = 0", guard);
        Assert.Contains("VIEW DEFINITION", guard);
        Assert.Contains("userTableCount != 0", guard);
        Assert.Contains("standalone-database.json", guard);
    }

    [Fact]
    public void Standalone_Mode_Does_Not_Read_Or_Delete_Previous_User_State()
    {
        var login = Read("src/DatesErp.Desktop/Views/LoginWindow.xaml.cs");
        var planning = Read("src/DatesErp.Desktop/Views/Screens/PlanningView.xaml.cs");
        var receiving = Read("src/DatesErp.Desktop/Views/Screens/ReceivingView.xaml.cs");

        Assert.Contains("IsolatedTestRun.IsEnabled || StandaloneInstall.IsEnabled", login);
        Assert.Contains("!StandaloneInstall.IsEnabled", login);
        Assert.Contains("IsolatedTestRun.IsEnabled || StandaloneInstall.IsEnabled", planning);
        Assert.Contains("IsolatedTestRun.IsEnabled || StandaloneInstall.IsEnabled", receiving);
    }

    [Fact]
    public void Windows_Installer_Publishes_To_A_New_Separate_Folder_Without_Old_Updater_Paths()
    {
        var installer = Read("Installer/Install-And-Open-OFFTT.ps1");

        Assert.Contains("'publish', $project", installer);
        Assert.Contains("win-x64", installer);
        Assert.Contains("OFFTT_LATEST_20261022", installer);
        Assert.Contains("--offtt-standalone", installer);
        Assert.Contains("-p:OFFTTStandalone=true", installer);
        Assert.Contains("OFFTT_STANDALONE_PACKAGE", Read("src/DatesErp.Desktop/DatesErp.Desktop.csproj"));
        Assert.Contains("موجود مسبقاً ولن يُستبدل", installer);
        Assert.DoesNotContain("DateERP_1.50.20_Full", installer);
        Assert.DoesNotContain("MfgSystem_Publish", installer);
    }
}
