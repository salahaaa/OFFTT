using DatesErp.Core.Common;
using DatesErp.Core.Domain.Enums;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Views.Screens;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
namespace DatesErp.Tests;
public class ActualProductionTests
{
    [Fact]
    public void Actual_Delivery_Persists_Stock_QC_Reports_And_Rolls_Back_Atomically()
    {
        using var host = new TestHost(); host.LoginAsAdmin(); int steps = 0;
        ActualDeliveryScenarios.Run(host.Services, (ok, message) => { Assert.True(ok, message); steps++; });
        Assert.True(steps >= 105);
    }
    [Fact]
    public void SaveActualProduction_Persists_ClosedExecutionState()
    {
        using var host = new TestHost();
        host.LoginAsAdmin();
        var db = host.Get<DatesErpDbContext>();
        FullWorkflowTests.SeedQuickOrderPacked(host, db, out var orderId, out _);

        var delivery = host.Get<IProductionDeliveryService>();
        var order = Assert.Single(delivery.GetActualDeliveryOrders().Where(o => o.OrderId == orderId));
        var input = new ActualProductionDto
        {
            OrderId = orderId,
            ConsumedRawKg = 500,
            Items = order.Items.Select(i => new ActualProductionItemDto
            {
                OrderItemId = i.OrderItemId,
                ActualCartons = i.PlannedCartons
            }).ToList()
        };

        var saved = delivery.SaveActualProduction(input);
        Assert.True(saved.Ok, saved.Message);

        db.ChangeTracker.Clear();
        var execution = Assert.Single(db.ProductionExecutions.AsNoTracking().Where(e => e.OrderId == orderId));
        Assert.True(execution.IsDayClosed);
        Assert.Equal(DocStatuses.Completed, execution.Status);
        Assert.NotNull(execution.EndDateTime);

        // Regression guard: closing the execution must close the production order and every item too.
        db.ChangeTracker.Clear();
        var persistedOrder = Assert.Single(db.ProductionOrders.AsNoTracking().Include(o => o.Items).Where(o => o.Id == orderId));
        Assert.True(persistedOrder.IsClosed);
        Assert.Equal(DocStatuses.Completed, persistedOrder.Status);
        Assert.NotEmpty(persistedOrder.Items);
        Assert.All(persistedOrder.Items, item =>
        {
            Assert.True(item.IsClosed);
            Assert.Equal(DocStatuses.Completed, item.Status);
        });
    }

    [Fact]
    public void Partial_Actual_Can_Be_Received_Before_Continuation_Without_Duplicate_Stock()
    {
        using var host = new TestHost();
        host.LoginAsAdmin();
        var db = host.Get<DatesErpDbContext>();
        FullWorkflowTests.SeedQuickOrderPacked(host, db, out var orderId, out var lotId);
        int planId = db.ProductionOrders.AsNoTracking().Where(o => o.Id == orderId)
            .Select(o => o.SourcePlanId).Single() ?? throw new InvalidOperationException("خطة الأمر غير موجودة.");
        var delivery = host.Get<IProductionDeliveryService>();
        var initial = Assert.Single(delivery.GetActualDeliveryOrders().Where(o => o.OrderId == orderId));
        var firstCounts = initial.Items.ToDictionary(i => i.OrderItemId, i => i.PlannedCartons / 2);
        var wfg = db.Warehouses.Single(w => w.WarehouseCode == "WFG").Id;
        double FinishedStock() => db.StockBalances.AsNoTracking()
            .Where(b => b.WarehouseId == wfg && b.CustomerId == 1 && b.ProductId == 3)
            .Sum(b => b.QtyKg);
        List<QualityItemDto> QualityRows(ActualDeliveryOrderDto source, Dictionary<int, int> counts)
            => source.Items.Where(i => counts.TryGetValue(i.OrderItemId, out var qty) && qty > 0).Select(i =>
            {
                int cartons = counts[i.OrderItemId];
                double kg = cartons * (i.PlannedQtyKg / i.PlannedCartons);
                return new QualityItemDto
                {
                    OrderItemId = i.OrderItemId,
                    ProductId = i.ProductId,
                    LotId = i.LotId,
                    CheckedQtyKg = kg,
                    AcceptedQtyKg = kg,
                    RejectedQtyKg = 0,
                    CheckedCartons = cartons,
                    AcceptedCartons = cartons,
                    RejectedCartons = 0
                };
            }).ToList();
        List<FinishedGoodsItemDto> ReceiptItems(ProductionDeliveryCard card)
            => card.Lines.Select(line => new FinishedGoodsItemDto
            {
                ProductId = line.ProductId,
                LotId = line.LotId,
                PackagingTypeId = line.PackagingTypeId,
                PackageCount = line.PackageCount,
                NetWeightKg = line.QtyKg,
                CustomerId = line.CustomerId,
                DeliveryItemId = line.Id
            }).ToList();
        double beforeReceipt = FinishedStock();

        // الجلسة الأولى تنتج نصف المخطط؛ تُفحص وتُسلَّم وتُستلم عبر المستندات الرسمية.
        var first = delivery.SaveActualProduction(new ActualProductionDto
        {
            OrderId = orderId,
            ConsumedRawKg = 250,
            Items = firstCounts.Select(x => new ActualProductionItemDto
                { OrderItemId = x.Key, ActualCartons = x.Value }).ToList()
        });
        Assert.True(first.Ok, first.Message);
        Assert.True(first.Id > 0);
        Assert.Equal(beforeReceipt, FinishedStock(), 1); // الفعلي لا ينشئ حركة لمخزن التام
        var quality = host.Get<IQualityService>();
        var q1 = quality.SaveCheck(orderId, first.Id, DateTime.Today.ToString("dd/MM/yyyy"), "نهائي",
            QualityRows(initial, firstCounts), lab: new QualityLabDto { Decision = "Passed" });
        Assert.True(q1.Ok, q1.Message);
        Assert.True(quality.ApproveCheck(q1.Id).Ok);

        var draft1 = delivery.CreateDeliveryFromActual(first.Id, DateTime.Today.ToString("dd/MM/yyyy"));
        Assert.True(draft1.Ok, draft1.Message);
        var card1 = delivery.GetDelivery(draft1.Id);
        Assert.Equal(initial.PlannedQtyKg / 2, card1.Lines.Sum(l => l.QtyKg), 1);
        Assert.True(delivery.IssueDelivery(draft1.Id).Ok);
        Assert.False(db.ProductionPlans.AsNoTracking().Single(p => p.Id == planId).IsClosed);
        var finishedGoods = host.Get<IFinishedGoodsService>();
        var receipt1 = finishedGoods.SaveReceipt(orderId, q1.Id, DateTime.Today.ToString("dd/MM/yyyy"),
            ReceiptItems(card1), draft1.Id);
        Assert.True(receipt1.Ok, receipt1.Message);
        Assert.True(finishedGoods.Issue(receipt1.Id).Ok);
        Assert.Equal(beforeReceipt, FinishedStock(), 1); // إنشاء/إصدار الاستلام لا يرحّل الرصيد
        Assert.True(finishedGoods.Receive(receipt1.Id, null).Ok);
        Assert.Equal(beforeReceipt + initial.PlannedQtyKg / 2, FinishedStock(), 1);

        // حتى بعد الاستلام الجزئي، يبقى الأمر والخطة مفتوحين لاستكمال المتبقي.
        db.ChangeTracker.Clear();
        var afterReceipt = Assert.Single(delivery.GetActualDeliveryOrders(orderId));
        Assert.True(afterReceipt.Recorded);
        Assert.True(afterReceipt.CanRecord);
        Assert.False(afterReceipt.CanCreateDelivery); // لا منتج جديد غير مسلَّم بعد
        Assert.Equal(initial.PlannedQtyKg / 2, afterReceipt.ActualQtyKg, 1);
        Assert.Equal(initial.PlannedQtyKg / 2, afterReceipt.StockReceivedQtyKg, 1);
        Assert.Equal(0, afterReceipt.RemainingQtyKg, 1);
        var secondCounts = afterReceipt.Items.ToDictionary(i => i.OrderItemId, i => i.PlannedCartons - i.ActualCartons);

        var second = delivery.SaveActualProduction(new ActualProductionDto
        {
            OrderId = orderId,
            ConsumedRawKg = 250,
            Items = secondCounts.Select(x => new ActualProductionItemDto
                { OrderItemId = x.Key, ActualCartons = x.Value }).ToList()
        });
        Assert.True(second.Ok, second.Message); // سند الاستلام السابق لا يمنع جلسة الاستكمال
        Assert.NotEqual(first.Id, second.Id);
        Assert.Equal(beforeReceipt + initial.PlannedQtyKg / 2, FinishedStock(), 1);

        db.ChangeTracker.Clear();
        var completed = Assert.Single(delivery.GetActualDeliveryOrders(orderId));
        Assert.False(completed.CanRecord);
        Assert.Equal(completed.PlannedQtyKg, completed.ActualQtyKg, 1);
        Assert.Equal(initial.PlannedQtyKg / 2, completed.StockReceivedQtyKg, 1);
        Assert.Equal(initial.PlannedQtyKg / 2, completed.RemainingQtyKg, 1);
        Assert.True(completed.CanCreateDelivery);
        var extra = delivery.SaveActualProduction(new ActualProductionDto
        {
            OrderId = orderId,
            ConsumedRawKg = 1,
            Items = completed.Items.Select(i => new ActualProductionItemDto
                { OrderItemId = i.OrderItemId, ActualCartons = 1 }).ToList()
        });
        Assert.False(extra.Ok); // بعد الاكتمال لا تُنشأ جلسة تنفيذ إضافية
        var executions = db.ProductionExecutions.AsNoTracking().Where(e => e.OrderId == orderId).ToList();
        Assert.Equal(2, executions.Count);
        Assert.All(executions, e => Assert.Equal(initial.PlannedQtyKg / 2, e.ActualQtyKg, 1));
        int halfCartons = initial.Items.Sum(i => i.PlannedCartons) / 2;
        Assert.All(executions, e => Assert.Equal(halfCartons, e.ActualCartons));
        Assert.Equal(2, executions.Select(e => e.DocumentNumber).Distinct().Count());
        var checks = db.QualityChecks.AsNoTracking().Where(q => q.OrderId == orderId).ToList();
        Assert.Equal(2, checks.Count);
        Assert.Equal(2, checks.Select(q => q.ExecutionId).Distinct().Count());

        var q2 = quality.SaveCheck(orderId, second.Id, DateTime.Today.ToString("dd/MM/yyyy"), "نهائي",
            QualityRows(afterReceipt, secondCounts), lab: new QualityLabDto { Decision = "Passed" });
        Assert.True(q2.Ok, q2.Message);
        Assert.True(quality.ApproveCheck(q2.Id).Ok);

        // مصدر التنفيذ الثاني يعرض الإجمالي التراكمي ناقص ما سُلِّم في الأول: لا ازدواج في PDL.
        var draft2 = delivery.CreateDeliveryFromActual(second.Id, DateTime.Today.ToString("dd/MM/yyyy"));
        Assert.True(draft2.Ok, draft2.Message);
        var visibleDraft = Assert.Single(delivery.GetActualDeliveryOrders().Where(o => o.OrderId == orderId));
        Assert.Equal(draft2.Id, visibleDraft.ProductionDeliveryId); // تبقى مسودة التسليم قابلة للفتح والتحرير
        var card2 = delivery.GetDelivery(draft2.Id);
        Assert.Equal(initial.PlannedQtyKg / 2, card2.Lines.Sum(l => l.QtyKg), 1);
        Assert.Equal(initial.Items.Sum(i => i.PlannedCartons) / 2, card2.Lines.Sum(l => l.PackageCount));
        Assert.True(delivery.IssueDelivery(draft2.Id).Ok);
        Assert.True(db.ProductionPlans.AsNoTracking().Single(p => p.Id == planId).IsClosed);
        var receipt2 = finishedGoods.SaveReceipt(orderId, q2.Id, DateTime.Today.ToString("dd/MM/yyyy"),
            ReceiptItems(card2), draft2.Id);
        Assert.True(receipt2.Ok, receipt2.Message);
        Assert.True(finishedGoods.Issue(receipt2.Id).Ok);
        Assert.Equal(beforeReceipt + initial.PlannedQtyKg / 2, FinishedStock(), 1);
        Assert.True(finishedGoods.Receive(receipt2.Id, null).Ok);
        Assert.Equal(beforeReceipt + completed.ActualQtyKg, FinishedStock(), 1);
        Assert.False(finishedGoods.Receive(receipt2.Id, null).Ok); // لا ترحيل مكرر بعد اكتمال السند
        Assert.Equal(beforeReceipt + completed.ActualQtyKg, FinishedStock(), 1);

        db.ChangeTracker.Clear();
        Assert.Equal(2, db.FinishedGoodsReceipts.AsNoTracking().Count(r => r.OrderId == orderId
            && r.Status != DocStatuses.Cancelled));
        Assert.Equal(2, db.ProductionDeliveries.AsNoTracking().Count(d => d.SourceType == DeliverySources.FromActual
            && db.ProductionExecutions.Any(e => e.Id == d.SourceId && e.OrderId == orderId)));
        Assert.Equal(2, db.ProductionExecutions.AsNoTracking().Count(e => e.OrderId == orderId));
        Assert.Equal(2, db.QualityChecks.AsNoTracking().Count(q => q.OrderId == orderId));
    }

    [Theory]
    [InlineData("")][InlineData("NaN")][InlineData("Infinity")][InlineData("-1")][InlineData("3001")][InlineData("2700.5")]
    public void Actual_UI_Row_Does_Not_Coerce_Invalid_Input(string value)
    {
        var row = new ActualProductionRow(new ActualDeliveryItemDto { PlannedCartons = 3000 }, false) { Actual = value };
        Assert.False(row.TryQuantity(out _)); Assert.NotEmpty(row.Error); Assert.Equal("—", row.Difference);
    }
    [Fact]
    public void Arabic_Digits_Are_Actual_Input_Not_Implicit_Planned_Quantity()
    {
        var row = new ActualProductionRow(new ActualDeliveryItemDto { PlannedCartons = 3000 }, false);
        Assert.Empty(row.Actual); row.Actual = "٢٧٠٠"; Assert.True(row.TryQuantity(out var quantity)); Assert.Equal(2700, quantity); Assert.Equal("300", row.Difference);
        Assert.True(ActualProductionRow.TryNonnegative("١٫٥", out var hours)); Assert.Equal(1.5, hours);
    }
    [Fact]
    public void Actual_UI_Continuation_Separates_Previous_Production_From_Current_Session()
    {
        var row = new ActualProductionRow(new ActualDeliveryItemDto
        {
            PlannedCartons = 100,
            ActualCartons = 40
        }, recorded: true, continuation: true);

        Assert.Equal(40, row.PreviouslyProduced);
        Assert.Equal(60, row.RemainingBefore);
        Assert.Empty(row.Actual); // لا تُعاد الكمية التراكمية كمدخل للجلسة الجديدة
        row.Actual = "61";
        Assert.False(row.TryQuantity(out _));
        row.Actual = "٦٠";
        Assert.True(row.TryQuantity(out var currentSession));
        Assert.Equal(60, currentSession);
        Assert.Equal("0", row.Difference);
    }

    [Fact]
    public void Submission_Cannot_Choose_Customer_Product_Lot_Or_Planned_Quantity()
    {
        var fields = typeof(ActualProductionItemDto).GetProperties().Select(p => p.Name).OrderBy(n => n).ToArray();
        Assert.Equal(new[] { "ActualCartons", "OrderItemId" }, fields);
    }
}
