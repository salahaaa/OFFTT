using System.IO;
using DatesErp.Infrastructure.Connection;
using Microsoft.Data.SqlClient;
using Xunit;

namespace DatesErp.Tests;

public sealed class IsolatedTestRunTests
{
    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null && !File.Exists(Path.Combine(dir.FullName, "DateERP.sln"))) dir = dir.Parent;
        return dir!.FullName;
    }

    [Fact]
    public void TestConnection_Is_Pinned_To_The_Requested_Instance_And_Database()
    {
        var builder = new SqlConnectionStringBuilder(IsolatedTestRun.BuildConnectionString());

        Assert.Equal(@".\SQLEXPRESS2022", builder.DataSource);
        Assert.Equal("DateERP_OFFTT_TEST_20261017", builder.InitialCatalog);
        Assert.True(builder.IntegratedSecurity);
        Assert.True(builder.TrustServerCertificate);
    }

    [Fact]
    public void Bootstrapper_Verifies_Opened_Test_Database_Before_Any_Schema_Or_Seed_Operation()
    {
        string boot = File.ReadAllText(Path.Combine(RepoRoot(), "src/DatesErp.Desktop/Services/Bootstrapper.cs"));
        int verify = boot.IndexOf("IsolatedTestRun.VerifyOpenedConnection(connection)", StringComparison.Ordinal);
        Assert.True(verify >= 0, "فحص DB_NAME واسم نسخة SQL Server إلزامي قبل التهيئة.");
        int require = boot.IndexOf("IsolatedTestRun.RequireDatabaseVerified()", verify, StringComparison.Ordinal);
        int ensure = boot.IndexOf("db.Database.EnsureCreated()", verify, StringComparison.Ordinal);
        int seed = boot.IndexOf("DbSeeder.Seed(db)", verify, StringComparison.Ordinal);
        int migrate = boot.IndexOf("SchemaMigrator.Migrate(db)", verify, StringComparison.Ordinal);
        int refData = boot.IndexOf("DbSeeder.UpgradeReferenceData(db)", verify, StringComparison.Ordinal);

        Assert.True(require > verify && ensure > require);
        Assert.True(seed > verify);
        Assert.True(migrate > verify);
        Assert.True(refData > verify);
    }

    [Fact]
    public void Schema_And_Seeder_EntryPoints_Require_The_Verified_Test_Database()
    {
        string guard = File.ReadAllText(Path.Combine(RepoRoot(), "src/DatesErp.Infrastructure/Connection/IsolatedTestRun.cs"));
        string seeder = File.ReadAllText(Path.Combine(RepoRoot(), "src/DatesErp.Infrastructure/Persistence/DbSeeder.cs"));
        string migrator = File.ReadAllText(Path.Combine(RepoRoot(), "src/DatesErp.Infrastructure/Persistence/SchemaMigrator.cs"));

        Assert.Contains("public static void RequireDatabaseVerified()", guard);
        Assert.Contains("Volatile.Write(ref _databaseVerified, 1)", guard);
        Assert.Contains("IsolatedTestRun.RequireDatabaseVerified();", seeder);
        Assert.Contains("IsolatedTestRun.RequireDatabaseVerified();", migrator);
    }

    [Fact]
    public void AppConfig_Stops_Access_To_Installed_Settings_In_Test_Mode()
    {
        string source = File.ReadAllText(Path.Combine(RepoRoot(), "src/DatesErp.Infrastructure/Connection/AppConfig.cs"));
        Assert.Contains("!IsolatedTestRun.IsEnabled && File.Exists(ConfigPath)", source);
        Assert.Contains("if (IsolatedTestRun.IsEnabled || !Exists()) return null;", source);
        Assert.Contains("if (IsolatedTestRun.IsEnabled)", source);
        Assert.Contains("throw new InvalidOperationException", source);
    }
}
