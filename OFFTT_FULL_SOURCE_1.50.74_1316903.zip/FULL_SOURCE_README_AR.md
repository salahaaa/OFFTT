# OFFTT — المصدر البرمجي الكامل

الإصدار: 1.50.74
Commit: 1316903
الفرع: arena/01a0ac34-offtt

هذه حزمة المصدر الكامل بعد آخر التحديثات. لا تحتوي ملف MfgSystem.exe.

للبناء على Windows مع .NET 8 SDK:

    dotnet build DateERP.sln -c Release

لا تستبدل config.json أو ملفات قاعدة البيانات ولا تغيّر إعدادات الاتصال.
