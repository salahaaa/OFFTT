UPDATE 1.50.74 — Production Orders current source DEV snapshot
===============================================================
Commit: 3f28a33
Branch: arena/01a0ac34-offtt

Included:
- Complete tracked source, solution, projects, tests, and documentation.
- Production Orders scheduled plans screen: previous/current/future approved scheduled plans.
- Scheduled date, plan, customer, product, shift, line, cartons, and kg columns.
- Plan-original quantities are read-only in the display grid.
- Selected-row/group issuance uses IssuePlanGroup with the original scheduled date.
- Duplicate/partial plan-item issuance guards remain active.

Verification:
- UTF-8, XAML parse, and git diff checks passed in Arena.
- Windows/.NET build and runtime tests were NOT run because this environment has no .NET SDK.
- This is a DEV source snapshot, not the final Windows-verified delivery package.

The repository's older ZIP archives are intentionally excluded to keep this source download small.
