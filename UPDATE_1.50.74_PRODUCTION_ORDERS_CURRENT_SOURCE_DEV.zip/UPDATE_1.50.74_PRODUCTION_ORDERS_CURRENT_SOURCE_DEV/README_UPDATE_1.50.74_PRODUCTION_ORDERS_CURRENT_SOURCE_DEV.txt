UPDATE 1.50.74 — Production Orders current source DEV snapshot
===============================================================
Commit: ef9415a
Branch: arena/01a0ac34-offtt

Included:
- Complete tracked source, solution, projects, tests, and documentation.
- Production Orders scheduled plans screen: previous/current/future approved scheduled plans.
- Scheduled date, plan, customer, product, shift, line, cartons, and kg columns.
- ERP layout polish matching the approved visual reference: dark section header, chips, summary strip, navy table headers, and clear action bar.
- Main toolbar: Add, Pull from Plan, Save, Search, Edit, Delete, Refresh, Print, Exit.
- Plan-original quantities are read-only in the display grid.
- Selected-row/group issuance uses IssuePlanGroup with the original scheduled date.
- Explicit approval action for selected draft production orders, still protected by production/Approve.
- Duplicate/partial plan-item issuance guards remain active.
- BOM initialization guard: self-diagnostic NullReferenceException fixed in ProductBOMView.

Verification:
- UTF-8, XAML parse, and git diff checks passed in Arena.
- Windows/.NET build and runtime tests were NOT run because this environment has no .NET SDK.
- This is a DEV source snapshot, not the final Windows-verified delivery package.

The repository's older ZIP archives are intentionally excluded to keep this source download small.
