# OFFTT — المصدر البرمجي الكامل

الإصدار: 1.50.74
Commit: c7761bd
الفرع: arena/01a0ac34-offtt

يتضمن آخر تحديث: إعادة شاشة خطط الإنتاج MPS كمدخل التخطيط الرئيسي، مع التمرير الأفقي وتحسين نطاق عدة العملاء. لا يحتوي ملف MfgSystem.exe.

للبناء على Windows: dotnet build DateERP.sln -c Release
