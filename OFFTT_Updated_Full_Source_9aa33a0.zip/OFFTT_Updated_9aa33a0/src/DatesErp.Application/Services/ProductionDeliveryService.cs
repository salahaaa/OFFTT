using DatesErp.Core.Common;
using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Domain.Enums;
using DatesErp.Core.Exceptions;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Application.Services;

/// <summary>
/// §B96 — أوامر تسليم الإنتاج (إدارة الإنتاج — يحررها مدير الإنتاج):
/// مسودة ← مُصدَرة ← مستلمة (عبر سندات الاستلام المخزنية).
/// المصدر التشغيلي الجديد: جلسة الإنتاج الفعلي المكتملة فقط؛ وتبقى مصادر الفحص/الخطة للقراءة التاريخية والتوافق مع المستندات القديمة.
/// البند = أمر + صنف + دفعة + عميل + كمية — عميل أو عدة عملاء، صنف أو أكثر.
/// سقفان: سقف المصدر (المقبول/المنتَج) + سقف فيزيائي موحد (كل المصادر ≤ المنتَج).
/// </summary>
public partial class ProductionDeliveryService : ServiceBase, IProductionDeliveryService
{
    private readonly IAuditService _audit;

    public ProductionDeliveryService(DatesErpDbContext db, ICurrentSession session, INumberingService numbering, IAuditService audit)
        : base(db, session, numbering)
    {
        _audit = audit;
    }

    public OpResult SaveDelivery(string sourceType, int sourceId, string deliveryDate, List<ProductionDeliveryItemDto> items,
        string bypassReason = null, string notes = null)
    {
        Require("production", "Create");
        if (sourceType != DeliverySources.FromActual && sourceType != DeliverySources.FromCheck
            && sourceType != DeliverySources.FromPlan && sourceType != DeliverySources.FromClosing)
            return OpResult.Fail("مصدر التسليم غير معروف — اختر جلسة إنتاج فعلي مكتملة.");
        if (items == null || items.Count == 0)
            return OpResult.Fail("أدخل بنداً واحداً على الأقل في أمر التسليم.");

        // §B96 — التجاوز بصلاحية وسبب مكتوب (لا تجاوز صامت إطلاقاً)
        bool bypass = DeliverySources.IsBypass(sourceType);
        if (bypass)
        {
            Require("production", "BypassInspection");
            if (string.IsNullOrWhiteSpace(bypassReason))
                return OpResult.Fail("التسليم من الخطة/الإقفال يتجاوز الفحص — أدخل سبب التجاوز مكتوباً ليُحفظ موثقاً في الأمر.");
        }

        // §التحقق من المصدر وحالته
        QualityCheck check = null;
        ProductionPlan plan = null;
        ProductionOrder checkOrder = null;
        ProductionExecution execution = null;
        if (sourceType == DeliverySources.FromActual)
        {
            execution = Db.ProductionExecutions.AsNoTracking().FirstOrDefault(e => e.Id == sourceId);
            if (execution == null) return OpResult.Fail("جلسة الإنتاج الفعلي غير موجودة — احفظ الفعلي أولاً.");
            if (!execution.IsDayClosed || execution.Status != DocStatuses.Completed)
                return OpResult.Fail("لا يمكن إنشاء أمر تسليم قبل إقفال جلسة الإنتاج الفعلي.");
            checkOrder = Db.ProductionOrders.Include(o => o.Items)
                .FirstOrDefault(o => o.Id == execution.OrderId && o.IsApproved && o.Status != DocStatuses.Cancelled);
            if (checkOrder == null)
                return OpResult.Fail("أمر الإنتاج المرتبط بالفعلي غير موجود أو غير معتمد.");
        }
        else if (sourceType == DeliverySources.FromCheck)
        {
            check = Db.QualityChecks.Include(c => c.Items).FirstOrDefault(c => c.Id == sourceId);
            if (check == null) return OpResult.Fail("محضر الفحص غير موجود — تحقق من الرقم.");
            // §B102 — الهوية قبل الحالة: الفحص اليدوي بلا أمر لا يُسلَّم منه إطلاقاً (حتى لو اعتُمِد)
            if (check.OrderId == null) return OpResult.Fail("الفحص اليدوي بلا أمر لا يُسلَّم منه — التسليم من إنتاج أمر تشغيل فقط.");
            if (!check.IsApproved) return OpResult.Fail($"محضر الفحص {check.DocumentNumber} غير معتمد — لا يُسلَّم إلا من محضر معتمد.");
            checkOrder = Db.ProductionOrders.Include(o => o.Items).FirstOrDefault(o => o.Id == check.OrderId.Value);
            if (checkOrder == null) return OpResult.Fail("أمر المحضر غير موجود.");
        }
        else
        {
            plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == sourceId);
            if (plan == null) return OpResult.Fail("الخطة غير موجودة — تحقق من الرقم.");
            if (!plan.IsApproved) return OpResult.Fail("الخطة غير معتمدة — اعتمدها أولاً.");
            if (plan.Status == DocStatuses.Cancelled) return OpResult.Fail("الخطة ملغاة — لا يُسلَّم منها.");
            if (sourceType == DeliverySources.FromClosing && !plan.IsClosed)
                return OpResult.Fail("الخطة غير مقفلة — التسليم من الإقفال يتطلب خطة مقفلة (أو سلِّم من الخطة مباشرة).");
        }

        var srcLines = BuildSourceLines(sourceType, sourceId, check, checkOrder, plan, execution);

        return RunOp(() =>
        {
            // PRD-03: أعد تحميل المصدر داخل المعاملة؛ لا تنشئ سنداً من تنفيذ/أمر أُلغي
            // بعد فحص الشاشة.
            if (sourceType == DeliverySources.FromActual)
            {
                var currentExecution = Db.ProductionExecutions.AsNoTracking().FirstOrDefault(e => e.Id == sourceId);
                if (currentExecution == null || !currentExecution.IsDayClosed || currentExecution.Status != DocStatuses.Completed)
                    throw new DomainException("جلسة الإنتاج الفعلي غير موجودة أو لم تعد مكتملة.", "ACTUAL_STATE_CHANGED");
                var currentOrder = Db.ProductionOrders.AsNoTracking().FirstOrDefault(o => o.Id == currentExecution.OrderId);
                if (currentOrder == null || currentOrder.Status == DocStatuses.Cancelled || !currentOrder.IsApproved)
                    throw new DomainException("أمر الإنتاج المرتبط غير موجود أو ملغى.", "ORDER_CANCELLED");
            }
            var delivery = new ProductionDelivery
            {
                DocumentNumber = Numbering.Next("PDL"),
                DeliveryDate = UiFormat.TryParseDate(deliveryDate, out var d) ? d : DateTime.Now,
                SourceType = sourceType,
                SourceId = sourceId,
                BypassReason = bypass ? bypassReason.Trim() : null,
                Status = DocStatuses.Draft,
                ReceiptStatus = "None",
                Notes = notes
            };

            PopulateDeliveryItems(delivery, sourceType, srcLines, items);

            Db.ProductionDeliveries.Add(delivery);
            Db.SaveChanges();
            if (bypass)
                _audit.Log("الإنتاج", "تسليم بتجاوز الفحص", "ProductionDelivery", delivery.DocumentNumber, delivery.Id,
                    new { المصدر = DeliverySources.ToArabic(sourceType) }, new { السبب = delivery.BypassReason });
            double total = delivery.Items.Sum(i => i.QtyKg);
            return OpResult.Success(
                $"تم إنشاء أمر تسليم الإنتاج {delivery.DocumentNumber} من {DeliverySources.ToArabic(sourceType)} — {delivery.Items.Count} بنود ({total:N1} كجم)." +
                (bypass ? " (بتجاوز موثق للفحص)" : "") + " — بانتظار تحرير مدير الإنتاج.",
                delivery.Id, delivery.DocumentNumber);
        });
    }

    private void PopulateDeliveryItems(ProductionDelivery delivery, string sourceType,
        List<DeliverySourceLine> srcLines, List<ProductionDeliveryItemDto> items)
    {
            var takenPerLine = new Dictionary<DeliverySourceLine, double>();
            var takenPackagesPerLine = new Dictionary<DeliverySourceLine, int>();
            foreach (var it in items)
            {
                // §نظام الوحدات: التسليم للمنتجات التامة فقط (002)
                UnitsPolicy.RequireItemType(Db, it.ProductId, "Finished", "بند أمر تسليم الإنتاج");
                if (it.QtyKg <= 0)
                    throw new DomainException($"كمية البند للصنف «{ProdName(it.ProductId)}» يجب أن تكون أكبر من صفر.");

                // §مطابقة سطر المصدر (صنف + دفعة + عميل)
                // §تعدد العملاء: حين يُترك عميل البند فارغاً كان الشرط l.CustomerId == (it.CustomerId ?? l.CustomerId)
                // يتحقق لكل السطور، فيُلتقط أول سطر بالصدفة ويُقيَّد التام لعميل غير صاحبه.
                // فإن تعددت السطور المطابقة صنفاً ودفعةً، العميل إلزامي صريح.
                bool strictPackagingIdentity = sourceType == DeliverySources.FromActual;
                var candidates = srcLines.Where(l => l.ProductId == it.ProductId && l.LotId == it.LotId
                    && (!strictPackagingIdentity || l.PackagingTypeId == it.PackagingTypeId)).ToList();
                DeliverySourceLine line;
                if (it.CustomerId != null)
                    line = candidates.FirstOrDefault(l => l.CustomerId == it.CustomerId);
                else if (candidates.Count > 1)
                    throw new DomainException(
                        $"⛔ الصنف «{ProdName(it.ProductId)}»" +
                        (it.LotId != null ? $" من الدفعة «{LotCode(it.LotId)}»" : "") +
                        $" مشترك بين {candidates.Count} عملاء في {DeliverySources.ToArabic(sourceType)} — حدد عميل البند صراحةً.\n" +
                        "العملاء: " + string.Join(" · ", candidates.Select(c => c.CustomerName ?? "بلا عميل")),
                        "AMBIGUOUS_CUSTOMER");
                else
                    line = candidates.FirstOrDefault();
                if (line == null)
                    throw new DomainException(
                        $"لا يوجد سطر مطابق في {DeliverySources.ToArabic(sourceType)} للصنف «{ProdName(it.ProductId)}»" +
                        (it.LotId != null ? $" والدفعة «{LotCode(it.LotId)}»" : "") + " — راجع الملء الآلي.",
                        "NO_SOURCE_LINE");
                // PRD-08 — المطابقة لا تكتمل بالصنف والدفعة فقط؛ العبوة والكراتين
                // جزء من هوية المصدر التشغيلي الجديد. المسارات القديمة تُقرأ للتوافق
                // التاريخي فقط، وتستكمل القيم الناقصة من سطرها المحفوظ ولا تُستخدم لإنشاء
                // سند استلام جديد (حارس FinishedGoodsService).
                if (strictPackagingIdentity)
                {
                    if (it.PackagingTypeId != line.PackagingTypeId)
                        throw new DomainException("عبوة بند أمر التسليم لا تطابق العبوة في المصدر التشغيلي.", "PACKAGING_MISMATCH");
                    if (it.PackageCount <= 0 || line.PackageCount <= 0)
                        throw new DomainException("لا يمكن إنشاء أمر تسليم بلا عدد كراتين صحيح للمصدر والبند.", "PACKAGE_COUNT_REQUIRED");
                    takenPackagesPerLine.TryGetValue(line, out var takenPackages);
                    if (takenPackages + it.PackageCount > line.PackageCount)
                        throw new DomainException("مجموع كراتين بنود أمر التسليم يتجاوز عدد كراتين سطر المصدر.", "PACKAGE_COUNT_OVER");
                    takenPackagesPerLine[line] = takenPackages + it.PackageCount;
                }
                else if (it.PackagingTypeId != null && it.PackagingTypeId != line.PackagingTypeId)
                    throw new DomainException("عبوة بند أمر التسليم لا تطابق العبوة في المصدر التاريخي.", "PACKAGING_MISMATCH");
                int effectivePackageCount = it.PackageCount > 0 ? it.PackageCount : line.PackageCount;
                if (!strictPackagingIdentity && line.PackageCount > 0 && effectivePackageCount > line.PackageCount)
                    throw new DomainException("عدد كراتين أمر التسليم يتجاوز عدد كراتين المصدر التاريخي.", "PACKAGE_COUNT_OVER");
                int? effectivePackagingTypeId = it.PackagingTypeId ?? line.PackagingTypeId;

                // §سقف المصدر: لا تسليم فوق المتبقي (المقبول/المنتَج ناقص ما سُلِّم سابقاً)
                // RemainingQtyKg محسوب مرة واحدة قبل الحلقة من المحفوظ، فبندان في نفس المستند
                // على سطر واحد كانا يُقاسان كلاهما على المتبقي الكامل ويتجاوزانه معاً — يُجمَّع محلياً.
                takenPerLine.TryGetValue(line, out double takenBefore);
                if (takenBefore + it.QtyKg > line.RemainingQtyKg + 0.01)
                    throw new DomainException(
                        $"⛔ كمية البند ({it.QtyKg:N1} كجم) تتجاوز المتبقي القابل للتسليم ({line.RemainingQtyKg:N1} كجم) " +
                        $"للصنف «{line.ProductName}» في {DeliverySources.ToArabic(sourceType)}." +
                        (takenBefore > 0 ? $"\nمأخوذ في بنود أخرى من هذا المستند: {takenBefore:N1} كجم." : ""),
                        "OVER_SOURCE");
                takenPerLine[line] = takenBefore + it.QtyKg;

                // §السقف الفيزيائي الموحد: كل المصادر معاً لا تتجاوز إنتاج الأمر (منع ازدواج محضر+خطة)
                if (line.OrderId is int lineOrderId)
                {
                    double produced = Db.ProductionOrderItems.AsNoTracking()
                        .Where(o => o.OrderId == lineOrderId && o.ProductId == it.ProductId).Sum(o => o.ProducedQtyKg);
                    double deliveredAll = Db.ProductionDeliveryItems.AsNoTracking()
                        .Join(Db.ProductionDeliveries.AsNoTracking(), i => i.DeliveryId, d => d.Id, (i, d) => new { i, d })
                        .Where(x => x.d.Status != DocStatuses.Cancelled && x.d.Id != delivery.Id && x.i.OrderId == lineOrderId && x.i.ProductId == it.ProductId)
                        .Sum(x => x.i.QtyKg);
                    // §المباشر القديم يُرى أيضاً (المربوط داخل deliveredAll أصلاً فلا ازدواج)
                    double directReceived = Db.FinishedGoodsReceiptItems.AsNoTracking()
                        .Join(Db.FinishedGoodsReceipts.AsNoTracking(), i => i.ReceiptId, r => r.Id, (i, r) => new { i, r })
                        .Where(x => x.r.Status != DocStatuses.Cancelled && x.r.DeliveryId == null
                            && x.r.OrderId == lineOrderId && x.i.ProductId == it.ProductId)
                        .Sum(x => x.i.ReceivedQtyKg);
                    double thisDoc = delivery.Items.Where(i => i.OrderId == lineOrderId && i.ProductId == it.ProductId).Sum(i => i.QtyKg);
                    if (deliveredAll + directReceived + thisDoc + it.QtyKg > produced + 0.01)
                        throw new DomainException(
                            $"⛔ التسليم يتجاوز الإنتاج الفعلي للصنف «{line.ProductName}».\n" +
                            $"المنتَج: {produced:N1} كجم | المُسلَّم بأوامر أخرى: {deliveredAll:N1} | المستلَم مباشرةً: {directReceived:N1} | هذا الأمر بعد الإضافة: {thisDoc + it.QtyKg:N1}",
                            "OVER_PRODUCED");
                }

                // §تتبع الهوية: الدفعة المسلَّمة يجب أن تطابق دفعة بند الأمر (لا استبدال هوية)
                if (it.LotId is int lineLot && line.OrderId is int lineOrd)
                {
                    ProductIdentityGuard.EnsureConversionAllowed(Db, it.ProductId, lineLot);
                    bool lotOk = Db.ProductionOrderItems.AsNoTracking()
                        .Any(o => o.OrderId == lineOrd && o.ProductId == it.ProductId && o.LotId == lineLot);
                    if (!lotOk)
                        throw new DomainException($"⛔ الدفعة «{LotCode(lineLot)}» ليست دفعة هذا الصنف في الأمر المصدر.", "LOT_MISMATCH");
                }

                delivery.Items.Add(new ProductionDeliveryItem
                {
                    OrderId = line.OrderId,
                    ProductId = it.ProductId,
                    LotId = it.LotId,
                    CustomerId = line.CustomerId,
                    PackagingTypeId = effectivePackagingTypeId,
                    PackageCount = effectivePackageCount,
                    QtyKg = it.QtyKg
                });
            }

    }

    public OpResult CreateDeliveryFromActual(int executionId, string deliveryDate = null, string notes = null)
    {
        Require("production", "Create");
        var execution = Db.ProductionExecutions.AsNoTracking().FirstOrDefault(e => e.Id == executionId);
        if (execution == null) return OpResult.Fail("جلسة الإنتاج الفعلي غير موجودة.");
        if (!execution.IsDayClosed || execution.Status != DocStatuses.Completed)
            return OpResult.Fail("لا يمكن إنشاء أمر تسليم قبل حفظ الإنتاج الفعلي وإقفاله.");
        // يسمح التنفيذ الواحد بأكثر من أمر تسليم عند التسليم الجزئي أو التوزيع على أكثر من مخزن.
        // السقف المشترك يحسب كل الأوامر غير الملغاة داخل GetSourceContext.
        var ctx = GetSourceContext(DeliverySources.FromActual, executionId);
        var items = ctx.Lines.Where(l => l.RemainingQtyKg > 0.001)
            .Select(l => new ProductionDeliveryItemDto
            {
                OrderId = l.OrderId,
                ProductId = l.ProductId,
                LotId = l.LotId,
                CustomerId = l.CustomerId,
                PackagingTypeId = l.PackagingTypeId,
                PackageCount = l.PackageCount,
                QtyKg = Math.Round(l.RemainingQtyKg, 3)
            }).ToList();
        if (items.Count == 0) return OpResult.Fail("لا توجد كمية فعلية قابلة للتسليم في جلسة الإنتاج.");
        return SaveDelivery(DeliverySources.FromActual, executionId,
            deliveryDate ?? DateTime.Now.ToString("dd/MM/yyyy"), items, null, notes);
    }

    public OpResult UpdateDelivery(int deliveryId, string deliveryDate, List<ProductionDeliveryItemDto> items, string notes = null)
    {
        Require("production", "Edit");
        if (items == null || items.Count == 0) return OpResult.Fail("أدخل بنداً واحداً على الأقل في أمر التسليم.");
        var delivery = Db.ProductionDeliveries.Include(d => d.Items).FirstOrDefault(d => d.Id == deliveryId);
        if (delivery == null) return OpResult.Fail("أمر التسليم غير موجود.");
        if (delivery.SourceType != DeliverySources.FromActual)
            return OpResult.Fail("لا يمكن تعديل أمر تسليم قديم غير نازل من الإنتاج الفعلي.");
        if (delivery.Status != DocStatuses.Draft)
            return OpResult.Fail("لا يمكن تعديل أمر التسليم بعد تحريره للمخزن.");
        if (delivery.Items.Any(i => i.ReceivedQtyKg > 0.001))
            return OpResult.Fail("بدأ استلام هذا الأمر — لا يمكن تعديله.");

        var ctx = GetSourceContext(DeliverySources.FromActual, delivery.SourceId);
        // مسودة الأمر الحالي لا تحجب نفسها عند إعادة حفظها.
        foreach (var line in ctx.Lines)
        {
            var old = delivery.Items.Where(i => i.ProductId == line.ProductId && i.LotId == line.LotId
                && i.CustomerId == line.CustomerId && i.PackagingTypeId == line.PackagingTypeId).Sum(i => i.QtyKg);
            line.DeliveredQtyKg = Math.Max(0, line.DeliveredQtyKg - old);
            line.RemainingQtyKg = Math.Max(0, line.AvailableQtyKg - line.DeliveredQtyKg);
        }

        return RunOp(() =>
        {
            Db.ProductionDeliveryItems.RemoveRange(delivery.Items);
            delivery.Items.Clear();
            Db.SaveChanges(); // لا تحتسب حواجز السقف بنود المسودة القديمة أثناء إعادة البناء
            PopulateDeliveryItems(delivery, DeliverySources.FromActual, ctx.Lines, items);
            delivery.DeliveryDate = UiFormat.TryParseDate(deliveryDate, out var d) ? d : delivery.DeliveryDate;
            delivery.Notes = notes;
            delivery.ModifiedBy = Session?.UserId;
            delivery.ModifiedDate = DateTime.Now;
            Db.SaveChanges();
            return OpResult.Success($"تم تعديل أمر تسليم الإنتاج {delivery.DocumentNumber} — ما زال مسودة بانتظار تحرير مدير الإنتاج.", delivery.Id, delivery.DocumentNumber);
        });
    }

    public OpResult IssueDelivery(int deliveryId)
    {
        Require("production", "Approve");
        var delivery = Db.ProductionDeliveries.Include(d => d.Items).FirstOrDefault(d => d.Id == deliveryId);
        if (delivery == null) return OpResult.Fail("أمر التسليم غير موجود.");
        if (delivery.Status == DocStatuses.Issued) return OpResult.Fail("أمر التسليم مُحرَّر مسبقاً.");
        if (delivery.Status == DocStatuses.Cancelled) return OpResult.Fail("أمر التسليم ملغى.");
        if (delivery.Status == DocStatuses.Completed) return OpResult.Fail("أمر التسليم مستلم بالكامل.");

        return RunOp(() =>
        {
            // PRD-03: حالة أمر التسليم قد تكون تغيرت بعد فحص ما قبل المعاملة.
            Db.ChangeTracker.Clear();
            delivery = Db.ProductionDeliveries.Include(d => d.Items).FirstOrDefault(d => d.Id == deliveryId)
                ?? throw new DomainException("أمر التسليم غير موجود.", "DELIVERY_MISSING");
            if (delivery.Status == DocStatuses.Cancelled)
                throw new DomainException("أمر التسليم ملغى.", "DELIVERY_CANCELLED");
            if (delivery.Status == DocStatuses.Issued)
                throw new DomainException("أمر التسليم مُحرَّر مسبقاً.", "DELIVERY_ISSUED");
            if (delivery.Status == DocStatuses.Completed)
                throw new DomainException("أمر التسليم مستلم بالكامل.", "DELIVERY_COMPLETED");
            if (delivery.Items.Count == 0)
                throw new DomainException("لا يمكن تحرير أمر بلا بنود.");
            delivery.Status = DocStatuses.Issued;
            delivery.IsApproved = true;
            delivery.ApprovedBy = Session?.UserId;
            delivery.ApprovedDate = DateTime.Now;
            Db.SaveChanges(); // اجعل أمر التسليم الحالي مرئياً لمزامنة دفتر الخطة داخل نفس المعاملة.
            string planMessage = SyncLinkedPlanAfterDeliveryChange(delivery);
            Db.SaveChanges();
            return OpResult.Success($"تم تحرير أمر التسليم {delivery.DocumentNumber} إلى المخازن — بانتظار أمر استلام أمين مخزن التام.{planMessage}");
        });
    }

    /// <summary>
    /// إقفال الخطة هو أثر تحرير أمر تسليم الإنتاج، لا أثر اعتماد أمر الإنتاج
    /// ولا أثر تسجيل الفعلي ولا أثر استلام المخزن. الصلاحية حُكمت في IssueDelivery
    /// عبر production/Approve، ولا تُستخدم بوابة بديلة.
    /// </summary>
    /// <summary>
    /// PRD-04 — مزامنة الخطة من دفتر أوامر التسليم الفعلية.
    /// لا تُقفل الخطة عند أول أمر؛ تُقفل فقط عندما غُطيت كل بنودها المنتجة
    /// بأوامر تسليم غير ملغاة. وكل انتقال (إقفال/إعادة فتح) يعيد احتساب
    /// حجوزات الدفعات داخل نفس المعاملة.
    /// </summary>
    private string SyncLinkedPlanAfterDeliveryChange(ProductionDelivery triggeringDelivery)
    {
        if (triggeringDelivery.SourceType != DeliverySources.FromActual) return "";
        var execution = Db.ProductionExecutions.AsNoTracking().FirstOrDefault(e => e.Id == triggeringDelivery.SourceId);
        if (execution == null) throw new DomainException("جلسة الإنتاج الفعلي المرتبطة بأمر التسليم غير موجودة.", "ACTUAL_MISSING");
        var sourceOrder = Db.ProductionOrders.AsNoTracking().FirstOrDefault(o => o.Id == execution.OrderId);
        if (sourceOrder?.SourcePlanId == null) return "";

        var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == sourceOrder.SourcePlanId.Value);
        if (plan == null) throw new DomainException("الخطة المرتبطة بالإنتاج الفعلي غير موجودة.", "PLAN_MISSING");
        if (plan.Status == DocStatuses.Cancelled)
            throw new DomainException("الخطة المرتبطة ملغاة — لا يمكن تحرير أمر التسليم.", "PLAN_CANCELLED");
        if (!plan.IsApproved)
            throw new DomainException("الخطة المرتبطة غير معتمدة — لا يمكن تحرير أمر التسليم.", "PLAN_NOT_APPROVED");

        var orderIds = Db.ProductionOrders.AsNoTracking()
            .Where(o => o.SourcePlanId == plan.Id && o.SourceType == "FromPlan" && o.Status != DocStatuses.Cancelled)
            .Select(o => o.Id).ToList();
        var orderItems = Db.ProductionOrderItems.AsNoTracking()
            .Where(i => orderIds.Contains(i.OrderId) && i.PlanItemId != null)
            .ToList();
        var deliveries = (from di in Db.ProductionDeliveryItems.AsNoTracking()
                          join d in Db.ProductionDeliveries.AsNoTracking() on di.DeliveryId equals d.Id
                          join e in Db.ProductionExecutions.AsNoTracking() on d.SourceId equals e.Id
                          join o in Db.ProductionOrders.AsNoTracking() on e.OrderId equals o.Id
                          where d.SourceType == DeliverySources.FromActual
                              && d.Status != DocStatuses.Cancelled && o.SourcePlanId == plan.Id
                          select new { di, o.Id }).ToList();

        foreach (var pi in plan.Items)
        {
            var oiIds = orderItems.Where(i => i.PlanItemId == pi.Id).Select(i => i.Id).ToHashSet();
            var matchingOrderIds = orderItems.Where(i => oiIds.Contains(i.Id)).Select(i => i.OrderId).ToHashSet();
            double delivered = deliveries
                .Where(x => matchingOrderIds.Contains(x.di.OrderId ?? 0)
                    && x.di.ProductId == pi.ProductId && x.di.LotId == pi.LotId
                    && x.di.CustomerId == pi.CustomerId
                    && x.di.PackagingTypeId == pi.PackagingTypeId)
                .Sum(x => x.di.QtyKg);
            pi.DeliveredQtyKg = delivered;
        }

        // بند لم يُنتج بعد ليس «مكتمل التسليم»؛ فلا تغلق الخطة مبكراً.
        bool allProducedItemsDelivered = plan.Items.Count > 0 && plan.Items.All(pi =>
            pi.ProducedQtyKg > 0.001 && pi.DeliveredQtyKg + 0.001 >= pi.ProducedQtyKg);
        string message;
        bool wasClosed = plan.IsClosed;
        var affectedLots = plan.Items.Where(i => i.LotId != null).Select(i => i.LotId.Value).Distinct().ToList();
        if (allProducedItemsDelivered)
        {
            if (!plan.IsClosed)
            {
                plan.IsClosed = true;
                plan.ClosedDate = DateTime.Now;
                plan.ClosedBy = Session?.UserId;
                plan.Status = DocStatuses.Closed;
                message = $" أُقفلت الخطة {plan.DocumentNumber} بعد اكتمال تسليم جميع بنودها.";
            }
            else message = $" الخطة {plan.DocumentNumber} مقفلة بعد اكتمال جميع بنودها.";
        }
        else
        {
            if (plan.IsClosed)
            {
                plan.IsClosed = false;
                plan.ClosedDate = null;
                plan.ClosedBy = null;
                plan.Status = DocStatuses.Approved;
                message = $" أُعيد فتح الخطة {plan.DocumentNumber} لأن التسليمات غير الملغاة لا تغطي كل بنودها.";
            }
            else message = $" الخطة {plan.DocumentNumber} ما زالت مفتوحة — لم تكتمل كل بنودها.";
        }
        if (!wasClosed && plan.IsClosed)
            _audit.Log("إدارة الإنتاج", "إقفال الخطة بعد اكتمال كل بنود التسليم", "Plan", plan.DocumentNumber, plan.Id,
                new { السبب = "ProductionDelivery.Issue", أمر_التسليم = triggeringDelivery.DocumentNumber },
                new { الحالة_الجديدة = "مقفلة", المستخدم = Session?.UserId });
        else if (wasClosed && !plan.IsClosed)
            _audit.Log("إدارة الإنتاج", "إعادة فتح الخطة بعد إلغاء أمر التسليم", "Plan", plan.DocumentNumber, plan.Id,
                new { السبب = "ProductionDelivery.Cancel", أمر_التسليم = triggeringDelivery.DocumentNumber },
                new { الحالة_الجديدة = "معتمدة", المستخدم = Session?.UserId });
        // الحجز يُقرأ من SQL لا من ChangeTracker؛ احفظ انتقال الحالة داخل نفس
        // المعاملة أولاً حتى لا يُبنى الرقم على حالة Closed/Approved القديمة.
        Db.SaveChanges();
        RecalculatePlanLotReservations(affectedLots);
        return message;
    }

    private void RecalculatePlanLotReservations(IEnumerable<int> lotIds)
    {
        foreach (var lotId in lotIds.Distinct())
        {
            var lot = Db.Lots.FirstOrDefault(l => l.Id == lotId);
            if (lot == null) continue;
            var amounts = (from i in Db.ProductionPlanItems
                           join p in Db.ProductionPlans on i.PlanId equals p.Id
                           where i.LotId == lotId && p.Status != DocStatuses.Closed
                               && p.Status != DocStatuses.Cancelled && !p.IsClosed && !i.IsClosed
                           select new { i.PlannedQtyKg, i.ProducedQtyKg }).ToList();
            lot.ReservedQtyKg = Math.Max(0, amounts.Sum(x => Math.Max(0, x.PlannedQtyKg - x.ProducedQtyKg)));
        }
    }

    public OpResult CancelDelivery(int deliveryId)
    {
        Require("production", "Cancel");
        var delivery = Db.ProductionDeliveries.Include(d => d.Items).FirstOrDefault(d => d.Id == deliveryId);
        if (delivery == null) return OpResult.Fail("أمر التسليم غير موجود.");
        if (delivery.Status == DocStatuses.Cancelled) return OpResult.Fail("أمر التسليم ملغى مسبقاً.");
        if (delivery.Status == DocStatuses.Completed) return OpResult.Fail("الأمر مستلم بالكامل — ألغِ سندات الاستلام أولاً.");

        return RunOp(() =>
        {
            Db.ChangeTracker.Clear();
            delivery = Db.ProductionDeliveries.Include(d => d.Items).FirstOrDefault(d => d.Id == deliveryId)
                ?? throw new DomainException("أمر التسليم غير موجود.", "DELIVERY_MISSING");
            if (delivery.Status == DocStatuses.Cancelled)
                throw new DomainException("أمر التسليم ملغى مسبقاً.", "DELIVERY_CANCELLED");
            if (delivery.Items.Any(i => i.ReceivedQtyKg > 0.001))
                throw new DomainException("بدأ استلام هذا الأمر — ألغِ سندات الاستلام أولاً ثم ألغِ الأمر.", "HAS_RECEIPTS");
            delivery.Status = DocStatuses.Cancelled;
            Db.SaveChanges(); // حتى تستبعد المزامنة سند الإلغاء من التسليمات الفعالة داخل نفس المعاملة.
            string planMessage = SyncLinkedPlanAfterDeliveryChange(delivery);
            Db.SaveChanges();
            return OpResult.Success($"تم إلغاء أمر التسليم {delivery.DocumentNumber}." + planMessage);
        });
    }

    public DeliverySourceContext GetSourceContext(string sourceType, int sourceId)
    {
        var ctx = new DeliverySourceContext { SourceType = sourceType, SourceId = sourceId };
        if (sourceType == DeliverySources.FromActual)
        {
            var execution = Db.ProductionExecutions.AsNoTracking().FirstOrDefault(e => e.Id == sourceId);
            if (execution == null) return ctx;
            ctx.SourceNumber = execution.DocumentNumber;
            ctx.SourceDate = UiFormat.D(execution.EndDateTime);
            var order = Db.ProductionOrders.Include(o => o.Items).AsNoTracking().FirstOrDefault(o => o.Id == execution.OrderId);
            ctx.Lines = BuildSourceLines(sourceType, sourceId, null, order, null, execution);
        }
        else if (sourceType == DeliverySources.FromCheck)
        {
            var check = Db.QualityChecks.Include(c => c.Items).AsNoTracking().FirstOrDefault(c => c.Id == sourceId);
            if (check == null) return ctx;
            ctx.SourceNumber = check.DocumentNumber;
            ctx.SourceDate = UiFormat.D(check.CheckDate);
            var order = check.OrderId != null
                ? Db.ProductionOrders.Include(o => o.Items).AsNoTracking().FirstOrDefault(o => o.Id == check.OrderId.Value)
                : null;
            ctx.Lines = BuildSourceLines(sourceType, sourceId, check, order, null, null);
        }
        else if (sourceType == DeliverySources.FromPlan || sourceType == DeliverySources.FromClosing)
        {
            var plan = Db.ProductionPlans.Include(p => p.Items).AsNoTracking().FirstOrDefault(p => p.Id == sourceId);
            if (plan == null) return ctx;
            ctx.SourceNumber = plan.DocumentNumber;
            ctx.SourceDate = UiFormat.D(plan.StartDate);
            ctx.Lines = BuildSourceLines(sourceType, sourceId, null, null, plan, null);
        }
        return ctx;
    }

    public List<(int Id, string Label)> GetSourceDocs(string sourceType)
    {
        if (sourceType == DeliverySources.FromActual)
            return Db.ProductionExecutions.AsNoTracking()
                .Where(e => e.IsDayClosed && e.Status == DocStatuses.Completed)
                .OrderByDescending(e => e.Id).Take(200).ToList()
                .Select(e => (e.Id, $"{e.DocumentNumber} — {UiFormat.D(e.EndDateTime)} — {e.ActualCartons:N0} كرتون"))
                .ToList();
        if (sourceType == DeliverySources.FromCheck)
            return Db.QualityChecks.AsNoTracking().Include(c => c.Items)
                .Where(c => c.IsApproved && c.OrderId != null)
                .OrderByDescending(c => c.Id).Take(200).ToList()
                .Select(c => (c.Id, $"{c.DocumentNumber} — {UiFormat.D(c.CheckDate)} — مقبول {c.Items.Sum(i => i.AcceptedQtyKg):N1} كجم"))
                .ToList();
        if (sourceType == DeliverySources.FromPlan)
            return Db.ProductionPlans.AsNoTracking()
                .Where(p => p.IsApproved && p.Status != DocStatuses.Cancelled && !p.IsClosed)
                .OrderByDescending(p => p.Id).Take(200).ToList()
                .Select(p => (p.Id, $"{p.DocumentNumber} — {UiFormat.D(p.StartDate)}"))
                .ToList();
        if (sourceType == DeliverySources.FromClosing)
            return Db.ProductionPlans.AsNoTracking()
                .Where(p => p.IsApproved && p.IsClosed)
                .OrderByDescending(p => p.Id).Take(200).ToList()
                .Select(p => (p.Id, $"{p.DocumentNumber} — {UiFormat.D(p.StartDate)} (مقفلة)"))
                .ToList();
        return new List<(int, string)>();
    }

    public ProductionDeliveryCard GetDelivery(int deliveryId)
    {
        var d = Db.ProductionDeliveries.Include(x => x.Items).AsNoTracking().FirstOrDefault(x => x.Id == deliveryId);
        if (d == null) return null;
        var card = new ProductionDeliveryCard
        {
            Id = d.Id,
            DocumentNumber = d.DocumentNumber,
            DeliveryDate = UiFormat.D(d.DeliveryDate),
            SourceType = d.SourceType,
            SourceTypeAr = DeliverySources.ToArabic(d.SourceType),
            SourceId = d.SourceId,
            SourceNumber = SourceNumber(d.SourceType, d.SourceId),
            BypassReason = d.BypassReason,
            Status = d.Status,
            StatusAr = DocStatuses.ToArabic(d.Status),
            ReceiptStatus = d.ReceiptStatus
        };
        foreach (var i in d.Items)
            card.Lines.Add(new ProductionDeliveryLineRow
            {
                Id = i.Id,
                OrderId = i.OrderId,
                OrderNumber = i.OrderId != null ? Db.ProductionOrders.AsNoTracking().Where(o => o.Id == i.OrderId.Value).Select(o => o.DocumentNumber).FirstOrDefault() : null,
                ProductId = i.ProductId,
                ProductName = ProdName(i.ProductId),
                LotId = i.LotId,
                LotCode = i.LotId != null ? LotCode(i.LotId) : null,
                CustomerId = i.CustomerId,
                CustomerName = i.CustomerId != null ? CustName(i.CustomerId) : null,
                PackagingTypeId = i.PackagingTypeId,
                PackagingName = i.PackagingTypeId != null
                    ? Db.PackagingTypes.AsNoTracking().Where(p => p.Id == i.PackagingTypeId.Value).Select(p => p.PackageNameAr).FirstOrDefault()
                    : null,
                CartonWeightKg = UnitsPolicy.CartonWeight(Db, i.ProductId, i.PackagingTypeId),
                PackageCount = i.PackageCount,
                QtyKg = i.QtyKg,
                ReceivedQtyKg = i.ReceivedQtyKg,
                RemainingQtyKg = Math.Max(0, i.QtyKg - i.ReceivedQtyKg)
            });
        return card;
    }

    public List<ProductionDeliveryCard> GetDeliveries(string statusFilter = null)
    {
        var ids = Db.ProductionDeliveries.AsNoTracking()
            .Where(d => statusFilter == null || d.Status == statusFilter)
            .OrderByDescending(d => d.Id).Take(300).Select(d => d.Id).ToList();
        return ids.Select(GetDelivery).Where(c => c != null).ToList();
    }

    // ── سطور المصدر: المتاح (مقبول/منتَج) ناقص ما سُلِّم بأوامر غير ملغاة ──
    private List<DeliverySourceLine> BuildSourceLines(string sourceType, int sourceId,
        QualityCheck check, ProductionOrder order, ProductionPlan plan, ProductionExecution execution)
    {
        var lines = new List<DeliverySourceLine>();
        if (sourceType == DeliverySources.FromActual)
        {
            if (order == null) return lines;
            var actualItems = order.Items
                .Where(i => i.ProducedQtyKg > 0.001 || i.ProducedCartons > 0)
                .GroupBy(i => new { i.ProductId, i.LotId, CustomerId = i.CustomerId ?? order.CustomerId, i.PackagingTypeId });
            foreach (var g in actualItems)
            {
                double produced = g.Sum(i => i.ProducedQtyKg);
                int packages = g.Sum(i => i.ProducedCartons);
                double delivered = Db.ProductionDeliveryItems.AsNoTracking()
                    .Join(Db.ProductionDeliveries.AsNoTracking(), i => i.DeliveryId, d => d.Id, (i, d) => new { i, d })
                    .Where(x => x.d.Status != DocStatuses.Cancelled && x.d.SourceType == DeliverySources.FromActual
                        && x.d.SourceId == sourceId && x.i.ProductId == g.Key.ProductId && x.i.LotId == g.Key.LotId
                        && x.i.CustomerId == g.Key.CustomerId)
                    .Sum(x => x.i.QtyKg);
                lines.Add(new DeliverySourceLine
                {
                    OrderId = order.Id,
                    OrderNumber = order.DocumentNumber,
                    ProductId = g.Key.ProductId,
                    ProductName = ProdName(g.Key.ProductId),
                    LotId = g.Key.LotId,
                    LotCode = g.Key.LotId != null ? LotCode(g.Key.LotId) : null,
                    CustomerId = g.Key.CustomerId,
                    CustomerName = g.Key.CustomerId != null ? CustName(g.Key.CustomerId) : null,
                    PackagingTypeId = g.Key.PackagingTypeId,
                    PackageCount = packages,
                    AvailableQtyKg = produced,
                    DeliveredQtyKg = delivered,
                    RemainingQtyKg = Math.Max(0, produced - delivered)
                });
            }
        }
        else if (sourceType == DeliverySources.FromCheck)
        {
            if (check == null || order == null) return lines;
            foreach (var g in check.Items.GroupBy(i => new { i.ProductId, i.LotId }))
            {
                double accepted = g.Sum(i => i.AcceptedQtyKg);
                if (accepted <= 0.001) continue;
                // §عميل السطر: بند الأمر المطابق (صنف + دفعة) ثم أول بند للصنف ثم عميل الأمر
                int? cust = order.Items.FirstOrDefault(i => i.ProductId == g.Key.ProductId && i.LotId == g.Key.LotId)?.CustomerId
                    ?? order.Items.FirstOrDefault(i => i.ProductId == g.Key.ProductId)?.CustomerId
                    ?? order.CustomerId;
                double delivered = Db.ProductionDeliveryItems.AsNoTracking()
                    .Join(Db.ProductionDeliveries.AsNoTracking(), i => i.DeliveryId, d => d.Id, (i, d) => new { i, d })
                    .Where(x => x.d.Status != DocStatuses.Cancelled && x.d.SourceType == DeliverySources.FromCheck
                        && x.d.SourceId == sourceId && x.i.ProductId == g.Key.ProductId && x.i.LotId == g.Key.LotId)
                    .Sum(x => x.i.QtyKg);
                lines.Add(new DeliverySourceLine
                {
                    OrderId = order.Id,
                    OrderNumber = order.DocumentNumber,
                    ProductId = g.Key.ProductId,
                    ProductName = ProdName(g.Key.ProductId),
                    LotId = g.Key.LotId,
                    LotCode = g.Key.LotId != null ? LotCode(g.Key.LotId) : null,
                    CustomerId = cust,
                    CustomerName = cust != null ? CustName(cust) : null,
                    AvailableQtyKg = accepted,
                    DeliveredQtyKg = delivered,
                    RemainingQtyKg = Math.Max(0, accepted - delivered)
                });
            }
        }
        else
        {
            if (plan == null) return lines;
            // §التجاوز يسلِّم المنتَج فقط (لا المخطط النظري): المنتَج المزامَن من الأوامر
            var planTypes = new[] { DeliverySources.FromPlan, DeliverySources.FromClosing };
            foreach (var pi in plan.Items)
            {
                if (pi.ProducedQtyKg <= 0.001) continue;
                int? ordId = Db.ProductionOrderItems.AsNoTracking()
                    .Where(o => o.PlanItemId == pi.Id).OrderBy(o => o.Id)
                    .Select(o => (int?)o.OrderId).FirstOrDefault();
                double delivered = Db.ProductionDeliveryItems.AsNoTracking()
                    .Join(Db.ProductionDeliveries.AsNoTracking(), i => i.DeliveryId, d => d.Id, (i, d) => new { i, d })
                    .Where(x => x.d.Status != DocStatuses.Cancelled && planTypes.Contains(x.d.SourceType)
                        && x.d.SourceId == sourceId && x.i.ProductId == pi.ProductId
                        && x.i.LotId == pi.LotId && x.i.CustomerId == pi.CustomerId)
                    .Sum(x => x.i.QtyKg);
                lines.Add(new DeliverySourceLine
                {
                    OrderId = ordId,
                    OrderNumber = ordId != null ? Db.ProductionOrders.AsNoTracking().Where(o => o.Id == ordId.Value).Select(o => o.DocumentNumber).FirstOrDefault() : null,
                    ProductId = pi.ProductId,
                    ProductName = ProdName(pi.ProductId),
                    LotId = pi.LotId,
                    LotCode = pi.LotId != null ? LotCode(pi.LotId) : null,
                    CustomerId = pi.CustomerId,
                    CustomerName = pi.CustomerId != null ? CustName(pi.CustomerId) : null,
                    AvailableQtyKg = pi.ProducedQtyKg,
                    DeliveredQtyKg = delivered,
                    RemainingQtyKg = Math.Max(0, pi.ProducedQtyKg - delivered)
                });
            }
        }
        return lines;
    }

    private string SourceNumber(string sourceType, int sourceId)
    {
        if (sourceType == DeliverySources.FromCheck)
            return Db.QualityChecks.AsNoTracking().Where(c => c.Id == sourceId).Select(c => c.DocumentNumber).FirstOrDefault() ?? $"#{sourceId}";
        return Db.ProductionPlans.AsNoTracking().Where(p => p.Id == sourceId).Select(p => p.DocumentNumber).FirstOrDefault() ?? $"#{sourceId}";
    }

    private string ProdName(int id)
        => Db.Products.AsNoTracking().Where(p => p.Id == id).Select(p => p.ProductNameAr).FirstOrDefault() ?? $"صنف #{id}";

    private string LotCode(int? id)
        => id == null ? null : Db.Lots.AsNoTracking().Where(l => l.Id == id.Value).Select(l => l.LotCode).FirstOrDefault() ?? $"دفعة #{id}";

    private string CustName(int? id)
        => id == null ? null : Db.Customers.AsNoTracking().Where(c => c.Id == id.Value).Select(c => c.CustomerName).FirstOrDefault() ?? $"عميل #{id}";
}
